@echo off
cd /d E:\w\0\election-v2-2.0\0716\g5
set NODE_ENV=production
set FORCE_AUTHN_INNERAPI_DOMAIN=http://localhost:3000
set FORCE_FRAMEWORK_DISABLE_DATAPASS=true
"E:\w\0\election-v2-2.0\0716\node22\node-v22.21.0-win-x64\node.exe" dist\server\main.js
