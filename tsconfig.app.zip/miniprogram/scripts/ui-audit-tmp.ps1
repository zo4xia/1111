$wxmlFiles = @(Get-ChildItem -Recurse -Path pages -Include *.wxml -File)
$allWxml = ''
foreach ($f in $wxmlFiles) { $allWxml += ([System.IO.File]::ReadAllText($f.FullName) + "`n") }

$cssFiles = @(Get-ChildItem -Recurse -Path pages -Include *.wxss -File)
if (Test-Path 'app.wxss') { $cssFiles += Get-Item 'app.wxss' }

# 收集 wxml 中出现的动态前缀，如 tag-{{ / dot-{{ / m-{{ ，避免误判为死代码
$dynPrefixes = New-Object System.Collections.Generic.List[string]
foreach ($m in [regex]::Matches($allWxml, '([a-zA-Z][\w-]*-)\s*\{\{')) {
  $p = $m.Groups[1].Value
  if (-not $dynPrefixes.Contains($p)) { $dynPrefixes.Add($p) }
}

$res = New-Object System.Collections.Generic.List[string]
$res.Add('=== DYNAMIC PREFIXES: ' + ($dynPrefixes -join ' , ') + ' ===')

$dead = New-Object System.Collections.Generic.List[string]

foreach ($cf in $cssFiles) {
  $isGlobal = ($cf.Name -eq 'app.wxss')
  $ownWxml = ''
  if (-not $isGlobal) {
    $p = Join-Path $cf.DirectoryName ($cf.BaseName + '.wxml')
    if (Test-Path $p) { $ownWxml = [System.IO.File]::ReadAllText($p) }
  }

  $lines = [System.IO.File]::ReadAllLines($cf.FullName)
  for ($i = 0; $i -lt $lines.Count; $i++) {
    foreach ($m in [regex]::Matches($lines[$i], '\.([a-zA-Z][\w-]*)')) {
      $cls = $m.Groups[1].Value

      $used = $false
      if ($isGlobal) {
        if ($allWxml.Contains($cls)) { $used = $true }
      } else {
        if ($ownWxml.Contains($cls)) { $used = $true }
        elseif ($allWxml.Contains($cls)) { $used = $true }
      }

      if (-not $used) {
        foreach ($p in $dynPrefixes) {
          if ($cls.StartsWith($p)) { $used = $true; break }
        }
      }
      # 令牌变量行不是类
      if ($lines[$i].Trim().StartsWith('--')) { $used = $true }

      if (-not $used) {
        $dead.Add($cf.Name + ':' + ($i + 1) + '  .' + $cls + '   |  ' + $lines[$i].Trim())
      }
    }
  }
}

$res.Add('=== DEAD CSS CLASSES (' + $dead.Count + ') ===')
foreach ($d in $dead) { $res.Add($d) }

[System.IO.File]::WriteAllLines((Join-Path (Get-Location) 'scripts/ui-audit-result.txt'), $res, [System.Text.UTF8Encoding]::new($false))
Write-Output ('done dead=' + $dead.Count)
