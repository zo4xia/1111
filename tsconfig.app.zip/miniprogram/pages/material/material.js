const { ctx } = require('../../utils/kit')
const { computeStageDates, materialWindowOpen } = require('../../utils/dates')
const icons = require('../../utils/icons')

const MATERIAL_TYPES = ['个人自荐表', '身份证', '个人简历', '无犯罪记录证明', '组织推荐函']
const CHANNELS = ['个人自荐', '组织推荐']
// 与材料上报相关的公告阶段（D-15 提名启动 ~ D-13 收审截止）
const MATERIAL_STAGES = ['D-15', 'D-14', 'D-13']

Page({
  data: {
    icons: icons.dai,
    realWindowOpen: false,
    canSubmit: false,
    windowMsg: '',
    annOptions: [],
    annIndex: -1,
    annSelected: null,
    typeIndex: -1,
    channelIndex: 0,
    channels: CHANNELS,
    types: MATERIAL_TYPES,
    gridConfig: { column: 4 },
    imgFiles: [],   // t-upload：拍照/相册图片
    docFiles: [],   // 文件附件（PDF/Word 等）
    records: [],
    // 来自「换届选举岗位清单」页快捷提交入口的预选岗位（material?position=岗位名）
    quickPos: ''
  },

  // 快捷提交口：method 页「上传材料」按钮带岗位参数进入，预选「个人自荐表」并提示
  onLoad(options) {
    if (options && options.position) {
      const pos = decodeURIComponent(options.position)
      this.setData({ quickPos: pos, typeIndex: 0 })
      wx.showToast({ title: '已预选报名岗位：' + pos, icon: 'none', duration: 2000 })
    }
  },

  onShow() { this.refresh() },

  refresh() {
    const { app, g, s } = ctx()
    if (!g.account || !g.orgId || !g.electionId) { wx.reLaunch({ url: '/pages/login/login' }); return }
    const el = app.election()
    const stages = computeStageDates(el.el_election_date, s.stages)
    // 窗口开关 = 日程引擎自动判断（D-15 ~ D-13），无人工开关
    const realOpen = materialWindowOpen(stages, g.snapshotDate)
    const annOptions = s.announcements.filter(a => MATERIAL_STAGES.includes(a.ann_stage_key))
      .map(a => ({ code: a.ann_code, title: a.ann_title, publish: (a.ann_publish_time || '').slice(0, 10) }))
    const phone = g.account ? g.account.acc_phone : ''
    const mine = s.materials.filter(m => m.mat_applicant_id === phone)
    const stName = { submitted: '已提交', needs_correction: '待补正', approved: '已通过', rejected: '未通过' }
    // 材料表未落 mat_ann_code，按材料归属阶段（提名阶段→D-15）反查当前作用域公告号，避免写死「第7号」
    const nomAnn = s.announcements.find(a =>
      a.ann_org_id === g.orgId && a.ann_election_id === g.electionId &&
      a.ann_stage_key === 'D-15' && (a.ann_status === 'published' || a.ann_status === '已发布'))
    const records = mine.map(m => ({
      name: (m.mat_type === '组织推荐' ? '组织推荐函' : '个人自荐表') + '（' + m.mat_position_id + '岗）',
      date: (m.mat_submit_time || '').slice(0, 10),
      status: stName[m.mat_status] || m.mat_status,
      ok: m.mat_status === 'approved',
      type: m.mat_type,
      ann: nomAnn ? nomAnn.ann_code : (m.mat_stage || '待关联公告'),
      comment: m.mat_review_comment
    }))
    const d15 = stages.find(x => x.es_stage_key === 'D-15')
    const d13 = stages.find(x => x.es_stage_key === 'D-13')
    this.setData({
      realWindowOpen: realOpen, canSubmit: realOpen, annOptions, records,
      windowMsg: realOpen
        ? '材料上报窗口开放中：' + (d15 ? d15.plan_start : '') + ' ~ ' + (d13 ? d13.plan_start : '')
        : '窗口按日程自动开关（开放与截止日期以公布日程为准），逾期无法提交'
    })
  },

  pickAnn(e) { const idx = Number(e.detail.value); this.setData({ annIndex: idx, annSelected: this.data.annOptions[idx] }) },
  pickType(e) { this.setData({ typeIndex: Number(e.detail.value) }) },
  pickChannel(e) { this.setData({ channelIndex: Number(e.detail.value) }) },

  /* ============ t-upload：拍照 / 相册图片（可自增多个） ============ */
  onImgAdd(e) {
    const add = (e.detail.files || []).map(f => ({ url: f.url, name: f.name || '材料图片', size: f.size, type: 'image' }))
    this.setData({ imgFiles: this.data.imgFiles.concat(add).slice(0, 9) })
  },
  onImgRemove(e) {
    const idx = e.detail.index
    const imgFiles = this.data.imgFiles.slice()
    imgFiles.splice(idx, 1)
    this.setData({ imgFiles })
  },
  onUploadFail() { wx.showToast({ title: '选择图片失败，请重试', icon: 'none' }) },

  /* ============ 文件附件：自增多个（PDF / Word 等） ============ */
  addDocFile() {
    if (!this.data.canSubmit) { wx.showToast({ title: '窗口已关闭，按日程自动截止', icon: 'none' }); return }
    const that = this
    wx.chooseMessageFile({
      count: 9, type: 'file',
      success(res) {
        const add = res.tempFiles.map(f => ({ name: f.name, size: Math.max(1, Math.round(f.size / 1024)) + 'KB' }))
        that.setData({ docFiles: that.data.docFiles.concat(add).slice(0, 9) })
      }
    })
  },
  removeDocFile(e) {
    const idx = e.currentTarget.dataset.idx
    const docFiles = this.data.docFiles.slice()
    docFiles.splice(idx, 1)
    this.setData({ docFiles })
  },

  submit() {
    if (!this.data.canSubmit) { wx.showToast({ title: '窗口已关闭，按日程自动截止', icon: 'none' }); return }
    const { annIndex, typeIndex, channelIndex, imgFiles, docFiles, channels, types } = this.data
    if (annIndex < 0) { wx.showToast({ title: '请先选择关联的公告事件', icon: 'none' }); return }
    if (typeIndex < 0) { wx.showToast({ title: '请先选择材料类型', icon: 'none' }); return }
    if (!imgFiles.length && !docFiles.length) { wx.showToast({ title: '请先拍照或添加文件附件', icon: 'none' }); return }
    const g = getApp().globalData
    const rec = {
      name: types[typeIndex] + '（演示提交）',
      date: (g.snapshotDate || '').slice(0, 10),
      status: '已提交', ok: null, type: channels[channelIndex],
      ann: this.data.annOptions[annIndex].code,
      files: '图片 ' + imgFiles.length + ' 份 · 文件 ' + docFiles.length + ' 份',
      comment: '演示数据：本地暂存，等待工作人员审核'
    }
    this.setData({ records: [rec].concat(this.data.records), imgFiles: [], docFiles: [], annIndex: -1, annSelected: null, typeIndex: -1 })
    wx.showToast({ title: '提交成功，等待收审', icon: 'success' })
  }
})
