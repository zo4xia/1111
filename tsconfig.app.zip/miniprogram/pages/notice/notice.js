const { ctx } = require('../../utils/kit')
const { computeStageDates, shortRange } = require('../../utils/dates')
const { DB } = require('../../data/db')
const icons = require('../../utils/icons')

function excerptOf(s, n) {
  n = n || 64
  if (!s) return ''
  s = String(s).replace(/\s+/g, ' ').trim()
  return s.length > n ? s.slice(0, n) + '…' : s
}

Page({
  data: {
    icons: icons.dai,
    activeTab: 'latest',
    orgName: '',
    marqueeText: '',
    latest: [],
    electionOptions: [],
    electionIndex: 0,
    selectedElectionId: '',
    selectedElectionLabel: '',
    forecasts: [],
    history: [],
    detail: null,
    detailKind: '',
    readSet: []
  },

  onShow() {
    this.setData({ readSet: wx.getStorageSync('readNotices') || [] })
    this.refresh()
    // ⇠ 来自首页“某条公告”点击：home 把目标 ann_code 挂到 globalData.pendingAnnCode，
    //    此处接收并在 latest 列表中定位 idx，自动打开对应详情（而非停留在列表页）。
    this._tryOpenPending()
  },

  _tryOpenPending() {
    const app = getApp()
    const code = app.pendingAnnCode
    if (!code) return
    app.pendingAnnCode = null
    // 确保落在 latest 标签（首页公告均为已发布，归属 latest）
    if (this.data.activeTab !== 'latest') this.setData({ activeTab: 'latest', detail: null })
    const idx = (this.data.latest || []).findIndex(x => x.code === code)
    if (idx >= 0) this.openDetail({ currentTarget: { dataset: { idx } } })
  },

  refresh() {
    const { app, g, s } = ctx()
    if (!g.account || !g.orgId || !g.electionId) { wx.reLaunch({ url: '/pages/login/login' }); return }
    const org = app.org()
    const el = app.election()
    const stages = computeStageDates(el.el_election_date, s.stages)
    const readSet = this.data.readSet || []

    // 公告页允许在同一个村居内切换当前届和历史届，默认仍落在当前正在进行的届次。
    const electionOptions = DB.elections
      .filter(x => x.el_org_id === g.orgId)
      .sort((a, b) => {
        if (a.el_id === g.electionId) return -1
        if (b.el_id === g.electionId) return 1
        return (b.el_election_date || '').localeCompare(a.el_election_date || '')
      })
      .map(x => ({
        id: x.el_id,
        term: x.el_term,
        label: (x.el_id === g.electionId ? '当前届次 · ' : '') + x.el_term + ' · ' + x.el_name,
        name: x.el_name,
        status: x.el_status,
        date: x.el_election_date
      }))
    const selectedElectionId = electionOptions.some(x => x.id === this.data.selectedElectionId)
      ? this.data.selectedElectionId
      : (electionOptions.some(x => x.id === g.electionId) ? g.electionId : (electionOptions[0] ? electionOptions[0].id : ''))
    const electionIndex = Math.max(0, electionOptions.findIndex(x => x.id === selectedElectionId))
    const selectedElection = electionOptions[electionIndex]

    const anns = DB.announcements
      .filter(a => a.ann_org_id === g.orgId && a.ann_election_id === selectedElectionId)
      .filter(a => a.ann_status === 'published' || a.ann_status === '已发布')

    // —— 公告按「事情时间线」排序：真相源 election_stages.es_offset_start 升序（D-35 → D0），
    //    同阶段内按 ann_publish_time 升序（号次顺序）；每条挂阶段名标签 es_stage_name ——
    const stageRows = DB.election_stages
      .filter(x => x.es_election_id === selectedElectionId)
      .sort((a, b) => (a.es_offset_start || 0) - (b.es_offset_start || 0))
    const stageIdx = {}
    const stageNameMap = {}
    const stageNoteMap = {}
    stageRows.forEach((s, i) => {
      stageIdx[s.es_stage_key] = i
      stageNameMap[s.es_stage_key] = s.es_stage_name
      stageNoteMap[s.es_stage_key] = s.es_note || ''
    })

    const latest = anns.map(a => {
      const selectedStages = selectedElectionId === g.electionId
        ? stages
        : computeStageDates(selectedElection ? selectedElection.date : '', stageRows)
      const st = selectedStages.find(x => x.es_stage_key === a.ann_stage_key)
      const code = a.ann_code
      return {
        code, title: a.ann_title, content: a.ann_content,
        excerpt: excerptOf(a.ann_content, 64),
        stageKey: a.ann_stage_key,
        stageName: stageNameMap[a.ann_stage_key] || '通用事项',
        stageNote: stageNoteMap[a.ann_stage_key] || '',
        stageIdx: stageIdx[a.ann_stage_key] !== undefined ? stageIdx[a.ann_stage_key] : 999,
        // 仅提名/收审阶段（D-15~D-13）的公告与材料上报相关，详情底部才出现“前往材料提交”
        canMaterial: ['D-15', 'D-14', 'D-13'].includes(a.ann_stage_key),
        start: st ? st.plan_start : '', end: st ? st.plan_end : '',
        publish: (a.ann_publish_time || '').slice(0, 10),
        electionTerm: selectedElection ? selectedElection.term : '',
        noticeKey: selectedElectionId + '::' + code,
        unread: readSet.indexOf(selectedElectionId + '::' + code) === -1
      }
    }).sort((x, y) => (x.stageIdx - y.stageIdx) || String(x.publish).localeCompare(String(y.publish)))

    const forecasts = stages
      .filter(x => x.plan_start && x.plan_start > g.snapshotDate)
      .map(x => {
        const status = x.es_status || '未开始'
        const cls = status === '办理中' || status === '进行中' || status === '已开始' ? 'tag-live'
          : status === '已完成' || status === '已归档' ? 'tag-done'
          : 'tag-forecast'
        return { key: x.es_stage_key, name: x.es_stage_name, start: x.plan_start, end: x.plan_end, note: x.es_note, annDesc: x.es_note, statusLabel: status, statusCls: cls }
      })

    // 「现在进行中」数据源 = 全量阶段中状态为办理中/进行中/已开始 的那一个。
    // 不能用 forecasts 找（它是未来阶段，永远命不中 tag-live），否则 live-banner 恒为空。
    const LIVE_STATUS = ['办理中', '进行中', '已开始']
    const liveStageRaw = stages.find(x => LIVE_STATUS.includes(x.es_status)) || null
    const liveStage = liveStageRaw
      ? { key: liveStageRaw.es_stage_key, name: liveStageRaw.es_stage_name, start: liveStageRaw.plan_start, end: liveStageRaw.plan_end, range: shortRange(liveStageRaw.plan_start, liveStageRaw.plan_end) }
      : null

    const history = []
    const ysAnns = s.announcements.slice().sort((a, b) => (b.ann_publish_time || '').localeCompare(a.ann_publish_time || ''))
    const scopedResults = s.results.filter(r => r.er_election_id === g.electionId)
    const ysRes = scopedResults
    if (ysRes.length) {
      const head = ysRes[0]
      const winners = ysRes.map(r => r.er_winner_name).join('、')
      history.push({ title: '第11届延寿村委会换届选举结果公示', date: head.er_election_date, result: '主任：' + ysRes[0].er_winner_name + '｜委员：' + winners, voters: '参选率：' + head.er_turnout + '（' + head.er_actual_voters + '人投票）', status: '已完成', orgName: '延寿村委会', stageKey: 'D0', stageName: '正式选举', stageNote: '现场集中投票、当众开箱计票、当场公布结果' })
    }
    const jkRes = scopedResults
    if (jkRes.length) {
      history.push({ title: '第14届涧口社区居委会换届选举结果公示', date: jkRes[0].er_election_date, result: '主任：' + jkRes[0].er_winner_name + '｜委员：' + jkRes.map(r => r.er_winner_name).join('、'), voters: '参选率：' + jkRes[0].er_turnout + '（' + jkRes[0].er_actual_voters + '人投票）', status: '已归档', orgName: '涧口社区居委会', stageKey: 'D0', stageName: '正式选举', stageNote: '现场集中投票、当众开箱计票、当场公布结果' })
    }
    ysAnns.filter(a => ['第17号', '第17-1号', '第9号'].includes(a.ann_code)).forEach(a => {
      history.push({ title: a.ann_code + ' ' + a.ann_title, date: (a.ann_publish_time || '').slice(0, 10), result: '延寿村委会第11届（已完结样本）', voters: '正文可点开查看', status: '已完结', orgName: '延寿村委会', content: a.ann_content, stageKey: a.ann_stage_key, stageName: a.ann_stage_key === 'D0' ? '正式选举' : '正式候选人公示', stageNote: a.ann_stage_key === 'D0' ? '现场集中投票、当众开箱计票、当场公布结果' : '联审收尾，确定并公示正式候选人名单' })
    })

    // 时间线升序后，最新一条在末尾（走马灯播最新）
    const lastAnn = latest.length ? latest[latest.length - 1] : null
    const marqueeText = (selectedElection ? selectedElection.term + ' · ' : '') + '公告 ' + latest.length + ' 条已发布 — 最新：' + (lastAnn ? lastAnn.code + ' ' + lastAnn.title : '当前届次暂无已发布公告')
    const unreadCount = latest.filter(a => a.unread).length

    // —— 阶段卡片：按 election_stages 分组，每阶段一张高级感卡片（阶段参数+介绍+公告列表）——
    const stageCardMap = {}
    stageRows.forEach((s, i) => {
      const computed = stages.find(x => x.es_stage_key === s.es_stage_key) || {}
      stageCardMap[s.es_stage_key] = {
        key: s.es_stage_key,
        name: s.es_stage_name,
        note: s.es_note || '',
        status: s.es_status || '未开始',
        statusCls: (s.es_status === '已完成' || s.es_status === '已归档') ? 'tag-done'
          : (s.es_status === '办理中' || s.es_status === '进行中' || s.es_status === '已开始') ? 'tag-live'
          : 'tag-forecast',
        barCls: (s.es_status === '已完成' || s.es_status === '已归档') ? 'bar-done'
          : (s.es_status === '进行中' || s.es_status === '已开始') ? 'bar-live'
          : 'bar-todo',
        start: computed.plan_start || '',
        end: computed.plan_end || '',
        stageIdx: i,
        announcements: []
      }
    })
    latest.forEach((a, idx) => {
      const card = stageCardMap[a.stageKey]
      if (card) card.announcements.push(Object.assign({}, a, { globalIdx: idx }))
    })
    const stageCards = Object.values(stageCardMap)
      .filter(c => c.announcements.length > 0)
      .sort((a, b) => a.stageIdx - b.stageIdx)

    this.setData({ orgName: org ? org.name : '', marqueeText, latest, stageCards, electionOptions, electionIndex, selectedElectionId, selectedElectionLabel: selectedElection ? selectedElection.label : '', forecasts, history, unreadCount, liveStage })
  },

  pickElection(e) {
    const index = Number(e.detail.value)
    const option = (this.data.electionOptions || [])[index]
    if (!option) return
    this.setData({ electionIndex: index, selectedElectionId: option.id })
    this.refresh()
  },

  switchTab(e) { this.setData({ activeTab: e.currentTarget.dataset.key, detail: null }) },

  openDetail(e) {
    const idx = e.currentTarget.dataset.idx
    let d, kind
    if (this.data.activeTab === 'latest') { d = this.data.latest[idx]; kind = 'ann' }
    else if (this.data.activeTab === 'forecast') { d = this.data.forecasts[idx]; kind = 'forecast' }
    else {
      const h = this.data.history[idx]
      if (h.content) { d = h; kind = 'ann' } else { wx.showToast({ title: '结果详情见PC端「结果与花名册」', icon: 'none' }); return }
    }
    if (d && d.code) {
      const rs = new Set(this.data.readSet || [])
      rs.add(d.noticeKey || d.code)
      const arr = Array.from(rs)
      wx.setStorageSync('readNotices', arr)
      const latest = this.data.latest.map(x => x.code === d.code ? Object.assign({}, x, { unread: false }) : x)
      this.setData({ readSet: arr, latest, unreadCount: latest.filter(x => x.unread).length })
      d = Object.assign({}, d, { unread: false, excerpt: d.excerpt || excerptOf(d.content, 64) })
    }
    this.setData({ detail: d, detailKind: kind })
  },

  closeDetail() { this.setData({ detail: null }) },
  goMaterial() { this.setData({ detail: null }); wx.navigateTo({ url: '/pages/material/material' }) },
  // 公告原文下载：小程序内无文件流，以「复制全文」落地（可粘贴到本地保存/转发）
  copyAnnContent() {
    const d = this.data.detail
    if (!d || !d.content) return
    wx.setClipboardData({
      data: d.title + '\n' + d.content,
      success: () => wx.showToast({ title: '原文已复制，可粘贴保存', icon: 'success' })
    })
  }
})
