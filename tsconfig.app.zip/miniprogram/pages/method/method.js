const { ctx } = require('../../utils/kit')
const { computeStageDates, fullRange, parseDate } = require('../../utils/dates')
const { DB, electionMethodsByOrgType } = require('../../data/db')
const icons = require('../../utils/icons')

// 各阶段应发布公告号（真相源：甲方 docx「需发布公告」列 ≡ xlsx stage_templates.st_announcement）
// D日两口径：村=16/17+17-1号，居=16/17号，此处取并集展示
const STAGE_ANN_MAP = {
  'D-35': '', 'D-34': '公告 1/2/3 号', 'D-33~-29': '张贴 3 号', 'D-28~-24': '公告 4 号',
  'D-23~-21': '更正补充公告', 'D-20~-16': '公告 5/6/6-1 号', 'D-15': '公告 7 号', 'D-14': '',
  'D-13': '公告 8 号+2-1 号', 'D-12~-10': '预选办法+结果', 'D-9~-5': '', 'D-4': '公告 9 号',
  'D-3~-2': '公告 10~14 号', 'D-1': '公告 15 号', 'D0': '公告 16/17 号', 'D+1~+10': ''
}

const STAGE_STATUS_TEXT = { '已完成': '已完成', '办理中': '进行中', '未开始': '未开始' }

function statusLabel(status) {
  if (status === 'in_progress') return '正在进行'
  if (status === 'archived') return '历史归档'
  return status || '未开始'
}

// 选举方式说明：以当前归属地(org.type)决定支持哪些形式（登录选归属地时已埋点筛选村/居），
// el_method 只记录本届实际选用方式。差额/等额属于正式候选人预选规则，不在此列。
function methodDetail(orgType, method) {
  const catalog = electionMethodsByOrgType(orgType)
  const hit = catalog.find(x => x.key === method) || catalog[0]
  const tail = catalog.length > 1
    ? `（本社区选举办法由居民代表会议从 ${catalog.map(x => x.key).join(' / ')} 中表决确定）`
    : ''
  return hit.desc + tail
}

function dateText(s) { return s ? String(s).slice(0, 10) : '' }

// 汉字纪年（公文落款用）：2026-08 → 二〇二六年八月
const CN_DIGITS = ['〇', '一', '二', '三', '四', '五', '六', '七', '八', '九']
const CN_MONTHS = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二']
function dateCN(d) {
  const y = String(d.getFullYear()).split('').map(x => CN_DIGITS[Number(x)]).join('')
  return `${y}年${CN_MONTHS[d.getMonth() + 1]}月`
}

Page({
  data: {
    icons: icons.dai,
    electionOptions: [],
    electionIndex: 0,
    // t-picker 筛选器状态（keys 映射 electionOptions 的 id/label 字段）
    pickerVisible: false,
    pickerKeys: { value: 'id', label: 'label' },
    selectedElectionId: '',
    selectedElection: null,
    electionMethodText: '',
    electionMethodDetail: '',
    positions: [],
    positionTotal: 0,
    gov: {},
    stages: [],
    stageCounts: { done: 0, doing: 0, todo: 0 },
    currentStage: null,
    progressDone: 0,
    resources: [],
    resourceVisible: false,
    selectedResource: null,
    // 在任干部花名册（后台手工输入，roster 表按当前组织作用域）
    roster: [],
    // t-table 列定义（colKey 对应 roster 字段；联系电话等宽数字）
    rosterColumns: [
      { title: '姓名', colKey: 'name', align: 'center', width: 130 },
      { title: '职位', colKey: 'position', align: 'left' },
      { title: '联系电话', colKey: 'phone', align: 'center', width: 220 }
    ],
    // 报名表弹窗
    formVisible: false,
    formText: '',
    formPosition: ''
  },

  onShow() { this.refresh() },

  refresh() {
    const { app, g, s } = ctx()
    if (!g.account || !g.orgId || !g.electionId) {
      wx.reLaunch({ url: '/pages/login/login' })
      return
    }

    const electionOptions = DB.elections
      .filter(x => x.el_org_id === g.orgId)
      .sort((a, b) => {
        if (a.el_id === g.electionId) return -1
        if (b.el_id === g.electionId) return 1
        return (b.el_election_date || '').localeCompare(a.el_election_date || '')
      })
      .map(x => ({
        id: x.el_id,
        term: x.el_term,
        label: (x.el_id === g.electionId ? '当前活动 · ' : '') + x.el_term + ' · ' + x.el_name,
        name: x.el_name,
        orgName: (app.org() && app.org().name) || x.el_name,
        status: x.el_status,
        statusLabel: statusLabel(x.el_status),
        date: dateText(x.el_election_date),
        method: x.el_method || '按方案执行',
        note: x.el_note || ''
      }))

    const selectedElectionId = electionOptions.some(x => x.id === this.data.selectedElectionId)
      ? this.data.selectedElectionId
      : (electionOptions.some(x => x.id === g.electionId) ? g.electionId : (electionOptions[0] ? electionOptions[0].id : ''))
    const electionIndex = Math.max(0, electionOptions.findIndex(x => x.id === selectedElectionId))
    const selectedElection = electionOptions[electionIndex] || null
    const method = selectedElection ? selectedElection.method : ''
    // 当前归属地类型（村/居）——登录选归属地时已埋点筛选，决定公文称谓/选举方式/审核口径
    const org = app.org() || {}
    const orgType = org.type || 'village_committee'
    const isCommunity = orgType === 'community_committee'
    const orgShort = (org.name || '').replace(/居委会|村委会/, '')

    // —— 公文卡文案（村/居口径自适应，称谓规则=甲方 Word TABLE 2 通用替换） ——
    const gov = {
      guide: isCommunity
        ? '经居民代表会议研究决定，本届换届选举设置以下岗位，现将有关事项公告如下：'
        : '经村民代表会议研究决定，本届换届选举设置以下岗位，现将有关事项公告如下：',
      eligibility: isCommunity
        ? '年满十八周岁、依照法律未被剥夺政治权利的本社区登记居民，均可报名参选上述岗位。'
        : '年满十八周岁、依照法律未被剥夺政治权利的本村登记村民，均可报名参选上述岗位。',
      office: isCommunity ? '居委会办公室' : '村委会办公室',
      committee: isCommunity ? `${orgShort}社区居民选举委员会` : `${orgShort}村民选举委员会`,
      // 公文落款取演示快照日（g.snapshotDate），与公告/日程数据同处 2026-07 时间轴；
      // 若用真实时钟（2026-08）会出现「数据 7 月、落款 8 月」的错位。
      dateCN: dateCN(parseDate(g.snapshotDate) || new Date())
    }

    // —— 本届换届选举岗位清单（positions 表：职位/职数/岗位需求说明） ——
    const positions = DB.positions
      .filter(x => x.pos_org_id === g.orgId && x.pos_election_id === selectedElectionId)
      .map(x => ({
        type: x.pos_type,
        quota: Number(x.pos_quota) || 0,
        status: x.pos_status,
        desc: x.pos_desc || '按本届选举方案执行'
      }))

    // —— 换届日程：全量阶段时间线（不再截断，办理中/D日必须可见） ——
    const stageRows = DB.election_stages.filter(x => x.es_election_id === selectedElectionId)
    const notices = DB.announcements.filter(x => x.ann_org_id === g.orgId && x.ann_election_id === selectedElectionId && (x.ann_status === 'published' || x.ann_status === '已发布'))
    const stages = computeStageDates(selectedElection ? selectedElection.date : '', stageRows)
      .map(x => ({
        key: x.es_stage_key,
        name: x.es_stage_name,
        start: x.plan_start || '',
        end: x.plan_end || '',
        status: x.es_status || '未开始',
        statusText: STAGE_STATUS_TEXT[x.es_status] || x.es_status || '未开始',
        cls: x.es_status === '已完成' ? 'done' : (x.es_status === '办理中' ? 'doing' : 'todo'),
        // t-tag 状态映射（tdesign 标准标签）
        tagTheme: x.es_status === '办理中' ? 'primary' : 'default',
        tagVariant: x.es_status === '未开始' ? 'outline' : 'light',
        dday: x.es_offset_start === 0 && x.es_offset_end === 0,
        annText: STAGE_ANN_MAP[x.es_stage_key] || '',
        noticeCount: notices.filter(n => n.ann_stage_key === x.es_stage_key).length
      }))
    const stageCounts = {
      done: stages.filter(x => x.status === '已完成').length,
      doing: stages.filter(x => x.status === '办理中').length,
      todo: stages.filter(x => x.status === '未开始').length
    }
    const active = stages.find(x => x.status === '办理中')
    const progressDone = stages.length ? Math.round(stageCounts.done / stages.length * 100) : 0

    // —— 在任干部花名册（纯展示，后台手工输入；roster 表按当前组织作用域 s.roster） ——
    // rowKey 供 t-table 行主键使用（ros_id 优先，缺失时按 姓名::职位 兜底，避免同名人员冲突）
    const roster = s.roster.map((r, i) => ({
      rowKey: r.ros_id || (r.ros_name + '::' + (r.ros_position || i)),
      position: r.ros_position,
      name: r.ros_name,
      phone: r.ros_phone || ''
    }))

    // 公告正文模板：真相源(甲方docx)中「公告正文模板」即官方公告标准文本，
    // 对应 announcement_templates.at_content 字段。该体系无「附件下载 URL」概念，
    // 因此前端直接展示 at_content 正文，不取不存在的 at_file_url/at_attachment。
    const resources = DB.announcement_templates.slice(0, 8).map(x => ({
      code: x.at_code,
      name: x.at_name,
      label: x.at_code + ' · ' + x.at_name,
      note: x.at_note || '官方公告标准文本',
      content: x.at_content || ''
    }))

    this.setData({
      electionOptions,
      electionIndex,
      selectedElectionId,
      selectedElection,
      electionMethodText: method,
      electionMethodDetail: methodDetail(orgType, method),
      positions,
      positionTotal: positions.reduce((sum, x) => sum + x.quota, 0),
      gov,
      stages,
      stageCounts,
      currentStage: active
        ? { key: active.key, name: active.name, start: active.start, end: active.end, range: fullRange(active.start, active.end) }
        : null,
      progressDone,
      roster,
      resources
    })
  },

  /* ============ 选举活动筛选（tdesign t-picker 标准交互） ============ */
  openElectionPicker() {
    if (!this.data.electionOptions.length) return
    this.setData({ pickerVisible: true })
  },
  closeElectionPicker() {
    this.setData({ pickerVisible: false })
  },
  onPickerVisibleChange(e) {
    if (!e.detail.visible) this.setData({ pickerVisible: false })
  },
  onElectionConfirm(e) {
    const id = e.detail && e.detail.value && e.detail.value[0]
    const index = (this.data.electionOptions || []).findIndex(x => x.id === id)
    if (index < 0) return
    this.setData({ electionIndex: index, selectedElectionId: id, pickerVisible: false })
    this.refresh()
  },

  /* ============ 报名表（无短信/文件接口，采用「模板文本 + 一键复制」方案） ============ */
  // 官方报名表以文本模板呈现：用户复制后可在微信中粘贴打印，或填写后拍照走「快捷提交」上传
  buildFormText(posName) {
    const app = getApp()
    const org = (app.org() && app.org().name) || '本村（社区）'
    const term = this.data.selectedElection ? this.data.selectedElection.term : ''
    return [
      org + term + '换届选举报名表',
      '━━━━━━━━━━━━━━━━━━',
      '报名岗位：' + (posName || '____________'),
      '━━━━━━━━━━━━━━━━━━',
      '姓名：____________　　性别：______',
      '出生年月：____________　政治面貌：____________',
      '身份证号：____________________',
      '联系电话：____________',
      '户籍/居住地址：____________________',
      '━━━━━━━━━━━━━━━━━━',
      '个人简历（学习、工作经历）：',
      '________________________________',
      '',
      '自荐理由：',
      '________________________________',
      '',
      '本人承诺以上信息真实、准确、有效。',
      '报名人签名：____________　　日期：____________'
    ].join('\n')
  },
  openForm(e) {
    const pos = (e && e.currentTarget && e.currentTarget.dataset.pos) || ''
    this.setData({ formVisible: true, formPosition: pos, formText: this.buildFormText(pos) })
  },
  closeForm() { this.setData({ formVisible: false }) },
  onFormVisibleChange(e) { if (!e.detail.visible) this.setData({ formVisible: false }) },
  copyForm() {
    wx.setClipboardData({
      data: this.data.formText,
      success: () => wx.showToast({ title: '报名表已复制，可粘贴打印或填写', icon: 'none' })
    })
  },

  /* ============ 快捷提交：直通材料提交大模块（material 页，支持岗位预选） ============ */
  quickSubmit(e) {
    const pos = (e && e.currentTarget && e.currentTarget.dataset.pos) || ''
    const query = pos ? '?position=' + encodeURIComponent(pos) : ''
    wx.navigateTo({ url: '/pages/material/material' + query })
  },

  openResources() { this.setData({ resourceVisible: true, selectedResource: null }) },
  closeResources() { this.setData({ resourceVisible: false, selectedResource: null }) },
  onResourceVisibleChange(e) { if (!e.detail.visible) this.setData({ resourceVisible: false, selectedResource: null }) },
  // 点击模板 → 查看公告正文（at_content），不再尝试下载文件
  previewResource(e) {
    const item = (this.data.resources || [])[Number(e.currentTarget.dataset.index)]
    if (!item) return
    this.setData({ selectedResource: item })
  },
  backResource() { this.setData({ selectedResource: null }) }
})
