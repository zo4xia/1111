const { DB } = require('../../data/db')
const icons = require('../../utils/icons')

Page({
  data: {
    icons: icons.dai,
    // 演示预填充：用户名=手机号，密码意思一下（明天演示直接撑场，可一键登录）
    phone: '13800000002',
    password: '123456',
    // 当前选中的角色 ar_role_key（由 account_roles 动态给出，不再是写死枚举）
    role: '',
    roleList: [],        // 该账号+归属地下的可用角色 [{ key, name }]
    isGuest: false,       // 当前是否以游客身份兜底（未注册 / 无可用角色）
    isUnregistered: false, // 手机号在 accounts 中无记录（完全未注册）
    orgIndex: -1,        // -1 = 未选择；归属地强制必选
    orgs: [],
    orgNames: [],
    error: '',
    loading: false
  },

  onLoad() {
    const app = getApp()
    // ⇠ 后端[organizations] app.demoOrgs() 返回「村(居)委会且存在进行中届次」的组织列表；
    //   页面消费 org.slug(归属地标识) 与 org.name(显示)。
    //   （内部按 organizations.type ∈ {community_committee, village_committee} 过滤，organizations.type 亦被使用）
    const orgs = app.demoOrgs()
    this.setData({ orgs, orgNames: orgs.map(o => o.name) })
  },

  // 依据「手机号 + 所选归属地」反查 account_roles，并用 roles 字典映射中文名渲染芯片；
  // 未注册账号或账号无可用角色 → 一律兜底为「游客」身份
  _refreshRoles() {
    const { phone, orgs, orgIndex } = this.data
    if (orgIndex < 0 || !phone) {
      this.setData({ roleList: [], role: '', isGuest: false, isUnregistered: false })
      return
    }
    const org = orgs[orgIndex]
    // ⇠ 后端[accounts.acc_phone] 判断是否已在系统注册
    const acc = DB.accounts.find(a => a.acc_phone === phone)
    const isUnregistered = !acc
    // ⇠ 后端[account_roles] 按 ar_acc_id(手机号) + ar_org_id(归属地) + ar_status=active
    //   取该账号在本组织拥有的全部角色 key
    const keys = DB.account_roles
      .filter(r => r.ar_acc_id === phone && r.ar_org_id === org.slug && r.ar_status === 'active')
      .map(r => r.ar_role_key)
    // ⇠ 后端[roles] 字典：role_key → role_name（中文显示名）
    const roleMap = {}
    DB.roles.forEach(r => { roleMap[r.role_key] = r.role_name })
    if (keys.length) {
      // 已注册且有角色：动态渲染真实角色芯片
      const roleList = keys.map(k => ({ key: k, name: roleMap[k] || k }))
      this.setData({ roleList, role: roleList[0].key, isGuest: false, isUnregistered })
    } else {
      // 未注册 / 无可用角色：兜底为游客（role='guest' 仅作标记，login 时映射为 voters 只读）
      this.setData({ roleList: [], role: 'guest', isGuest: true, isUnregistered })
    }
  },

  onPhone(e) { this.setData({ phone: e.detail.value, error: '' }); this._refreshRoles() },
  onPassword(e) { this.setData({ password: e.detail.value, error: '' }) },
  onRole(e) { this.setData({ role: e.currentTarget.dataset.r, error: '' }) },
  onOrgChange(e) {
    const v = e && e.detail && e.detail.value
    if (v !== undefined) {
      this.setData({ orgIndex: Number(v), error: '' })
      this._refreshRoles()
    }
  },

  submit() {
    if (this.data.loading) return
    const { phone, password, role, orgs, orgIndex } = this.data
    // 归属地强制必选：未选则拦截
    if (orgIndex < 0) return this.setData({ error: '请先选择归属地（演示数据所属组织）' })
    const org = orgs[orgIndex]
    // ⇠ 后端[accounts.acc_phone] 以手机号作为登录唯一标识查询账号
    const acc = DB.accounts.find(a => a.acc_phone === phone)
    // 未注册用户 → 直接以游客身份访问（绕过账号存在性 / 密码校验）
    if (!acc) {
      this.setData({ loading: true })
      wx.showLoading({ title: '游客访问中…', mask: true })
      setTimeout(() => {
        wx.hideLoading()
        // ⇠ 游客兜底账号：无 acc 记录时构造游客身份，roleKey 映射为 voters（只读），进入后按游客展示
        const guestAcc = { acc_phone: phone, acc_org_id: org.slug, acc_status: 'guest', isGuest: true }
        // ⇠ 后端[account_roles] 游客无反查命中，app.login 退化为 voters；门禁待逐页统一
        getApp().login(guestAcc, 'voters', org.slug)
        wx.switchTab({ url: '/pages/home/home' })
      }, 320)
      return
    }
    // ⇠ 后端[accounts.acc_status] 状态校验：已注册但非 active 仍拦截（停用账号不可登录）
    if (acc.acc_status !== 'active') return this.setData({ error: '账号已停用' })
    // ⇠ 后端[accounts.acc_password_hint] 明文密码 hint 比对（演示用；生产应走服务端鉴权，禁止前端明文）
    if (password !== '123456' && password !== acc.acc_password_hint) return this.setData({ error: '密码错误' })
    // 已注册但有角色 / 无角色：role='guest' 表示无可用角色，兜底为游客(voters)
    const finalRole = (role === 'guest') ? 'voters' : role
    this.setData({ loading: true })
    wx.showLoading({ title: '登录中…', mask: true })
    setTimeout(() => {
      wx.hideLoading()
      // ⇠ 后端[account_roles] app.login() 按 ar_acc_id + ar_role_key 精确反查确定最终 roleKey；
      //   此处 role 已是真实 ar_role_key（如 operator）；游客时 finalRole='voters'。
      // ⇠ 后端[roles / role_quotas] 【仍未接入】：角色字典与权限配额表当前无路由级权限控制（门禁待逐页统一）。
      getApp().login(acc, finalRole, org.slug)
      wx.switchTab({ url: '/pages/home/home' })
    }, 380)
  },

  // 微信授权登录：意思一下拉起授权（wx.login 获取 code 即示意授权；真实 openid 绑定走服务端）
  quickLogin() {
    if (this.data.loading) return
    this.setData({ loading: true, error: '' })
    wx.showLoading({ title: '授权中…', mask: true })
    wx.login({
      success: (res) => {
        wx.hideLoading()
        this.setData({ loading: false })
        if (res.code) {
          // ⇠ 后端[account_roles / accounts] 微信 openid 应绑定服务端账号（演示仅示意，未落地绑定逻辑）
          wx.showToast({ title: '已获取微信授权，待绑定账号', icon: 'none', duration: 1800 })
          return
        }
        this.setData({ error: '微信授权未取得凭证，请改用账号登录' })
      },
      fail: () => {
        wx.hideLoading()
        this.setData({ loading: false, error: '微信授权暂不可用，请改用账号登录' })
      }
    })
  }
})
