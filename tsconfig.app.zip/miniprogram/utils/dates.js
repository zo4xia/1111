/**
 * D日锚点日程引擎（与管理端日期规则保持一致）
 * 唯一输入 = elections.el_election_date，16阶段日期全部由偏移量推算
 */
function parseDate(str) {
  if (!str) return null
  const parts = str.slice(0, 10).split('-').map(Number)
  return new Date(parts[0], parts[1] - 1, parts[2])
}

function fmtDate(dt) {
  if (!dt) return ''
  const p = n => (n < 10 ? '0' + n : '' + n)
  return dt.getFullYear() + '-' + p(dt.getMonth() + 1) + '-' + p(dt.getDate())
}

function addDays(baseStr, offset) {
  const dt = parseDate(baseStr)
  if (!dt) return ''
  dt.setDate(dt.getDate() + Number(offset))
  return fmtDate(dt)
}

/** 计算一届选举的16阶段计划日期 */
function computeStageDates(electionDate, stages) {
  return stages.map(s => Object.assign({}, s, {
    plan_start: electionDate ? addDays(electionDate, s.es_offset_start) : '',
    plan_end: electionDate ? addDays(electionDate, s.es_offset_end) : ''
  }))
}

function daysBetween(fromStr, toStr) {
  const a = parseDate(fromStr), b = parseDate(toStr)
  if (!a || !b) return null
  return Math.round((b - a) / 86400000)
}

/** 指定日期落在哪个阶段（D偏移区间判断） */
function stageOfDay(stagesWithDates, dayStr) {
  return stagesWithDates.find(s => s.plan_start && s.plan_end && s.plan_start <= dayStr && dayStr <= s.plan_end) || null
}

/**
 * 完整日期 'YYYY-MM-DD' → 短日期 'MM-DD'（时间线窄格展示用）
 * 换算基准为 computeStageDates 产出的 plan_start/plan_end（addDays 用 Date 自动跨月跨年）
 */
function shortDate(str) {
  if (!str) return ''
  const s = String(str).slice(0, 10)
  return s.length >= 10 ? s.slice(5) : s
}

/** 起止日期 → 短区间标签：'MM-DD' 或 'MM-DD~MM-DD'（无空格，适配窄格） */
function shortRange(start, end) {
  if (!start) return ''
  const s = shortDate(start)
  if (!end || String(end) === String(start)) return s
  return s + '~' + shortDate(end)
}

/** 起止日期 → 完整区间标签：'YYYY-MM-DD' 或 'YYYY-MM-DD ~ YYYY-MM-DD' */
function fullRange(start, end) {
  if (!start) return ''
  if (!end || String(end) === String(start)) return String(start).slice(0, 10)
  return String(start).slice(0, 10) + ' ~ ' + String(end).slice(0, 10)
}

/** 材料上报窗口：D-15 ~ D-13 */
function materialWindowOpen(stagesWithDates, dayStr) {
  const s = stagesWithDates.find(x => x.es_stage_key === 'D-15')
  const e = stagesWithDates.find(x => x.es_stage_key === 'D-13')
  return s && e && s.plan_start <= dayStr && dayStr <= e.plan_start
}

module.exports = { parseDate, fmtDate, addDays, computeStageDates, daysBetween, stageOfDay, materialWindowOpen, shortDate, shortRange, fullRange }
