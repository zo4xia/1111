/** 从单个页面快捷取全局 app 与作用域数据 */
function ctx() {
  const app = getApp()
  return { app, g: app.globalData, s: app.scoped() }
}

/** 展示名：来源枚举 → 中文 */
function sourceLabel(v) { return v === 'self' ? '个人自荐' : '组织推荐' }

/** 四轮审核展示色 */
function roundType(v) {
  if (v === '通过' || v === '当选') return 'ok'
  if (v === '不通过') return 'bad'
  if (v === '预选未入围') return 'warn'
  if (v === '待审') return 'doing'
  return 'none'
}

/** 候选状态展示色 */
function statusType(v) {
  if (['当选', '正式候选人'].includes(v)) return 'ok'
  if (['联审不通过', '初审退出', '考察不通过'].includes(v)) return 'bad'
  if (['预选未入围', '落选'].includes(v)) return 'warn'
  if (v && v.indexOf('待') === 0) return 'doing'
  return 'none'
}

module.exports = { ctx, sourceLabel, roundType, statusType }
