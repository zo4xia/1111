export interface ApiResponse<T = unknown> {
  code: number;
  data: T;
  message: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ListResponse<T> {
  items: T[];
  total: number;
}

export interface ListQueryParams {
  page?: number;
  pageSize?: number;
}

export const API_ERROR_CODES = {
  SUCCESS: 0,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL_ERROR: 500,
} as const;

export type OrgType = 'platform' | 'community_committee' | 'village_committee';

export interface Organization {
  id: string;
  slug: string;
  name: string;
  town: string;
  type: OrgType;
  status: string;
}

export type ElectionStatus = 'in_progress' | 'archived' | string;

export interface Election {
  id: string;
  orgId: string;
  term: string;
  name: string;
  status: ElectionStatus;
  electionDate: string;
  method: string;
  proposalId: string;
}

export interface ElectionListItem {
  id: string;
  term: string;
  name: string;
  status: string;
  electionDate: string;
  method: string;
}

export type StageStatus = '未开始' | '办理中' | '已完成' | string;

export interface ElectionStage {
  id: string;
  stageKey: string;
  stageName: string;
  offsetStart: number;
  offsetEnd: number;
  planStart: string;
  planEnd: string;
  status: StageStatus;
  bizModule: string;
  note: string;
}

// 提案相关
export type ProposalStatus =
  | 'draft'
  | 'pending'
  | 'approved'
  | 'rejected'
  | string;

export interface Proposal {
  id: string;
  orgId: string;
  electionId: string;
  title: string;
  method: string;
  creatorId: string;
  status: ProposalStatus;
  version: number;
  submitTime: string;
  reviewerId: string;
  reviewTime: string;
  reviewComment: string;
}

export interface ProposalDetail extends Proposal {
  content: string;
}

export interface ProposalCreateDto {
  title: string;
  method: string;
  content?: string;
  orgId?: string;
  electionId?: string;
}

export interface ProposalUpdateDto {
  title?: string;
  method?: string;
  content?: string;
}

export interface ProposalRejectDto {
  comment: string;
}

export interface ProposalStats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
}

export interface WorkstationData {
  orgInfo: { name: string; town: string; type: string };
  currentElection: { id: string; name: string; term: string; status: string; electionDate: string } | null;
  elections: Array<{ id: string; name: string; term: string; status: string; method: string }>;
  stages: Array<{
    stageKey: string;
    stageName: string;
    status: StageStatus;
    planStart: string;
    planEnd: string;
    order: number;
  }>;
  proposals: Array<{
    id: string;
    title: string;
    status: ProposalStatus;
    version: number;
  }>;
  positions: Array<{
    id: string;
    type: PositionType;
    quota: number;
    status: PositionStatus;
  }>;
  roster: Array<{
    id: string;
    position: string;
    name: string;
    phone: string;
    term: string;
  }>;
  stats: {
    pendingMaterials: number;
    passedCandidates: number;
    publishedAnnouncements: number;
    archives: number;
  };
}

// 岗位相关
export type PositionStatus = 'active' | 'inactive' | string;

export type PositionType = '主任' | '副主任' | '委员' | string;

export interface Position {
  id: string;
  orgId: string;
  electionId: string;
  type: PositionType;
  quota: number;
  status: PositionStatus;
  description: string;
}

export interface PositionCreateDto {
  type: string;
  quota: number;
  description?: string;
  orgId?: string;
  electionId?: string;
}

export interface PositionUpdateDto {
  type?: string;
  quota?: number;
  description?: string;
  status?: string;
}

export interface PositionStats {
  total: number;
  totalQuota: number;
  directorCount: number;
  viceDirectorCount: number;
  memberCount: number;
}

export type AnnouncementStatus =
  | 'draft'
  | 'pending_publish'
  | 'published'
  | 'correction'
  | 'frozen';

export interface Announcement {
  id: string;
  orgId: string;
  electionId: string;
  code: string;
  title: string;
  stageKey: string;
  status: AnnouncementStatus;
  version: number;
  editor: string;
  publishTime: string;
}

export interface AnnouncementDetail extends Announcement {
  content: string;
  reviewer: string;
  editTime: string;
  reviewTime: string;
  reviewComment: string;
  publicityDeadline: string;
}

export type VoterStatus = '已确认' | '待审核' | '已更正' | '已取消' | string;

export type VoterSource = 'registered' | 'self' | 'org_recommend' | string;

export type VoterMaterialStatus =
  | 'none'
  | 'submitted'
  | 'resubmitted'
  | 'needs_correction'
  | 'approved'
  | 'rejected'
  | string;

export interface Voter {
  id: string;
  orgId: string;
  electionId: string;
  name: string;
  gender: string;
  age: number;
  idCard: string;
  phone: string;
  householdAddr: string;
  residenceAddr: string;
  status: VoterStatus;
  registerTime: string;
  note: string;
  source: VoterSource;
  positionId: string;
  materialStatus: VoterMaterialStatus;
}

export interface VoterStats {
  total: number;
  maleCount: number;
  femaleCount: number;
}

export type CandidateSource = 'self' | 'org_recommend' | string;

export interface Candidate {
  id: string;
  orgId: string;
  electionId: string;
  name: string;
  gender: string;
  age: number;
  position: string;
  source: CandidateSource;
  r1Status: string;
  r2Status: string;
  r3Status: string;
  r4Status: string;
  status: string;
  votes: number;
}

export interface CandidateDetail extends Candidate {
  idCard: string;
  phone: string;
  r1Reviewer?: string;
  r1Time?: string;
  r1Comment?: string;
  r2Reviewer?: string;
  r2Time?: string;
  r2Comment?: string;
  r3Reviewer?: string;
  r3Time?: string;
  r3Comment?: string;
  r4Reviewer?: string;
  r4Time?: string;
  r4Comment?: string;
}

export interface CandidateCreateDto {
  name: string;
  gender?: string;
  age?: number;
  position?: string;
  source?: string;
  orgId: string;
  electionId: string;
  idCard?: string;
  phone?: string;
}

export interface CandidateUpdateDto {
  name?: string;
  gender?: string;
  age?: number;
  position?: string;
  source?: string;
  idCard?: string;
  phone?: string;
}

export type MaterialStatus =
  | 'submitted'
  | 'needs_correction'
  | 'resubmitted'
  | 'approved'
  | 'rejected'
  | string;

export interface Material {
  id: string;
  orgId: string;
  electionId: string;
  applicantId: string;
  applicant: string;
  position: string;
  type: string;
  submitter: string;
  submitTime: string;
  status: MaterialStatus;
  reviewer: string;
  stage: string;
}

export interface MaterialDetail extends Material {
  applicantPhone: string;
  content: string;
  reviewTime: string;
  reviewComment: string;
  candidateId: string;
  submitterPhone: string;
  note: string;
}

export interface MaterialStats {
  submitted: number;
  needsCorrection: number;
  resubmitted: number;
  approved: number;
  rejected: number;
  total: number;
}

export interface MaterialReviewDto {
  action: 'approve' | 'reject' | 'need_correction';
  comment?: string;
}

// 选举结果相关
export interface ElectionResultOverview {
  electionDate: string;
  eligibleVoters: number;
  actualVoters: number;
  validVotes: number;
  invalidVotes: number;
  turnout: string;
}

export interface ElectionResultCandidate {
  id: string;
  name: string;
  votes: number;
  voteRate: string;
  isElected: boolean;
}

export interface ElectionResult {
  id: string;
  orgId: string;
  orgName: string;
  electionId: string;
  electionDate: string;
  position: string;
  winnerName: string;
  votes: number;
  eligibleVoters: number;
  actualVoters: number;
  validVotes: number;
  invalidVotes: number;
  turnout: string;
  resultAnnCode: string;
  filingStatus: string;
  filingTime: string;
  handoverStatus: string;
  note: string;
  candidates: ElectionResultCandidate[];
}

export interface ElectionResultCreateDto {
  electionId: string;
  orgId: string;
  position: string;
  candidateVotes: Array<{ candidateId: string; votes: number }>;
  validVotes: number;
  invalidVotes: number;
  actualVoters: number;
  winnerName?: string;
  note?: string;
  resultAnnCode?: string;
}

export interface ElectionResultUpdateDto {
  position?: string;
  winnerName?: string;
  votes?: number;
  validVotes?: number;
  invalidVotes?: number;
  actualVoters?: number;
  eligibleVoters?: number;
  resultAnnCode?: string;
  note?: string;
}

export interface ElectionResultFilingDto {
  filingStatus: string;
  filingTime?: string;
}

export interface ElectionResultHandoverDto {
  handoverStatus: string;
}

// 归档相关
export type ArchiveVisibility = 'public' | 'internal' | 'private' | string;

export interface Archive {
  id: string;
  orgId: string;
  electionId: string;
  sourceType: string;
  sourceId: string;
  displayName: string;
  fileVersion: string;
  visibility: ArchiveVisibility;
}

export interface ArchiveDetail extends Archive {
  sourceData?: Record<string, unknown>;
}

export interface ArchiveCreateDto {
  displayName: string;
  sourceType: string;
  sourceId?: string;
  fileVersion?: string;
  visibility?: ArchiveVisibility;
  orgId?: string;
  electionId?: string;
}

export interface ArchiveUpdateDto {
  displayName?: string;
  sourceType?: string;
  sourceId?: string;
  fileVersion?: string;
  visibility?: ArchiveVisibility;
}

export interface ArchiveStats {
  total: number;
  publicCount: number;
  internalCount: number;
  privateCount: number;
}

// 公告模板
export interface AnnouncementTemplate {
  id: string;
  code: string;
  name: string;
  version: string;
  content: string;
  needRemind: boolean;
  note: string;
}

// 花名册
export interface RosterItem {
  id: string;
  orgId: string;
  position: string;
  name: string;
  phone: string;
  term: string;
  yearStart: string;
  yearEnd: string;
  status: string;
  isActive: boolean;
  sessionNo: string;
  note: string;
}

export interface RosterCreateDto {
  orgId: string;
  position: string;
  name: string;
  phone: string;
  term: string;
  yearStart: string;
  yearEnd: string;
  status: string;
  isActive: boolean;
  sessionNo: string;
  note?: string;
}

export interface RosterUpdateDto {
  position?: string;
  name?: string;
  phone?: string;
  term?: string;
  yearStart?: string;
  yearEnd?: string;
  status?: string;
  isActive?: boolean;
  sessionNo?: string;
  note?: string;
}

export interface RosterStats {
  total: number;
  activeCount: number;
  terms: string[];
}

// 通知
export interface Notification {
  id: string;
  orgId: string;
  electionId: string;
  type: string;
  content: string;
  toRoleFilter: string;
  toPhones: string;
  status: string;
  scheduledAt: string;
  sourceType: string;
  sourceKey: string;
}

// 系统配置
export interface SystemConfig {
  smsAppId: string;
  smsAppKey: string;
  appName: string;
  mcpServerUrl: string;
  mcpServerKey: string;
}

export interface SystemInfo {
  appName: string;
  appVersion: string;
  environment: 'preview' | 'production';
  currentUser: string;
}

// 选举结果扩展（含备案/交接状态）
export interface ElectionResultFiling {
  filingStatus: string;
  filingTime: string;
  handoverStatus: string;
  note: string;
}

export type RoleKey =
  | 'platform_admin'
  | 'sub_admin'
  | 'operator'
  | 'editor'
  | 'reviewer'
  | 'voters';

export interface Role {
  id: string;
  key: RoleKey;
  name: string;
  scope: 'platform' | 'organization';
  description: string;
  permissions: string[];
}

export interface Account {
  id: string;
  orgId: string;
  name: string;
  phone: string;
  passwordHint: string;
  orgName: string;
  roleKey: RoleKey;
  status: string;
  createdBy: string;
  note: string;
}

export interface LoginRequest {
  phone: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  account: Account;
  roleKey: RoleKey;
  visibleOrgs: Organization[];
  canEditDate: boolean;
  canReview: boolean;
}

export interface AuthUser {
  accountId: string;
  phone: string;
  roleKey: RoleKey;
  orgId: string;
}
