import { Building2, Vote, LogOut, UserCircle } from 'lucide-react';
import { useElection } from '@client/src/contexts/ElectionContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import { Button } from '@client/src/components/ui/button';

const ROLE_LABELS: Record<string, string> = {
  platform_admin: '平台超管',
  sub_admin: '子管理员',
  operator: '经办',
  editor: '编辑',
  reviewer: '审核',
  voters: '选民',
};

const Topbar = () => {
  const {
    organizations,
    currentOrg,
    currentElection,
    switchOrg,
    loading,
    account,
    roleKey,
    onLogout,
  } = useElection();

  if (loading || !currentOrg) {
    return (
      <header className="h-14 flex items-center justify-between px-4 bg-background border-b border-border">
        <div className="flex items-center gap-4">
          <div className="text-sm text-muted-foreground">加载中...</div>
        </div>
      </header>
    );
  }

  return (
    <header className="h-14 flex items-center justify-between px-4 bg-background border-b border-border">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Building2 size={16} className="text-muted-foreground" />
          <Select value={currentOrg.id} onValueChange={switchOrg}>
            <SelectTrigger size="sm" className="w-56 border-0 h-8 shadow-none px-0 hover:bg-accent/50 focus-visible:ring-0">
              <SelectValue />
            </SelectTrigger>
            <SelectContent align="start">
              {organizations.map((org) => (
                <SelectItem key={org.id} value={org.id}>
                  {org.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="text-border">|</div>
        <div className="flex items-center gap-2 text-sm">
          <Vote size={16} className="text-primary" />
          <span className="font-medium text-primary">
            {currentElection ? currentElection.name : '暂无进行中选举'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 h-8 hover:bg-accent"
            >
              <UserCircle size={18} className="text-muted-foreground" />
              <span className="text-sm">
                {account?.name || '操作员'}
              </span>
              <span className="text-xs text-muted-foreground">
                {ROLE_LABELS[roleKey] || roleKey}
              </span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>
              <div className="font-medium">{account?.name}</div>
              <div className="text-xs text-muted-foreground font-normal">
                {account?.phone}
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={onLogout}
              className="text-[hsl(0_65%_50%)] cursor-pointer"
            >
              <LogOut size={14} className="mr-2" />
              退出登录
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Topbar;
