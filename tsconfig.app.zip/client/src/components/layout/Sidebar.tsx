import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Calendar,
  ListTodo,
  Users,
  Briefcase,
  FolderOpen,
  UserCheck,
  Bell,
  Trophy,
  Archive,
  Shield,
  ScrollText,
  Settings,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useElection } from '@client/src/contexts/ElectionContext';
import type { RoleKey } from '@shared/api.interface';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

interface NavItem {
  path: string;
  label: string;
  icon: React.ElementType;
  roles?: RoleKey[];
}

const NAV_ITEMS: NavItem[] = [
  { path: '/', label: '仪表盘', icon: LayoutDashboard },
  { path: '/proposal', label: '提案管理', icon: FileText },
  { path: '/elections', label: '选举活动管理', icon: ListTodo },
  { path: '/election', label: '选举阶段', icon: Calendar },
  { path: '/voter', label: '参选人管理', icon: Users },
  { path: '/position', label: '岗位管理', icon: Briefcase },
  { path: '/material', label: '材料管理', icon: FolderOpen },
  { path: '/candidate', label: '候选人管理', icon: UserCheck },
  { path: '/notice', label: '公告管理', icon: Bell },
  { path: '/result', label: '选举结果', icon: Trophy },
  { path: '/archive', label: '归档管理', icon: Archive },
  {
    path: '/user',
    label: '用户管理',
    icon: Shield,
    roles: ['platform_admin', 'sub_admin'],
  },
  {
    path: '/log',
    label: '日志管理',
    icon: ScrollText,
    roles: ['platform_admin', 'sub_admin'],
  },
  {
    path: '/config',
    label: '系统配置',
    icon: Settings,
    roles: ['platform_admin', 'sub_admin'],
  },
];

const Sidebar = ({ collapsed, onToggle }: SidebarProps) => {
  const { roleKey } = useElection();

  const visibleItems = NAV_ITEMS.filter((item) => {
    if (!item.roles) return true;
    return item.roles.includes(roleKey as RoleKey);
  });

  return (
    <aside
      className={`flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-all duration-200 ${
        collapsed ? 'w-16' : 'w-60'
      }`}
    >
      <div
        className={`flex items-center h-14 px-4 border-b border-sidebar-border ${
          collapsed ? 'justify-center' : 'justify-between'
        }`}
      >
        {!collapsed && (
          <div className="font-bold text-base tracking-wide">
            城厢区村居换届选举
          </div>
        )}
        {collapsed && <div className="font-bold text-sm">城选</div>}
        <button
          onClick={onToggle}
          className="p-1 rounded hover:bg-sidebar-accent text-sidebar-foreground"
          aria-label="toggle sidebar"
        >
          {collapsed ? (
            <ChevronRight size={18} />
          ) : (
            <ChevronLeft size={18} />
          )}
        </button>
      </div>
      <nav className="flex-1 py-2 overflow-y-auto">
        {visibleItems.map((item: NavItem) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 mx-2 mb-0.5 px-3 py-2.5 text-sm relative transition-colors rounded-sm ${
                  isActive
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                    : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                } ${collapsed ? 'justify-center' : ''}`
              }
              title={collapsed ? item.label : undefined}
            >
              <Icon size={18} className="shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          );
        })}
      </nav>
      {!collapsed && (
        <div className="p-3 text-xs text-sidebar-foreground/60 border-t border-sidebar-border">
          v1.0.0 · 2026 换届选举
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
