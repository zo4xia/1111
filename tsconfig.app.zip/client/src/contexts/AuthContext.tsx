import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { authApi, getToken, setToken, clearToken } from '@client/src/api/auth';
import type { Account, Organization, RoleKey } from '@shared/api.interface';

interface AuthState {
  account: Account | null;
  roleKey: RoleKey | '';
  visibleOrgs: Organization[];
  canEditDate: boolean;
  canReview: boolean;
  loading: boolean;
  authenticated: boolean;
}

interface AuthContextValue extends AuthState {
  login: (phone: string, password: string) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const defaultState: AuthState = {
  account: null,
  roleKey: '',
  visibleOrgs: [],
  canEditDate: false,
  canReview: false,
  loading: true,
  authenticated: false,
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(defaultState);

  const loadAuth = useCallback(async () => {
    const token = getToken();
    if (!token) {
      setState((prev) => ({ ...prev, loading: false, authenticated: false }));
      return;
    }
    try {
      const data = await authApi.getMe();
      setToken(data.token || token);
      setState({
        account: data.account,
        roleKey: data.roleKey,
        visibleOrgs: data.visibleOrgs,
        canEditDate: data.canEditDate,
        canReview: data.canReview,
        loading: false,
        authenticated: true,
      });
    } catch (err) {
      logger.error(`加载登录状态失败: ${(err as Error).message}`);
      clearToken();
      setState({ ...defaultState, loading: false });
    }
  }, []);

  useEffect(() => {
    loadAuth();
  }, [loadAuth]);

  const login = useCallback(async (phone: string, password: string) => {
    const data = await authApi.login({ phone, password });
    setToken(data.token);
    setState({
      account: data.account,
      roleKey: data.roleKey,
      visibleOrgs: data.visibleOrgs,
      canEditDate: data.canEditDate,
      canReview: data.canReview,
      loading: false,
      authenticated: true,
    });
  }, []);

  const logout = useCallback(() => {
    clearToken();
    setState({ ...defaultState, loading: false });
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      ...state,
      login,
      logout,
      refresh: loadAuth,
    }),
    [state, login, logout, loadAuth],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return ctx;
}
