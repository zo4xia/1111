import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { electionApi } from '@client/src/api/election';
import type {
  Organization,
  Election,
  OrgType,
  Account,
  RoleKey,
} from '@shared/api.interface';

interface ElectionContextValue {
  organizations: Organization[];
  elections: Election[];
  currentOrg: Organization | null;
  currentElection: Election | null;
  loading: boolean;
  switchOrg: (orgId: string) => void;
  switchElection: (electionId: string) => void;
  getTerminology: (type: OrgType) => { villager: string; committee: string };
  account: Account | null;
  roleKey: RoleKey | '';
  canEditDate: boolean;
  canReview: boolean;
  isPlatformAdmin: boolean;
  visibleOrgs: Organization[];
  onLogout: () => void;
}

interface ElectionProviderProps {
  children: ReactNode;
  authAccount: Account | null;
  authRoleKey: RoleKey | '';
  canEditDate: boolean;
  canReview: boolean;
  visibleOrgs: Organization[];
  onLogout: () => void;
}

const ElectionContext = createContext<ElectionContextValue | null>(null);

const TERMINOLOGY: Record<OrgType, { villager: string; committee: string }> = {
  village_committee: { villager: '村民', committee: '村民委员会' },
  community_committee: { villager: '居民', committee: '居民委员会' },
  platform: { villager: '选民', committee: '选举委员会' },
};

export function ElectionProvider({
  children,
  authAccount,
  authRoleKey,
  canEditDate,
  canReview,
  visibleOrgs,
  onLogout,
}: ElectionProviderProps) {
  const [elections, setElections] = useState<Election[]>([]);
  const [currentOrg, setCurrentOrg] = useState<Organization | null>(null);
  const [currentElection, setCurrentElection] = useState<Election | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const organizations = visibleOrgs;
  const isPlatformAdmin = authRoleKey === 'platform_admin';

  useEffect(() => {
    if (visibleOrgs.length === 0) {
      setLoading(false);
      setCurrentOrg(null);
      setCurrentElection(null);
      return;
    }
    const firstOrg =
      visibleOrgs.find((o) => o.type !== 'platform') || visibleOrgs[0];
    setCurrentOrg(firstOrg || null);
  }, [visibleOrgs]);

  useEffect(() => {
    if (!currentOrg) return;
    let mounted = true;

    (async () => {
      try {
        const [current, listResp] = await Promise.all([
          electionApi.getCurrent(currentOrg.slug),
          electionApi.list(currentOrg.slug),
        ]);
        if (!mounted) return;
        setCurrentElection(current);
        setElections(listResp.items || []);
      } catch (err) {
        logger.error(`加载选举数据失败: ${(err as Error).message}`);
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [currentOrg]);

  const switchOrg = useCallback(
    (orgId: string) => {
      const org = organizations.find((o) => o.id === orgId);
      if (org) {
        setLoading(true);
        setCurrentOrg(org);
        setCurrentElection(null);
        setElections([]);
      }
    },
    [organizations],
  );

  const switchElection = useCallback(
    (electionId: string) => {
      const election = elections.find((e) => e.id === electionId);
      if (election) {
        setCurrentElection(election);
      }
    },
    [elections],
  );

  const getTerminology = useCallback((type: OrgType) => {
    return TERMINOLOGY[type] ?? TERMINOLOGY.village_committee;
  }, []);

  const value = useMemo<ElectionContextValue>(
    () => ({
      organizations,
      elections,
      currentOrg,
      currentElection,
      loading,
      switchOrg,
      switchElection,
      getTerminology,
      account: authAccount,
      roleKey: authRoleKey,
      canEditDate,
      canReview,
      isPlatformAdmin,
      visibleOrgs,
      onLogout,
    }),
    [
      organizations,
      elections,
      currentOrg,
      currentElection,
      loading,
      switchOrg,
      switchElection,
      getTerminology,
      authAccount,
      authRoleKey,
      canEditDate,
      canReview,
      isPlatformAdmin,
      visibleOrgs,
      onLogout,
    ],
  );

  return (
    <ElectionContext.Provider value={value}>
      {children}
    </ElectionContext.Provider>
  );
}

export function useElection() {
  const ctx = useContext(ElectionContext);
  if (!ctx) {
    throw new Error('useElection must be used within ElectionProvider');
  }
  return ctx;
}
