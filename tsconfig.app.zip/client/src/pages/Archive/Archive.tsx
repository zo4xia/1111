import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';
import { toast } from 'sonner';
import {
  Archive as ArchiveIcon,
  FileText,
  Eye,
  Edit2,
  Trash2,
  Plus,
  RotateCcw,
  Search,
} from 'lucide-react';
import {
  Button,
  Tag,
  Card,
  Input,
  Select,
  Table,
  Space,
  Row,
  Col,
  Statistic,
  Segmented,
} from 'antd';
import {
  InboxOutlined,
  EyeOutlined,
  TeamOutlined,
  LockOutlined,
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { archiveApi } from '@client/src/api/archive';
import type { Archive, ArchiveStats } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import { ArchiveFormDialog } from './ArchiveFormDialog';
import { ArchiveDetailDialog } from './ArchiveDetailDialog';

const CATEGORIES = [
  { value: '', label: '全部归档' },
  { value: 'proposal', label: '提案' },
  { value: 'position', label: '岗位' },
  { value: 'material', label: '材料' },
  { value: 'announcement', label: '公告' },
  { value: 'candidate', label: '候选人' },
  { value: 'result', label: '选举结果' },
  { value: 'stage_evidence', label: '阶段凭证' },
];

const SOURCE_LABELS: Record<string, string> = {
  proposal: '提案',
  position: '岗位',
  material: '材料',
  announcement: '公告',
  candidate: '候选人',
  result: '选举结果',
  stage_evidence: '阶段凭证',
  other: '其他',
};

const VISIBILITY_OPTIONS = [
  { value: '', label: '全部可见性' },
  { value: 'public', label: '公开' },
  { value: 'internal', label: '内部' },
  { value: 'private', label: '私密' },
];

const getVisibilityColor = (visibility: string): string => {
  if (visibility === 'public' || visibility === '公开') return 'success';
  if (visibility === 'private' || visibility === '私密') return 'error';
  return 'processing';
};

const getVisibilityLabel = (visibility: string): string => {
  if (visibility === 'public' || visibility === '公开') return '公开';
  if (visibility === 'private' || visibility === '私密') return '私密';
  return '内部';
};

const ArchivePage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [activeCategory, setActiveCategory] = useState<string>('');
  const [archives, setArchives] = useState<Archive[]>([]);
  const [stats, setStats] = useState<ArchiveStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [visibilityFilter, setVisibilityFilter] = useState<string>('');

  const [detailOpen, setDetailOpen] = useState<boolean>(false);
  const [detail, setDetail] = useState<Archive | null>(null);
  const [detailLoading, setDetailLoading] = useState<boolean>(false);

  const [createOpen, setCreateOpen] = useState<boolean>(false);
  const [createLoading, setCreateLoading] = useState<boolean>(false);

  const [editOpen, setEditOpen] = useState<boolean>(false);
  const [editingArchive, setEditingArchive] = useState<Archive | null>(null);
  const [editLoading, setEditLoading] = useState<boolean>(false);

  const loadData = useCallback(async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const listParams = {
        orgId: currentOrg.id,
        electionId: currentElection?.id,
        sourceType: activeCategory || undefined,
        visibility: visibilityFilter || undefined,
      };
      const [listData, statsData] = await Promise.all([
        archiveApi.list(listParams),
        archiveApi.stats({
          orgId: currentOrg.id,
          electionId: currentElection?.id,
        }),
      ]);
      setArchives(listData.items);
      setStats(statsData);
    } catch (err) {
      logger.error(`加载归档数据失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [currentOrg, currentElection, activeCategory, visibilityFilter]);

  useEffect(() => {
    if (!currentOrg) return;
    loadData();
  }, [loadData]);

  const handleViewDetail = async (item: Archive) => {
    setDetailLoading(true);
    setDetailOpen(true);
    setDetail(item);
    try {
      const data = await archiveApi.detail(item.id);
      setDetail(data);
    } catch (err) {
      logger.error(`加载归档详情失败: ${(err as Error).message}`);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleCreateSubmit = async (data: {
    displayName: string;
    sourceType: string;
    sourceId: string;
    fileVersion: string;
    visibility: string;
  }) => {
    setCreateLoading(true);
    try {
      await archiveApi.create({
        ...data,
        orgId: currentOrg?.id,
        electionId: currentElection?.id,
      });
      setCreateOpen(false);
      toast.success('归档创建成功');
      await loadData();
    } catch (err) {
      logger.error(`创建归档失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '创建失败');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleEditSubmit = async (data: {
    displayName: string;
    sourceType: string;
    sourceId: string;
    fileVersion: string;
    visibility: string;
  }) => {
    if (!editingArchive) return;
    setEditLoading(true);
    try {
      await archiveApi.update(editingArchive.id, data);
      setEditOpen(false);
      toast.success('归档更新成功');
      await loadData();
    } catch (err) {
      logger.error(`更新归档失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '更新失败');
    } finally {
      setEditLoading(false);
    }
  };

  const handleDelete = async (item: Archive) => {
    if (
      !(await showConfirm(
        `确定删除归档"${item.displayName}"吗？此操作不可撤销。`,
      ))
    )
      return;
    try {
      await archiveApi.remove(item.id);
      toast.success('归档已删除');
      await loadData();
    } catch (err) {
      logger.error(`删除归档失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '删除失败');
    }
  };

  const handleRestore = async (item: Archive) => {
    if (!(await showConfirm(`确定还原归档"${item.displayName}"吗？`))) return;
    try {
      await archiveApi.restore(item.id);
      toast.success('归档已还原');
      await loadData();
    } catch (err) {
      logger.error(`还原归档失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '还原失败');
    }
  };

  const filtered = archives.filter((a) =>
    a.displayName.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  if (ctxLoading || !currentOrg) {
    return (
      <div className="space-y-4">
        <div className="text-sm text-muted-foreground">加载中...</div>
      </div>
    );
  }

  const columns: ColumnsType<Archive> = [
    {
      title: '文件名称',
      dataIndex: 'displayName',
      key: 'displayName',
      render: (v: string) => (
        <Space size={8}>
          <FileText size={14} className="text-muted-foreground flex-shrink-0" />
          <span className="font-medium">{v}</span>
        </Space>
      ),
    },
    {
      title: '来源类型',
      dataIndex: 'sourceType',
      key: 'sourceType',
      width: 120,
      render: (v: string) => (
        <Tag>{SOURCE_LABELS[v] || v}</Tag>
      ),
    },
    {
      title: '文件版本',
      dataIndex: 'fileVersion',
      key: 'fileVersion',
      width: 100,
      render: (v: string) => <span className="font-mono text-xs">{v}</span>,
    },
    {
      title: '可见性',
      dataIndex: 'visibility',
      key: 'visibility',
      width: 100,
      render: (v: string) => (
        <Tag color={getVisibilityColor(v)}>{getVisibilityLabel(v)}</Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 260,
      align: 'right' as const,
      render: (_, record) => (
        <Space size={4} wrap>
          <Button
            type="text"
            size="small"
            icon={<Eye size={14} />}
            onClick={() => handleViewDetail(record)}
          >
            查看
          </Button>
          <Button
            type="text"
            size="small"
            icon={<Edit2 size={14} />}
            onClick={() => {
              setEditingArchive(record);
              setEditOpen(true);
            }}
          >
            编辑
          </Button>
          <Button
            type="text"
            size="small"
            icon={<RotateCcw size={14} />}
            onClick={() => handleRestore(record)}
          >
            还原
          </Button>
          <Button
            type="text"
            size="small"
            danger
            icon={<Trash2 size={14} />}
            onClick={() => handleDelete(record)}
          >
            删除
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '归档管理' }]} />
      {/* 标题 */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">归档管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            选举相关资料的归档、查看与管理
          </p>
        </div>
        <Button
          type="primary"
          icon={<Plus size={16} />}
          onClick={() => setCreateOpen(true)}
        >
          新建归档
        </Button>
      </div>

      {/* 统计卡片 */}
      <Row gutter={[12, 12]} data-ai-section-type="card-stat">
        <Col xs={12} md={6}>
          <Card size="small">
            <Statistic
              title="归档总数"
              value={stats?.total ?? 0}
              prefix={<InboxOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card size="small">
            <Statistic
              title="公开"
              value={stats?.publicCount ?? 0}
              prefix={<EyeOutlined />}
              valueStyle={{ color: '#2D8B55' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card size="small">
            <Statistic
              title="内部"
              value={stats?.internalCount ?? 0}
              prefix={<TeamOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card size="small">
            <Statistic
              title="私密"
              value={stats?.privateCount ?? 0}
              prefix={<LockOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
      </Row>

      {/* 分类 + 搜索 + 列表 */}
      <Card
        size="small"
        title={
          <Segmented
            value={activeCategory}
            onChange={setActiveCategory}
            options={CATEGORIES.map((c) => ({ label: c.label, value: c.value }))}
            size="small"
          />
        }
        extra={
          <Space size={8}>
            <Input
              placeholder="搜索归档文件"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              prefix={<Search size={14} className="text-muted-foreground" />}
              style={{ width: 220 }}
              allowClear
            />
            <Select
              value={visibilityFilter}
              onChange={setVisibilityFilter}
              style={{ width: 140 }}
              size="middle"
              options={VISIBILITY_OPTIONS.map((v) => ({
                label: v.label,
                value: v.value,
              }))}
            />
          </Space>
        }
        styles={{ body: { padding: 0 } }}
      >
        <Table
          rowKey="id"
          columns={columns}
          dataSource={filtered}
          loading={loading}
          pagination={{
            pageSize: 10,
            showSizeChanger: false,
            showTotal: (total) => `共 ${total} 条`,
          }}
          size="middle"
          locale={{
            emptyText: (
              <div className="py-12 text-center text-muted-foreground">
                <ArchiveIcon size={32} className="mx-auto mb-3 opacity-40" />
                <div className="text-sm">暂无归档数据</div>
              </div>
            ),
          }}
        />
      </Card>

      <ArchiveDetailDialog
        open={detailOpen}
        onOpenChange={setDetailOpen}
        detail={detail as unknown as import('@shared/api.interface').ArchiveDetail | null}
        detailLoading={detailLoading}
      />

      <ArchiveFormDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        mode="create"
        loading={createLoading}
        onSubmit={handleCreateSubmit}
      />

      <ArchiveFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        mode="edit"
        archive={editingArchive}
        loading={editLoading}
        onSubmit={handleEditSubmit}
      />
    </div>
  );
};

export default ArchivePage;
