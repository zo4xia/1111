import { useState, useEffect } from 'react';
import { Modal, Form, Input, Select, Button, Row, Col } from 'antd';
import type { Archive } from '@shared/api.interface';

const SOURCE_TYPE_OPTIONS = [
  'proposal',
  'position',
  'material',
  'announcement',
  'candidate',
  'result',
  'stage_evidence',
  'other',
];

const SOURCE_LABELS: Record<string, string> = {
  proposal: '提案',
  position: '岗位',
  material: '材料',
  announcement: '公告',
  candidate: '候选人',
  result: '选举结果',
  stage_evidence: '阶段凭证',
  other: '其他',
};

const VISIBILITY_OPTIONS = [
  { key: 'public', label: '公开' },
  { key: 'internal', label: '内部' },
  { key: 'private', label: '私密' },
];

interface ArchiveFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  archive?: Archive | null;
  loading?: boolean;
  onSubmit: (data: {
    displayName: string;
    sourceType: string;
    sourceId: string;
    fileVersion: string;
    visibility: string;
  }) => void;
}

export function ArchiveFormDialog({
  open,
  onOpenChange,
  mode,
  archive,
  loading = false,
  onSubmit,
}: ArchiveFormDialogProps) {
  const [form] = Form.useForm();

  useEffect(() => {
    if (open) {
      if (mode === 'edit' && archive) {
        form.setFieldsValue({
          displayName: archive.displayName,
          sourceType: archive.sourceType,
          sourceId: archive.sourceId,
          fileVersion: archive.fileVersion,
          visibility: archive.visibility,
        });
      } else {
        form.resetFields();
        form.setFieldsValue({
          sourceType: 'proposal',
          fileVersion: 'v1.0',
          visibility: 'internal',
        });
      }
    }
  }, [open, mode, archive, form]);

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      onSubmit({
        displayName: values.displayName.trim(),
        sourceType: values.sourceType,
        sourceId: values.sourceId || '',
        fileVersion: values.fileVersion,
        visibility: values.visibility,
      });
    } catch {
      // validation error
    }
  };

  return (
    <Modal
      open={open}
      title={mode === 'create' ? '新建归档' : '编辑归档'}
      onCancel={() => onOpenChange(false)}
      footer={[
        <Button key="cancel" onClick={() => onOpenChange(false)}>
          取消
        </Button>,
        <Button
          key="submit"
          type="primary"
          loading={loading}
          onClick={handleOk}
        >
          {mode === 'create' ? '创建' : '保存'}
        </Button>,
      ]}
      width={520}
      destroyOnClose
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          sourceType: 'proposal',
          fileVersion: 'v1.0',
          visibility: 'internal',
        }}
      >
        <Form.Item
          label="归档名称"
          name="displayName"
          rules={[{ required: true, message: '请输入归档显示名称' }]}
        >
          <Input placeholder="请输入归档显示名称" />
        </Form.Item>
        <Form.Item label="来源类型" name="sourceType">
          <Select placeholder="请选择来源类型">
            {SOURCE_TYPE_OPTIONS.map((key) => (
              <Select.Option key={key} value={key}>
                {SOURCE_LABELS[key] || key}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Row gutter={12}>
          <Col span={12}>
            <Form.Item label="来源ID" name="sourceId">
              <Input placeholder="选填" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item label="文件版本" name="fileVersion">
              <Input placeholder="v1.0" />
            </Form.Item>
          </Col>
        </Row>
        <Form.Item label="可见性" name="visibility">
          <Select placeholder="请选择可见性">
            {VISIBILITY_OPTIONS.map((v) => (
              <Select.Option key={v.key} value={v.key}>
                {v.label}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
      </Form>
    </Modal>
  );
}

export default ArchiveFormDialog;
