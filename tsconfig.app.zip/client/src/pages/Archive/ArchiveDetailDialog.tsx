import { Download } from 'lucide-react';
import { toast } from 'sonner';
import { Modal, Tag, Button, Descriptions, Space } from 'antd';
import type { ArchiveDetail } from '@shared/api.interface';

const SOURCE_LABELS: Record<string, string> = {
  proposal: '提案',
  position: '岗位',
  material: '材料',
  announcement: '公告',
  candidate: '候选人',
  result: '选举结果',
  stage_evidence: '阶段凭证',
  other: '其他',
};

function VisibilityTag({ visibility }: { visibility: string }) {
  let label = '内部';
  let color = 'default';

  if (visibility === 'public' || visibility === '公开') {
    label = '公开';
    color = 'success';
  } else if (visibility === 'private' || visibility === '私密') {
    label = '私密';
    color = 'error';
  } else if (visibility === 'internal' || visibility === '内部') {
    label = '内部';
    color = 'processing';
  }

  return <Tag color={color}>{label}</Tag>;
}

interface ArchiveDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  detail: ArchiveDetail | null;
  detailLoading?: boolean;
}

export function ArchiveDetailDialog({
  open,
  onOpenChange,
  detail,
  detailLoading = false,
}: ArchiveDetailDialogProps) {
  return (
    <Modal
      open={open}
      title="归档详情"
      onCancel={() => onOpenChange(false)}
      width={700}
      destroyOnClose
      footer={
        <Space>
          <Button onClick={() => onOpenChange(false)}>关闭</Button>
          <Button
            type="text"
            disabled={!detail}
            icon={<Download size={14} />}
            onClick={() => toast.info('下载功能待接入')}
          >
            下载
          </Button>
        </Space>
      }
    >
      {detailLoading || !detail ? (
        <div className="p-8 text-center text-sm text-muted-foreground">
          加载中...
        </div>
      ) : (
        <div className="space-y-4">
          <Descriptions column={2} bordered size="small">
            <Descriptions.Item label="文件名称" span={2}>
              <span className="font-medium">{detail.displayName}</span>
            </Descriptions.Item>
            <Descriptions.Item label="来源类型">
              {SOURCE_LABELS[detail.sourceType] || detail.sourceType}
            </Descriptions.Item>
            <Descriptions.Item label="可见性">
              <VisibilityTag visibility={detail.visibility} />
            </Descriptions.Item>
            <Descriptions.Item label="文件版本">
              <span className="font-mono">{detail.fileVersion}</span>
            </Descriptions.Item>
            <Descriptions.Item label="来源ID">
              {detail.sourceId || '-'}
            </Descriptions.Item>
          </Descriptions>

          {detail.sourceData &&
            Object.keys(detail.sourceData).length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-muted-foreground font-medium">
                  来源数据
                </div>
                <div className="bg-[#FAF8F5] border border-[#E5E1DB] rounded p-3 text-xs font-mono overflow-x-auto max-h-60 overflow-y-auto">
                  <pre className="m-0">
                    {JSON.stringify(detail.sourceData, null, 2)}
                  </pre>
                </div>
              </div>
            )}
        </div>
      )}
    </Modal>
  );
}

export default ArchiveDetailDialog;
