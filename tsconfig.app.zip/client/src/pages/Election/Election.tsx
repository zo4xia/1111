import { useState, useEffect, useMemo } from 'react';
import dayjs from 'dayjs';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Calendar as CalendarIcon,
  Plus,
  FileText,
  Upload,
  Users,
  Megaphone,
  ClipboardCheck,
} from 'lucide-react';
import {
  Button,
  Tag,
  Card,
  Select,
  DatePicker,
  Space,
  Table,
  Tooltip,
  Row,
  Col,
  Statistic,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { electionStageApi } from '@client/src/api/election-stages';
import { electionApi } from '@client/src/api/election';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import type { ElectionStage, StageStatus } from '@shared/api.interface';

const STATUS_STYLE: Record<StageStatus, { color: string; label: string }> = {
  '未开始': { color: 'default', label: '未开始' },
  '办理中': { color: 'processing', label: '办理中' },
  '已完成': { color: 'success', label: '已完成' },
};

const STATUS_FLOW: StageStatus[] = ['未开始', '办理中', '已完成'];

interface StageWithDates extends ElectionStage {
  planStart: string;
  planEnd: string;
  days: number;
}

function getNextStatus(current: StageStatus): StageStatus | null {
  const idx = STATUS_FLOW.indexOf(current);
  if (idx < STATUS_FLOW.length - 1) {
    return STATUS_FLOW[idx + 1];
  }
  return null;
}

const ElectionPage = () => {
  const { currentOrg, currentElection, elections, switchElection, loading: ctxLoading, canEditDate } = useElection();
  const [stages, setStages] = useState<ElectionStage[]>([]);
  const [stagesLoading, setStagesLoading] = useState<boolean>(false);
  const [stats, setStats] = useState({
    voters: 0,
    materials: 0,
    announcements: 0,
    stagesCompleted: 0,
  });

  useEffect(() => {
    if (!currentElection) {
      setStages([]);
      return;
    }
    let mounted = true;
    (async () => {
      setStagesLoading(true);
      try {
        const data = await electionStageApi.list(currentElection.id);
        setStages(data.items || []);
      } catch (err) {
        logger.error(`加载阶段列表失败: ${(err as Error).message}`);
      } finally {
        if (mounted) setStagesLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [currentElection]);

  const stagesWithDates: StageWithDates[] = useMemo(() => {
    if (!currentElection?.electionDate) {
      return stages.map((s) => ({ ...s, planStart: '', planEnd: '', days: 0 }));
    }
    const dDay = dayjs(currentElection.electionDate);
    return stages.map((stage) => {
      const start = dDay.add(stage.offsetStart, 'day');
      const end = dDay.add(stage.offsetEnd, 'day');
      return {
        ...stage,
        planStart: start.format('YYYY-MM-DD'),
        planEnd: end.format('YYYY-MM-DD'),
        days: Math.max(1, end.diff(start, 'day') + 1),
      };
    });
  }, [stages, currentElection]);

  useEffect(() => {
    if (stages.length > 0) {
      setStats((prev) => ({
        ...prev,
        stagesCompleted: stages.filter((s) => s.status === '已完成').length,
      }));
    }
  }, [stages]);

  const handleDateChange = async (date: dayjs.Dayjs | null) => {
    if (!date || !currentElection) return;
    const dateStr = date.format('YYYY-MM-DD');
    if (dateStr === currentElection.electionDate) {
      return;
    }
    try {
      const updated = await electionApi.updateElectionDate(currentElection.id, dateStr);
      if (updated?.id) {
        switchElection(updated.id);
      }
      setStages([...stages]);
    } catch (err) {
      logger.error(`修改D日失败: ${(err as Error).message}`);
    }
  };

  const handleStatusAdvance = async (stageId: string, nextStatus: StageStatus) => {
    try {
      const updated = await electionStageApi.updateStatus(stageId, nextStatus);
      setStages((prev) =>
        prev.map((s) => (s.id === stageId ? updated : s)),
      );
    } catch (err) {
      logger.error(`更新阶段状态失败: ${(err as Error).message}`);
    }
  };

  if (ctxLoading) {
    return <div className="text-sm text-muted-foreground py-12">加载中...</div>;
  }

  if (!currentOrg) {
    return (
      <div className="space-y-4">
        <PageBreadcrumb items={[{ label: '选举活动管理', href: '/elections' }, { label: '活动详情' }]} />
        <Card className="text-center">
          <div className="py-12 text-muted-foreground text-sm">暂无组织数据</div>
        </Card>
      </div>
    );
  }

  if (!currentElection) {
    return (
      <div className="space-y-4">
        <PageBreadcrumb items={[{ label: '选举活动管理', href: '/elections' }, { label: '活动详情' }]} />
        <div>
          <h1 className="text-xl font-bold text-foreground">选举届次管理</h1>
          <p className="text-sm text-muted-foreground mt-1">当前组织暂无进行中的选举</p>
        </div>
        <Card className="text-center">
          <div className="py-12 text-muted-foreground text-sm">请先创建或切换到进行中的选举</div>
        </Card>
      </div>
    );
  }

  const columns: ColumnsType<StageWithDates> = [
    {
      title: '#',
      dataIndex: 'order',
      key: 'order',
      width: 50,
      render: (_: number, __, index) => <span className="text-muted-foreground font-mono text-xs">{index + 1}</span>,
    },
    {
      title: '阶段名称',
      dataIndex: 'stageName',
      key: 'stageName',
      render: (v: string, record) => (
        <Space size={8}>
          <span
            className="font-mono text-xs px-1.5 py-0.5 rounded"
            style={{ background: '#FDF6E3', color: '#8c1f28' }}
          >
            {record.stageKey}
          </span>
          <span className="font-medium">{v}</span>
          <Tag color={STATUS_STYLE[record.status]?.color || 'default'}>
            {STATUS_STYLE[record.status]?.label || record.status}
          </Tag>
        </Space>
      ),
    },
    {
      title: '开始日期',
      dataIndex: 'planStart',
      key: 'planStart',
      width: 120,
      render: (v: string) => (
        <span className="text-xs font-mono text-muted-foreground">{v || '—'}</span>
      ),
    },
    {
      title: '结束日期',
      dataIndex: 'planEnd',
      key: 'planEnd',
      width: 120,
      render: (v: string) => (
        <span className="text-xs font-mono text-muted-foreground">{v || '—'}</span>
      ),
    },
    {
      title: '天数',
      dataIndex: 'days',
      key: 'days',
      width: 70,
      render: (v: number) => (
        <span className="text-xs font-mono text-foreground">{v} 天</span>
      ),
    },
    {
      title: '核心工作',
      dataIndex: 'description',
      key: 'description',
      render: (v: string) => v || <span className="text-muted-foreground text-xs">—</span>,
    },
    {
      title: '关联材料',
      key: 'materials',
      width: 100,
      render: () => (
        <Tag color="default" className="text-xs">
          <FileText size={10} className="inline mr-1" />0
        </Tag>
      ),
    },
    {
      title: '上传文件',
      key: 'files',
      width: 100,
      render: () => (
        <Tag color="default" className="text-xs">
          <Upload size={10} className="inline mr-1" />0
        </Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 160,
      align: 'right',
      render: (_, record) => {
        const nextStatus = getNextStatus(record.status);
        if (!nextStatus) {
          return <Tag color="success">已完成</Tag>;
        }
        return (
          <Space size={4}>
            <Tooltip title={nextStatus === '办理中' ? '开始办理' : '标记完成'}>
              <Button
                type={record.status === '未开始' ? 'primary' : 'default'}
                size="small"
                onClick={() => handleStatusAdvance(record.id, nextStatus)}
              >
                {nextStatus === '办理中' ? '开始办理' : '标记完成'}
              </Button>
            </Tooltip>
          </Space>
        );
      },
    },
  ];

  const completedCount = stagesWithDates.filter((s) => s.status === '已完成').length;
  const totalCount = stagesWithDates.length;

  return (
    <div className="space-y-4">
      <PageBreadcrumb
        items={[
          { label: '选举活动管理', href: '/elections' },
          { label: `${currentElection.term || ''}${currentElection.name || '换届选举'}` },
        ]}
      />

      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-xl font-bold text-foreground m-0">
            {currentElection.name}
          </h1>
          <p className="text-sm text-muted-foreground mt-1 mb-0">
            共 {stages.length} 个阶段，基于 D 日倒排工期
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">选举届次：</span>
          <Select
            value={currentElection.id}
            onChange={(val) => switchElection(val)}
            style={{ width: 220 }}
            size="middle"
          >
            {elections.map((e) => (
              <Select.Option key={e.id} value={e.id}>
                {e.name}
              </Select.Option>
            ))}
          </Select>
        </div>
      </div>

      <Row gutter={16}>
        <Col span={6}>
          <Card size="small">
            <Statistic
              title="参选人数"
              value={stats.voters}
              suffix="人"
              prefix={<Users size={16} style={{ color: '#1677ff' }} />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small">
            <Statistic
              title="材料提交数"
              value={stats.materials}
              suffix="份"
              prefix={<FileText size={16} style={{ color: '#faad14' }} />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small">
            <Statistic
              title="公告数"
              value={stats.announcements}
              suffix="条"
              prefix={<Megaphone size={16} style={{ color: '#52c41a' }} />}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card size="small">
            <Statistic
              title="阶段完成数"
              value={`${completedCount}/${totalCount}`}
              prefix={<ClipboardCheck size={16} style={{ color: '#8c1f28' }} />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
      </Row>

      <Card
        title="16 阶段倒排工期"
        size="small"
        extra={
          <Space size={8}>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">D 日：</span>
              <DatePicker
                value={currentElection.electionDate ? dayjs(currentElection.electionDate) : null}
                onChange={handleDateChange}
                disabled={!canEditDate}
                format="YYYY-MM-DD"
                suffixIcon={<CalendarIcon size={14} />}
                style={{ fontFamily: 'monospace' }}
              />
            </div>
            <Button type="primary" size="small" icon={<Plus size={14} />}>
              新增阶段
            </Button>
          </Space>
        }
      >
        <Table
          rowKey="id"
          columns={columns}
          dataSource={stagesWithDates}
          loading={stagesLoading}
          pagination={false}
          size="small"
          locale={{
            emptyText: (
              <div className="py-12 text-center text-muted-foreground text-sm">
                暂无阶段数据
              </div>
            ),
          }}
        />
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-[#EEECE6] text-xs text-muted-foreground">
          <span>图例：</span>
          <Tag color="default">未开始</Tag>
          <Tag color="processing">办理中</Tag>
          <Tag color="success">已完成</Tag>
          <Tag color="warning">已锁定</Tag>
        </div>
      </Card>
    </div>
  );
};

export default ElectionPage;
