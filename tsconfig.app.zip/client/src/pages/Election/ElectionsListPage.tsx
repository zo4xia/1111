import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { FileText, Eye, Calendar } from 'lucide-react';
import { Table, Tag, Card, Button, Select, Space, Input } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { electionApi } from '@client/src/api/election';
import type { Election } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';

const STATUS_LABEL: Record<string, string> = {
  active: '进行中',
  archived: '已归档',
  draft: '草稿',
};

const STATUS_COLOR: Record<string, string> = {
  active: 'red',
  archived: 'default',
  draft: 'default',
};

const ELECTION_MODE_OPTIONS = [
  { value: '', label: '全部选举方式' },
  { value: 'direct', label: '直选' },
  { value: 'indirect', label: '间接选举' },
];

const YEAR_OPTIONS = [
  { value: '', label: '全部年份' },
  { value: '2026', label: '2026年' },
  { value: '2021', label: '2021年' },
  { value: '2016', label: '2016年' },
];

const STATUS_OPTIONS = [
  { value: '', label: '全部状态' },
  { value: 'active', label: '进行中' },
  { value: 'archived', label: '已归档' },
];

const ElectionsPage = () => {
  const { currentOrg } = useElection();
  const navigate = useNavigate();
  const [elections, setElections] = useState<Election[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [modeFilter, setModeFilter] = useState<string>('');
  const [yearFilter, setYearFilter] = useState<string>('');
  const [keyword, setKeyword] = useState<string>('');

  const loadList = async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const result = await electionApi.list(currentOrg.id);
      setElections(result.items || []);
    } catch (err) {
      logger.error(`加载选举列表失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadList();
  }, [currentOrg]);

  const filtered = elections.filter((item) => {
    if (statusFilter && item.status !== statusFilter) return false;
    if (modeFilter && item.method !== modeFilter) return false;
    if (yearFilter && !item.term?.includes(yearFilter)) return false;
    if (keyword && !item.name?.includes(keyword)) return false;
    return true;
  });

  const columns: ColumnsType<Election> = [
    {
      title: '届次',
      dataIndex: 'term',
      key: 'term',
      width: 120,
      render: (v) => v || '-',
    },
    {
      title: '活动名称',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
      render: (v) => v || '-',
    },
    {
      title: '选举方式',
      dataIndex: 'method',
      key: 'method',
      width: 120,
      render: (v) => {
        if (!v) return '-';
        return v === 'direct' ? '直选' : v === 'indirect' ? '间接选举' : v;
      },
    },
    {
      title: 'D日',
      dataIndex: 'electionDate',
      key: 'electionDate',
      width: 140,
      render: (v) => v || '-',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (v) => (
        <Tag color={STATUS_COLOR[v] || 'default'}>
          {STATUS_LABEL[v] || v}
        </Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      align: 'right',
      render: (_, record) => (
        <Space size={4}>
          <Button
            type="primary"
            size="small"
            icon={<Eye size={14} />}
            onClick={() => navigate('/election')}
          >
            进入管理
          </Button>
          <Button size="small" icon={<FileText size={14} />}>
            查看
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '选举活动管理' }]} />

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">选举活动管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            历届换届选举活动总览，可切换进入不同届次管理
          </p>
        </div>
      </div>

      <Card size="small" className="bg-card border border-border">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm text-muted-foreground">届次：</span>
          <Select
            value={yearFilter || undefined}
            onChange={setYearFilter}
            style={{ width: 140 }}
            size="small"
            options={YEAR_OPTIONS}
            placeholder="选择年份"
            allowClear
          />
          <span className="text-sm text-muted-foreground ml-1">选举方式：</span>
          <Select
            value={modeFilter || undefined}
            onChange={setModeFilter}
            style={{ width: 140 }}
            size="small"
            options={ELECTION_MODE_OPTIONS}
            placeholder="选择方式"
            allowClear
          />
          <span className="text-sm text-muted-foreground ml-1">状态：</span>
          <Select
            value={statusFilter || undefined}
            onChange={setStatusFilter}
            style={{ width: 140 }}
            size="small"
            options={STATUS_OPTIONS}
            placeholder="选择状态"
            allowClear
          />
          <div className="flex-1" />
          <Input.Search
            placeholder="搜索活动名称"
            size="small"
            style={{ width: 220 }}
            onSearch={setKeyword}
            allowClear
          />
        </div>
      </Card>

      <Card size="small" className="!p-0">
        <Table<Election>
          rowKey="id"
          columns={columns}
          dataSource={filtered}
          loading={loading}
          pagination={{ pageSize: 10, size: 'small' }}
          size="small"
          locale={{ emptyText: '暂无选举活动' }}
          scroll={{ x: 800 }}
        />
      </Card>
    </div>
  );
};

export default ElectionsPage;
