import { useState, useEffect } from 'react';
import { Modal, Form, Input, Select, Button } from 'antd';
import type { Proposal } from '@shared/api.interface';

const METHOD_OPTIONS = ['举手表决', '无记名投票', '差额选举', '直选', '户代表', '居民代表'];

interface ProposalFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  proposal?: Proposal | null;
  loading?: boolean;
  onSubmit: (data: { title: string; method: string; content?: string }) => void;
}

export function ProposalFormDialog({
  open,
  onOpenChange,
  mode,
  proposal,
  loading = false,
  onSubmit,
}: ProposalFormDialogProps) {
  const [form] = Form.useForm();

  useEffect(() => {
    if (open) {
      if (mode === 'edit' && proposal) {
        form.setFieldsValue({
          title: proposal.title,
          method: proposal.method || '举手表决',
          content: '',
        });
      } else {
        form.resetFields();
        form.setFieldsValue({ method: '举手表决' });
      }
    }
  }, [open, mode, proposal, form]);

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      onSubmit({
        title: values.title.trim(),
        method: values.method,
        content: values.content,
      });
    } catch {
      // validation error
    }
  };

  return (
    <Modal
      open={open}
      title={mode === 'create' ? '新建选举提案' : '编辑提案'}
      onCancel={() => onOpenChange(false)}
      footer={[
        <Button key="cancel" onClick={() => onOpenChange(false)}>
          取消
        </Button>,
        <Button
          key="submit"
          type="primary"
          loading={loading}
          onClick={handleOk}
        >
          保存
        </Button>,
      ]}
      width={600}
      destroyOnClose
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{ method: '举手表决' }}
      >
        <Form.Item
          label="提案标题"
          name="title"
          rules={[{ required: true, message: '请输入提案标题' }]}
        >
          <Input placeholder="请输入提案标题" />
        </Form.Item>
        <Form.Item label="选举方式" name="method">
          <Select placeholder="请选择选举方式">
            {METHOD_OPTIONS.map((m) => (
              <Select.Option key={m} value={m}>
                {m}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item label="提案说明" name="content">
          <Input.TextArea
            placeholder="请输入提案说明（可选）"
            autoSize={{ minRows: 4, maxRows: 8 }}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
}

export default ProposalFormDialog;
