import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';
import { toast } from 'sonner';
import {
  Plus,
  FileText,
  Edit2,
  Trash2,
  Send,
  Eye,
  FileCheck,
} from 'lucide-react';
import {
  Button,
  Tag,
  Card,
  Tabs,
  Table,
  Alert,
  Statistic,
  Space,
  Row,
  Col,
  Segmented,
} from 'antd';
import {
  FileTextOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons';
import { useElection } from '@client/src/contexts/ElectionContext';
import { proposalApi } from '@client/src/api/proposal';
import type { Proposal, ProposalDetail, ProposalStats } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import { ProposalFormDialog } from './ProposalFormDialog';
import { ProposalReviewDialog } from './ProposalReviewDialog';

const STATUS_TABS = [
  { key: '', label: '全部' },
  { key: 'draft', label: '草稿' },
  { key: 'pending', label: '待审核' },
  { key: 'approved', label: '已通过' },
  { key: 'rejected', label: '已驳回' },
];

const STATUS_COLOR: Record<string, string> = {
  draft: 'default',
  pending: 'processing',
  approved: 'success',
  rejected: 'error',
};

const STATUS_LABEL: Record<string, string> = {
  draft: '草稿',
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

function formatDate(value: string): string {
  if (!value) return '-';
  try {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
  } catch {
    return value;
  }
}

const ProposalPage = () => {
  const { currentOrg, currentElection } = useElection();
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [stats, setStats] = useState<ProposalStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('');

  const [createOpen, setCreateOpen] = useState<boolean>(false);
  const [createLoading, setCreateLoading] = useState<boolean>(false);

  const [editOpen, setEditOpen] = useState<boolean>(false);
  const [editingProp, setEditingProp] = useState<Proposal | null>(null);
  const [editLoading, setEditLoading] = useState<boolean>(false);

  const [detailOpen, setDetailOpen] = useState<boolean>(false);
  const [detail, setDetail] = useState<ProposalDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState<boolean>(false);

  const loadData = useCallback(async () => {
    if (!currentOrg) return;
    setLoading(true);
    setError(null);
    try {
      const listParams = {
        orgId: currentOrg.id,
        electionId: currentElection?.id,
        status: activeTab || undefined,
      };
      const [listData, statsData] = await Promise.all([
        proposalApi.list(listParams),
        proposalApi.stats({
          orgId: currentOrg.id,
          electionId: currentElection?.id,
        }),
      ]);
      setProposals(listData.items);
      setStats(statsData);
    } catch (err) {
      logger.error(`加载提案数据失败: ${(err as Error).message}`);
      setError((err as Error).message || '加载失败');
    } finally {
      setLoading(false);
    }
  }, [currentOrg, currentElection, activeTab]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleCreateSubmit = async (data: {
    title: string;
    method: string;
    content?: string;
  }) => {
    setCreateLoading(true);
    try {
      await proposalApi.create({
        ...data,
        orgId: currentOrg?.id,
        electionId: currentElection?.id,
      });
      setCreateOpen(false);
      toast.success('提案创建成功');
      await loadData();
    } catch (err) {
      logger.error(`创建提案失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '创建失败');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleEditSubmit = async (data: {
    title: string;
    method: string;
    content?: string;
  }) => {
    if (!editingProp) return;
    setEditLoading(true);
    try {
      await proposalApi.update(editingProp.id, data);
      setEditOpen(false);
      toast.success('提案更新成功');
      await loadData();
    } catch (err) {
      logger.error(`更新提案失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '更新失败');
    } finally {
      setEditLoading(false);
    }
  };

  const handleLoadDetail = async (id: string) => {
    setDetailLoading(true);
    try {
      const data = await proposalApi.detail(id);
      setDetail(data);
    } catch (err) {
      logger.error(`加载提案详情失败: ${(err as Error).message}`);
      setDetail(null);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleViewDetail = (p: Proposal) => {
    setDetail(p as unknown as ProposalDetail);
    setDetailOpen(true);
    handleLoadDetail(p.id);
  };

  const handleSubmit = async (p: Proposal) => {
    if (!(await showConfirm(`确定提交提案"${p.title}"进行审核？`))) return;
    try {
      await proposalApi.submit(p.id);
      toast.success('提案已提交审核');
      await loadData();
    } catch (err) {
      logger.error(`提交提案失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '提交失败');
    }
  };

  const handleDelete = async (p: Proposal) => {
    if (
      !(await showConfirm(`确定删除提案"${p.title}"吗？此操作不可撤销。`))
    )
      return;
    try {
      await proposalApi.remove(p.id);
      toast.success('提案已删除');
      await loadData();
    } catch (err) {
      logger.error(`删除提案失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '删除失败');
    }
  };

  const handleApprove = async (id: string) => {
    await proposalApi.approve(id);
    setDetailOpen(false);
    await loadData();
  };

  const handleReject = async (id: string, comment: string) => {
    await proposalApi.reject(id, comment);
    setDetailOpen(false);
    await loadData();
  };

  const tableColumns = [
    {
      title: '提案标题',
      dataIndex: 'title',
      key: 'title',
      render: (text: string, record: Proposal) => (
        <Space direction="vertical" size={2}>
          <span className="font-medium">{text}</span>
          <Space size={8}>
            <Tag color={STATUS_COLOR[record.status] || 'default'}>
              {STATUS_LABEL[record.status] || '草稿'}
            </Tag>
          </Space>
        </Space>
      ),
    },
    {
      title: '选举方式',
      dataIndex: 'method',
      key: 'method',
      width: 120,
      render: (v: string) => v || '-',
    },
    {
      title: '版本',
      dataIndex: 'version',
      key: 'version',
      width: 80,
      render: (v: number) => <span className="font-mono">V{v}</span>,
    },
    {
      title: '提交时间',
      dataIndex: 'submitTime',
      key: 'submitTime',
      width: 140,
      render: (v: string) => formatDate(v),
    },
    {
      title: '操作',
      key: 'action',
      width: 240,
      align: 'right' as const,
      render: (_: unknown, record: Proposal) => (
        <Space size={4}>
          {record.status === 'draft' && (
            <>
              <Button
                type="text"
                size="small"
                icon={<Edit2 size={14} />}
                onClick={() => {
                  setEditingProp(record);
                  setEditOpen(true);
                }}
              >
                编辑
              </Button>
              <Button
                type="primary"
                size="small"
                icon={<Send size={14} />}
                onClick={() => handleSubmit(record)}
              >
                提交审核
              </Button>
              <Button
                type="text"
                size="small"
                danger
                icon={<Trash2 size={14} />}
                onClick={() => handleDelete(record)}
              >
                删除
              </Button>
            </>
          )}
          {record.status === 'pending' && (
            <>
              <Button
                type="text"
                size="small"
                icon={<Eye size={14} />}
                onClick={() => handleViewDetail(record)}
              >
                查看
              </Button>
              <Button
                type="primary"
                size="small"
                icon={<FileCheck size={14} />}
                onClick={() => handleViewDetail(record)}
              >
                审核
              </Button>
            </>
          )}
          {(record.status === 'approved' || record.status === 'rejected') && (
            <Button
              type="text"
              size="small"
              icon={<Eye size={14} />}
              onClick={() => handleViewDetail(record)}
            >
              查看详情
            </Button>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '提案审批' }]} />
      {/* 角色视角切换 */}
      <Card size="small" className="mb-0">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">视角切换：</span>
          <Segmented
            options={[
              { label: '经办视角', value: 'operator' },
              { label: '审批视角', value: 'reviewer' },
            ]}
            defaultValue="operator"
            size="small"
          />
        </div>
      </Card>
      {/* 顶部标题区 */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">提案管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            选举提案的创建、提交与审核管理
          </p>
        </div>
        <Button
          type="primary"
          icon={<Plus size={16} />}
          onClick={() => setCreateOpen(true)}
        >
          新建提案
        </Button>
      </div>

      {error && (
        <Alert
          type="error"
          message={error}
          showIcon
          closable
          onClose={() => setError(null)}
        />
      )}

      {/* 统计卡片 */}
      <Row gutter={[12, 12]} data-ai-section-type="card-stat">
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="总提案数"
              value={stats?.total ?? 0}
              prefix={<FileTextOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="待审核"
              value={stats?.pending ?? 0}
              prefix={<ClockCircleOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="已通过"
              value={stats?.approved ?? 0}
              prefix={<CheckCircleOutlined />}
              valueStyle={{ color: '#2D8B55' }}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="已驳回"
              value={stats?.rejected ?? 0}
              prefix={<CloseCircleOutlined />}
              valueStyle={{ color: '#8c1f28' }}
            />
          </Card>
        </Col>
      </Row>

      {/* 状态 Tab + 列表 */}
      <Card
        styles={{ body: { padding: 0 } }}
        title={
          <Tabs
            activeKey={activeTab}
            onChange={setActiveTab}
            items={STATUS_TABS.map((tab) => ({
              key: tab.key || 'all',
              label: tab.label,
            }))}
            size="small"
          />
        }
      >
        <Table
          rowKey="id"
          columns={tableColumns}
          dataSource={proposals}
          loading={loading}
          pagination={{
            pageSize: 8,
            showSizeChanger: false,
            showTotal: (total) => `共 ${total} 条`,
          }}
          locale={{
            emptyText: (
              <div className="py-12 text-center text-muted-foreground">
                <FileText size={32} className="mx-auto mb-3 opacity-40" />
                <div className="text-sm">暂无提案数据</div>
              </div>
            ),
          }}
        />
      </Card>

      <ProposalFormDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        mode="create"
        loading={createLoading}
        onSubmit={handleCreateSubmit}
      />

      <ProposalFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        mode="edit"
        proposal={editingProp}
        loading={editLoading}
        onSubmit={handleEditSubmit}
      />

      <ProposalReviewDialog
        open={detailOpen}
        onOpenChange={setDetailOpen}
        detail={detail}
        detailLoading={detailLoading}
        onLoad={handleLoadDetail}
        onApprove={handleApprove}
        onReject={handleReject}
      />
    </div>
  );
};

export default ProposalPage;
