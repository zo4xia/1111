import { useState } from 'react';
import { XCircle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Modal, Tag, Input, Button, Space, Descriptions } from 'antd';
import type { ProposalDetail } from '@shared/api.interface';

const STATUS_COLOR: Record<string, string> = {
  draft: 'default',
  pending: 'processing',
  approved: 'success',
  rejected: 'error',
};

const STATUS_LABEL: Record<string, string> = {
  draft: '草稿',
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

function formatDate(value: string): string {
  if (!value) return '-';
  try {
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
  } catch {
    return value;
  }
}

interface ProposalReviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  detail: ProposalDetail | null;
  detailLoading?: boolean;
  onLoad: (id: string) => void;
  onApprove: (id: string) => Promise<void>;
  onReject: (id: string, comment: string) => Promise<void>;
}

export function ProposalReviewDialog({
  open,
  onOpenChange,
  detail,
  detailLoading = false,
  onLoad,
  onApprove,
  onReject,
}: ProposalReviewDialogProps) {
  const [reviewComment, setReviewComment] = useState('');
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const handleApprove = async () => {
    if (!detail) return;
    setActionLoading(true);
    try {
      await onApprove(detail.id);
      setReviewComment('');
      toast.success('审核通过成功');
    } catch (err) {
      logger.error(`审核通过失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '操作失败');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    if (!detail) return;
    if (!reviewComment.trim()) {
      toast.warning('请填写驳回意见');
      return;
    }
    setActionLoading(true);
    try {
      await onReject(detail.id, reviewComment.trim());
      setReviewComment('');
      toast.success('已驳回');
    } catch (err) {
      logger.error(`驳回失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '操作失败');
    } finally {
      setActionLoading(false);
    }
  };

  const handleOpenChange = (val: boolean) => {
    if (!val) {
      setReviewComment('');
    }
    onOpenChange(val);
  };

  // 加载详情
  const handleEnter = () => {
    if (detail) onLoad(detail.id);
  };

  const statusColor = detail
    ? STATUS_COLOR[detail.status] || 'default'
    : 'default';
  const statusLabel = detail
    ? STATUS_LABEL[detail.status] || '草稿'
    : '草稿';

  return (
    <Modal
      open={open}
      title={detail ? detail.title : '提案详情'}
      onCancel={() => handleOpenChange(false)}
      width={600}
      destroyOnClose
      afterOpenChange={(visible) => {
        if (visible) handleEnter();
      }}
      footer={
        detail && detail.status === 'pending' ? (
          <Space>
            <Button
              danger
              icon={<XCircle size={16} />}
              disabled={actionLoading || detailLoading}
              onClick={handleReject}
            >
              驳回
            </Button>
            <Button
              type="primary"
              icon={<CheckCircle size={16} />}
              disabled={actionLoading || detailLoading}
              onClick={handleApprove}
              style={{ backgroundColor: '#2D8B55', borderColor: '#2D8B55' }}
            >
              通过
            </Button>
          </Space>
        ) : (
          <Button onClick={() => onOpenChange(false)}>关闭</Button>
        )
      }
    >
      {detailLoading ? (
        <div className="py-8 text-center text-muted-foreground text-sm">
          加载中...
        </div>
      ) : !detail ? (
        <div className="py-8 text-center text-muted-foreground text-sm">
          加载失败
        </div>
      ) : (
        <div className="space-y-4">
          <Space size={8} align="center">
            <Tag color={statusColor}>{statusLabel}</Tag>
            <span className="text-xs text-muted-foreground">
              版本 V{detail.version}
            </span>
          </Space>

          <Descriptions column={2} size="small" bordered>
            <Descriptions.Item label="选举方式">
              {detail.method || '-'}
            </Descriptions.Item>
            <Descriptions.Item label="提交时间">
              {formatDate(detail.submitTime)}
            </Descriptions.Item>
          </Descriptions>

          {detail.content && (
            <div className="space-y-2">
              <div className="text-muted-foreground text-xs font-medium">
                提案说明
              </div>
              <div className="text-sm bg-[#FAF8F5] border border-[#E5E1DB] rounded p-3 min-h-[60px] whitespace-pre-wrap">
                {detail.content}
              </div>
            </div>
          )}

          {detail.reviewComment && (
            <div className="space-y-2">
              <div className="text-muted-foreground text-xs font-medium">
                审核意见
              </div>
              <div className="text-sm bg-[#FAF8F5] border border-[#E5E1DB] rounded p-3">
                {detail.reviewComment}
              </div>
            </div>
          )}

          {detail.status === 'pending' && (
            <div className="space-y-2 pt-4 border-t border-[#E5E1DB]">
              <label className="text-sm font-medium text-foreground">
                审核意见
              </label>
              <Input.TextArea
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="请输入审核意见（驳回时必填）"
                autoSize={{ minRows: 3, maxRows: 6 }}
              />
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}

export default ProposalReviewDialog;
