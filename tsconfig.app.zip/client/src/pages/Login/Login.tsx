import { useState, FormEvent } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { useAuth } from '@client/src/contexts/AuthContext';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Badge } from '@client/src/components/ui/badge';

const QUICK_ACCOUNTS = [
  { name: '张主任', phone: '13800000001', tag: '平台超管' },
  { name: '林建国', phone: '13800000005', tag: '涧口子管理' },
  { name: '李经办', phone: '13800000002', tag: '涧口经办' },
  { name: '王审核', phone: '13800000003', tag: '涧口审核' },
  { name: '赵运营', phone: '13800000004', tag: '涧口编辑' },
  { name: '吴春霖', phone: '13800000011', tag: '延寿子管理' },
];

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [phone, setPhone] = useState('13800000005');
  const [password, setPassword] = useState('123456');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const from = (location.state as { from?: string } | null)?.from || '/';

  const handleSubmit = async (e?: FormEvent) => {
    e?.preventDefault();
    setError('');
    if (!phone || !password) {
      setError('请输入手机号和密码');
      return;
    }
    setLoading(true);
    try {
      await login(phone, password);
      navigate(from, { replace: true });
    } catch (err) {
      logger.error(`登录失败: ${(err as Error).message}`);
      setError((err as Error).message || '登录失败');
    } finally {
      setLoading(false);
    }
  };

  const handleQuick = (acc: { phone: string }) => {
    setPhone(acc.phone);
    setPassword('123456');
    setError('');
    setLoading(true);
    login(acc.phone, '123456')
      .then(() => navigate(from, { replace: true }))
      .catch((err) => {
        setError((err as Error).message || '登录失败');
      })
      .finally(() => setLoading(false));
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-[hsl(217_65%_20%)] via-[hsl(217_60%_28%)] to-[hsl(217_50%_35%)] relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-[hsl(42_80%_50%/0.08)] blur-3xl" />
        <div className="absolute bottom-[-15%] left-[-10%] w-[600px] h-[600px] rounded-full bg-[hsl(217_60%_45%/0.15)] blur-3xl" />
      </div>

      <div className="relative z-10 w-[420px] bg-white rounded-sm shadow-xl p-8">
        <div className="text-center mb-6">
          <div className="w-14 h-14 mx-auto mb-3 rounded-sm bg-gradient-to-br from-[hsl(217_65%_32%)] to-[hsl(217_50%_45%)] flex items-center justify-center text-white text-2xl font-bold">
            换
          </div>
          <h1 className="text-xl font-bold text-[hsl(215_25%_17%)]">
            城厢区村居换届选举系统
          </h1>
          <p className="text-xs text-muted-foreground mt-1 tracking-wide">
            D日锚点 · 16阶段日程引擎 · 四轮审核状态机
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">手机号</label>
            <Input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="请输入手机号"
              autoComplete="username"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">密码</label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="演示统一密码 123456"
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="text-xs text-[hsl(0_65%_50%)] text-center bg-[hsl(0_55%_95%)] py-2 rounded-sm">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? '登录中...' : '登 录'}
          </Button>
        </form>

        <div className="my-5 flex items-center gap-2">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">演示账号一键登录</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <div className="flex flex-wrap gap-2 justify-center">
          {QUICK_ACCOUNTS.map((acc) => (
            <button
              key={acc.phone}
              type="button"
              onClick={() => handleQuick(acc)}
              className="px-3 py-1 text-xs border border-border rounded-sm hover:bg-accent hover:border-primary/30 transition-colors flex items-center gap-1"
            >
              <span className="text-foreground">{acc.name}</span>
              <Badge
                variant="outline"
                className="text-[10px] py-0 px-1 h-4 font-normal"
              >
                {acc.tag}
              </Badge>
            </button>
          ))}
        </div>

        <p className="text-[11px] text-muted-foreground text-center mt-6">
          数据与飞书多维表格同源 · 涧口社区居委会（进行中）+ 延寿村委会（已完结）
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
