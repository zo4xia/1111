import { useState, useEffect } from 'react';
import {
  SaveOutlined,
  EyeOutlined,
  EyeInvisibleOutlined,
  MessageOutlined,
  SettingOutlined,
  CloudServerOutlined,
  InfoCircleOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  ReloadOutlined,
} from '@ant-design/icons';
import { toast } from 'sonner';
import {
  Card,
  Button,
  Input,
  Descriptions,
  Space,
  Form,
  Row,
  Col,
  Tag,
} from 'antd';
import { configApi } from '@/api/config';
import type { SystemConfig, SystemInfo } from '@shared/api.interface';

const SECRET_MASK = '********';

interface TestStatus {
  sms: 'idle' | 'loading' | 'ok' | 'fail';
  postgres: 'idle' | 'loading' | 'ok' | 'fail';
}

const TestBadge = ({
  status,
  message,
}: {
  status: 'idle' | 'loading' | 'ok' | 'fail';
  message?: string;
}) => {
  if (status === 'idle') return null;
  if (status === 'loading') return <Tag icon={<ReloadOutlined spin />} color="default">测试中...</Tag>;
  if (status === 'ok') return <Tag icon={<CheckCircleOutlined />} color="success">连接正常</Tag>;
  return <Tag icon={<WarningOutlined />} color="error">连接失败</Tag>;
};

const SmsSection = ({
  config,
  onChange,
  onSave,
  saving,
  onTest,
  testStatus,
  testMessage,
}: {
  config: SystemConfig;
  onChange: (patch: Partial<SystemConfig>) => void;
  onSave: () => void;
  saving: boolean;
  onTest: () => void;
  testStatus: TestStatus['sms'];
  testMessage: string;
}) => {
  return (
    <Card
      title={
        <Space size={8}>
          <MessageOutlined style={{ color: '#8c1f28' }} />
          <span>短信服务配置</span>
          <TestBadge status={testStatus} message={testMessage} />
        </Space>
      }
      extra={
        <Space size={8}>
          <Button size="small" onClick={onTest} loading={testStatus === 'loading'}>
            发送测试短信
          </Button>
          <Button type="primary" onClick={onSave} loading={saving} size="small" icon={<SaveOutlined />}>
            保存
          </Button>
        </Space>
      }
    >
      <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 16, marginTop: -8 }}>
        配置短信服务商凭证，用于选举通知、验证码等短信发送
      </div>
      <Row gutter={16}>
        <Col span={12}>
          <Form.Item label="短信 App ID">
            <Input
              value={config.smsAppId}
              onChange={(e) => onChange({ smsAppId: e.target.value })}
              placeholder="请输入短信服务商 App ID"
            />
            <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 4 }}>
              短信平台应用 ID
            </div>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="短信 App Key">
            <Input.Password
              value={config.smsAppKey}
              onChange={(e) => onChange({ smsAppKey: e.target.value })}
              placeholder="请输入短信服务商 App Key"
            />
            <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 4 }}>
              短信平台应用密钥
            </div>
          </Form.Item>
        </Col>
      </Row>
      {testMessage && (testStatus === 'ok' || testStatus === 'fail') && (
        <div
          style={{
            padding: '8px 12px',
            borderRadius: 4,
            fontSize: 12,
            background: testStatus === 'ok' ? '#F0FDF4' : '#FEF2F2',
            color: testStatus === 'ok' ? '#166534' : '#991B1B',
            marginTop: 8,
          }}
        >
          {testMessage}
        </div>
      )}
    </Card>
  );
};

const McpSection = ({
  config,
  onChange,
  onSave,
  saving,
}: {
  config: SystemConfig;
  onChange: (patch: Partial<SystemConfig>) => void;
  onSave: () => void;
  saving: boolean;
}) => {
  return (
    <Card
      title={
        <Space size={8}>
          <CloudServerOutlined style={{ color: '#8c1f28' }} />
          <span>MCP Server 配置</span>
        </Space>
      }
      extra={
        <Button type="primary" onClick={onSave} loading={saving} size="small" icon={<SaveOutlined />}>
          保存
        </Button>
      }
    >
      <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 16, marginTop: -8 }}>
        配置 MCP 服务连接，用于外部能力扩展
      </div>
      <Row gutter={16}>
        <Col span={12}>
          <Form.Item label="MCP Server URL">
            <Input
              value={config.mcpServerUrl}
              onChange={(e) => onChange({ mcpServerUrl: e.target.value })}
              placeholder="https://mcp.example.com"
            />
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item label="MCP Server API Key">
            <Input.Password
              value={config.mcpServerKey}
              onChange={(e) => onChange({ mcpServerKey: e.target.value })}
              placeholder="请输入 MCP Server API Key"
            />
          </Form.Item>
        </Col>
      </Row>
    </Card>
  );
};

const SystemSection = ({
  config,
  onChange,
  onSave,
  saving,
}: {
  config: SystemConfig;
  onChange: (patch: Partial<SystemConfig>) => void;
  onSave: () => void;
  saving: boolean;
}) => {
  return (
    <Card
      title={
        <Space size={8}>
          <SettingOutlined style={{ color: '#8c1f28' }} />
          <span>系统基础配置</span>
        </Space>
      }
      extra={
        <Button type="primary" onClick={onSave} loading={saving} size="small" icon={<SaveOutlined />}>
          保存
        </Button>
      }
    >
      <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 16, marginTop: -8 }}>
        配置系统名称和展示信息
      </div>
      <Row gutter={16}>
        <Col span={12}>
          <Form.Item label="系统名称">
            <Input
              value={config.appName}
              onChange={(e) => onChange({ appName: e.target.value })}
              placeholder="请输入系统名称"
            />
            <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 4 }}>
              显示在登录页、侧边栏顶部等位置
            </div>
          </Form.Item>
        </Col>
      </Row>
    </Card>
  );
};

const InfoSection = ({ info, loading }: { info: SystemInfo | null; loading: boolean }) => {
  const items = info
    ? [
        { key: 'appVersion', label: '当前版本', children: info.appVersion },
        {
          key: 'environment',
          label: '环境',
          children: info.environment === 'production' ? '生产环境' : '预览环境',
        },
        { key: 'currentUser', label: '当前登录账号', children: info.currentUser },
      ]
    : [];

  return (
    <Card
      title={
        <Space size={8}>
          <InfoCircleOutlined style={{ color: '#8c1f28' }} />
          <span>系统信息</span>
        </Space>
      }
    >
      <div style={{ fontSize: 12, color: '#6B7280', marginBottom: 16, marginTop: -8 }}>
        只读展示，展示当前应用运行环境信息
      </div>
      {loading ? (
        <div style={{ fontSize: 13, color: '#6B7280' }}>加载中...</div>
      ) : (
        <Descriptions
          bordered
          size="small"
          column={1}
          items={items}
          labelStyle={{ width: 140, color: '#6B7280', fontSize: 12 }}
        />
      )}
    </Card>
  );
};

const SystemConfigPanel = () => {
  const [config, setConfig] = useState<SystemConfig>({
    smsAppId: '',
    smsAppKey: '',
    appName: '选举管理系统',
    mcpServerUrl: '',
    mcpServerKey: '',
  });
  const [info, setInfo] = useState<SystemInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [savingSms, setSavingSms] = useState(false);
  const [savingMcp, setSavingMcp] = useState(false);
  const [savingSystem, setSavingSystem] = useState(false);
  const [testStatus, setTestStatus] = useState<TestStatus>({
    sms: 'idle',
    postgres: 'idle',
  });
  const [testMessages, setTestMessages] = useState<Record<string, string>>({});

  useEffect(() => {
    void loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [cfg, sysInfo] = await Promise.all([
        configApi.getSystemConfig(),
        configApi.getSystemInfo(),
      ]);
      setConfig(cfg);
      setInfo(sysInfo);
    } catch (error) {
      toast.error('加载系统配置失败');
    } finally {
      setLoading(false);
    }
  };

  const handleConfigChange = (patch: Partial<SystemConfig>) => {
    setConfig((prev) => ({ ...prev, ...patch }));
  };

  const handleSaveSms = async () => {
    setSavingSms(true);
    try {
      const payload: Partial<SystemConfig> = {
        smsAppId: config.smsAppId,
      };
      if (config.smsAppKey !== SECRET_MASK) {
        payload.smsAppKey = config.smsAppKey;
      }
      const updated = await configApi.saveSystemConfig(payload);
      setConfig((prev) => ({ ...prev, ...updated }));
      toast.success('短信配置保存成功');
    } catch (error) {
      toast.error('保存失败，请重试');
    } finally {
      setSavingSms(false);
    }
  };

  const handleSaveMcp = async () => {
    setSavingMcp(true);
    try {
      const payload: Partial<SystemConfig> = {
        mcpServerUrl: config.mcpServerUrl,
      };
      if (config.mcpServerKey !== SECRET_MASK) {
        payload.mcpServerKey = config.mcpServerKey;
      }
      const updated = await configApi.saveSystemConfig(payload);
      setConfig((prev) => ({ ...prev, ...updated }));
      toast.success('MCP Server 配置保存成功');
    } catch (error) {
      toast.error('保存失败，请重试');
    } finally {
      setSavingMcp(false);
    }
  };

  const handleSaveSystem = async () => {
    setSavingSystem(true);
    try {
      const updated = await configApi.saveSystemConfig({
        appName: config.appName,
      });
      setConfig((prev) => ({ ...prev, ...updated }));
      toast.success('系统配置保存成功');
    } catch (error) {
      toast.error('保存失败，请重试');
    } finally {
      setSavingSystem(false);
    }
  };

  const handleTestSms = async () => {
    setTestStatus((prev) => ({ ...prev, sms: 'loading' }));
    try {
      const result = await configApi.testConnection('sms');
      setTestStatus((prev) => ({ ...prev, sms: result.ok ? 'ok' : 'fail' }));
      setTestMessages((prev) => ({ ...prev, sms: result.message }));
    } catch (error) {
      setTestStatus((prev) => ({ ...prev, sms: 'fail' }));
      setTestMessages((prev) => ({ ...prev, sms: (error as Error).message || '测试失败' }));
    }
  };

  return (
    <Space direction="vertical" size={16} style={{ width: '100%' }}>
      <SmsSection
        config={config}
        onChange={handleConfigChange}
        onSave={handleSaveSms}
        saving={savingSms}
        onTest={handleTestSms}
        testStatus={testStatus.sms}
        testMessage={testMessages.sms || ''}
      />
      <SystemSection
        config={config}
        onChange={handleConfigChange}
        onSave={handleSaveSystem}
        saving={savingSystem}
      />
      <McpSection
        config={config}
        onChange={handleConfigChange}
        onSave={handleSaveMcp}
        saving={savingMcp}
      />
      <InfoSection info={info} loading={loading} />
    </Space>
  );
};

export default SystemConfigPanel;
