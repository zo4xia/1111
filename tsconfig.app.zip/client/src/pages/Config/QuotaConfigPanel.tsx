import { useState, useEffect } from 'react';
import { SaveOutlined } from '@ant-design/icons';
import { toast } from 'sonner';
import {
  Table,
  Button,
  InputNumber,
  Select,
  Card,
  Space,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import type { Organization } from '@shared/api.interface';
import type { RoleDef } from '@/api/user';

const ROLE_DESC: Record<string, string> = {
  platform_admin: '拥有系统全部权限，可管理所有组织和用户',
  sub_admin: '管理指定组织内的用户与配置，仅次于平台管理员',
  reviewer: '负责候选人资格、材料、公告等内容的审核工作',
  operator: '负责日常业务操作，如选民登记、材料录入等',
  editor: '负责公告、通知等内容的编辑和发布',
  voter: '普通选民账号，仅可查看选举信息和投票',
};

interface Props {
  orgs: Organization[];
  roleDefs: RoleDef[];
  roleQuotas: Record<string, number>;
  onSave: (quotas: Record<string, number>) => void;
}

const QuotaConfigPanel = ({ orgs, roleDefs, roleQuotas, onSave }: Props) => {
  const [quotaOrg, setQuotaOrg] = useState<string>('');
  const [localQuotas, setLocalQuotas] = useState<Record<string, number>>({});

  useEffect(() => {
    if (orgs.length > 0 && !quotaOrg) {
      setQuotaOrg(orgs[0].slug);
    }
  }, [orgs, quotaOrg]);

  useEffect(() => {
    setLocalQuotas({ ...roleQuotas });
  }, [roleQuotas]);

  const handleChange = (roleKey: string, value: number | null) => {
    const num = value ?? 0;
    if (num >= 0) {
      setLocalQuotas({ ...localQuotas, [roleKey]: num });
    }
  };

  const handleSave = () => {
    onSave(localQuotas);
    toast.success('角色配额保存成功（演示环境，数据未持久化）');
  };

  const columns: ColumnsType<RoleDef> = [
    {
      title: '角色名称',
      dataIndex: 'label',
      key: 'label',
      width: 160,
      render: (text: string) => <span className="font-medium">{text}</span>,
    },
    {
      title: '配额上限',
      dataIndex: 'key',
      key: 'quota',
      width: 160,
      render: (key: string) => (
        <InputNumber
          min={0}
          value={localQuotas[key] ?? 0}
          onChange={(v) => handleChange(key, v)}
          style={{ width: 120 }}
        />
      ),
    },
    {
      title: '说明',
      dataIndex: 'key',
      key: 'desc',
      render: (key: string) => (
        <span style={{ fontSize: 13, color: '#6B7280' }}>
          {ROLE_DESC[key] || ''}
        </span>
      ),
    },
  ];

  return (
    <Card
      title={
        <div>
          <div style={{ fontSize: 16, fontWeight: 500 }}>角色配额</div>
          <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>
            配置各组织下不同角色的最大人数
          </div>
        </div>
      }
      extra={
        <Space size={8}>
          <span style={{ fontSize: 14, color: '#6B7280' }}>组织：</span>
          <Select
            value={quotaOrg}
            onChange={setQuotaOrg}
            style={{ width: 176 }}
          >
            {orgs.map((org) => (
              <Select.Option key={org.id} value={org.slug}>
                {org.name}
              </Select.Option>
            ))}
          </Select>
        </Space>
      }
    >
      <Table<RoleDef>
        rowKey="key"
        columns={columns}
        dataSource={roleDefs}
        pagination={false}
        size="small"
      />
      <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: 16 }}>
        <Button type="primary" icon={<SaveOutlined />} onClick={handleSave}>
          保存配额
        </Button>
      </div>
    </Card>
  );
};

export default QuotaConfigPanel;
