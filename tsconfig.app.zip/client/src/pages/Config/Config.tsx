import { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  Settings,
} from 'lucide-react';
import { toast } from 'sonner';
import { Card, Menu } from 'antd';
import { organizationApi } from '@/api/organization';
import { accountsApi } from '@/api/user';
import type { Organization } from '@shared/api.interface';
import type { RoleDef } from '@/api/user';
import OrgConfigPanel from './OrgConfigPanel';
import QuotaConfigPanel from './QuotaConfigPanel';
import SystemConfigPanel from './SystemConfigPanel';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';

const tabs = [
  { id: 'organization', label: '组织配置', icon: Building2 },
  { id: 'quota', label: '角色配额', icon: Users },
  { id: 'system', label: '系统参数', icon: Settings },
];

const ConfigPage = () => {
  const [activeTab, setActiveTab] = useState('organization');
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [orgLoading, setOrgLoading] = useState(false);
  const [roleDefs, setRoleDefs] = useState<RoleDef[]>([]);
  const [roleQuotas, setRoleQuotas] = useState<Record<string, number>>({});

  useEffect(() => {
    void loadOrgs();
    void loadRoleMeta();
  }, []);

  const loadOrgs = async () => {
    setOrgLoading(true);
    try {
      const result = await organizationApi.list();
      setOrgs(result.items || []);
    } catch (error) {
      toast.error('加载组织列表失败');
    } finally {
      setOrgLoading(false);
    }
  };

  const loadRoleMeta = async () => {
    try {
      const result = await accountsApi.getRoleMeta();
      setRoleDefs(result.roles);
      setRoleQuotas(result.quotas);
    } catch (error) {
      // ignore
    }
  };

  const handleQuotaSave = (quotas: Record<string, number>) => {
    setRoleQuotas(quotas);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <PageBreadcrumb items={[{ label: '后台管理' }]} />
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#1F2937', margin: 0 }}>
          系统配置
        </h1>
        <p style={{ fontSize: 14, color: '#6B7280', marginTop: 4, marginBottom: 0 }}>
          管理系统基础配置与参数设置
        </p>
      </div>

      <div style={{ display: 'flex', gap: 16 }}>
        <div style={{ width: 192, flexShrink: 0 }}>
          <Card styles={{ body: { padding: 8 } }}>
            <Menu
              mode="inline"
              selectedKeys={[activeTab]}
              onClick={({ key }) => setActiveTab(key)}
              style={{ border: 'none', background: 'transparent' }}
              items={tabs.map((tab) => {
                const Icon = tab.icon;
                return {
                  key: tab.id,
                  icon: <Icon size={16} />,
                  label: tab.label,
                };
              })}
            />
          </Card>
        </div>

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {activeTab === 'organization' && (
            <OrgConfigPanel orgs={orgs} loading={orgLoading} />
          )}
          {activeTab === 'quota' && (
            <QuotaConfigPanel
              orgs={orgs}
              roleDefs={roleDefs}
              roleQuotas={roleQuotas}
              onSave={handleQuotaSave}
            />
          )}
          {activeTab === 'system' && <SystemConfigPanel />}
        </div>
      </div>
    </div>
  );
};

export default ConfigPage;
