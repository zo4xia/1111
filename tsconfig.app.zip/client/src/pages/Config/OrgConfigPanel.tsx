import { useState } from 'react';
import { SaveOutlined } from '@ant-design/icons';
import { toast } from 'sonner';
import {
  Table,
  Button,
  Input,
  Select,
  Card,
  Space,
  Form,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import type { Organization } from '@shared/api.interface';

const ORG_TYPE_LABELS: Record<string, string> = {
  platform: '平台管理',
  community_committee: '社区居委会',
  village_committee: '村民委员会',
};

interface Props {
  orgs: Organization[];
  loading: boolean;
}

const OrgConfigPanel = ({ orgs, loading }: Props) => {
  const [editingOrg, setEditingOrg] = useState<Organization | null>(null);
  const [form, setForm] = useState({ name: '', town: '', type: '', phone: '' });

  const handleEdit = (org: Organization) => {
    setEditingOrg(org);
    setForm({ name: org.name, town: org.town, type: org.type, phone: '' });
  };

  const handleSave = () => {
    if (!form.name) {
      toast.warning('组织名称不能为空');
      return;
    }
    toast.success('组织信息保存成功（演示环境，数据未持久化）');
    setEditingOrg(null);
  };

  const columns: ColumnsType<Organization> = [
    {
      title: '组织名称',
      dataIndex: 'name',
      key: 'name',
      render: (text: string) => <span className="font-medium">{text}</span>,
    },
    {
      title: '组织标识',
      dataIndex: 'slug',
      key: 'slug',
      width: 160,
      render: (text: string) => (
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
          {text}
        </span>
      ),
    },
    {
      title: '所属镇街',
      dataIndex: 'town',
      key: 'town',
      width: 140,
      render: (text: string) => text || '-',
    },
    {
      title: '组织类型',
      dataIndex: 'type',
      key: 'type',
      width: 140,
      render: (type: string) => ORG_TYPE_LABELS[type] || type,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 80,
      render: (status: string) =>
        status === 'active' || status === '启用' ? '启用' : '停用',
    },
    {
      title: '操作',
      key: 'action',
      width: 100,
      align: 'right',
      render: (_: unknown, record: Organization) => (
        <Button type="text" size="small" onClick={() => handleEdit(record)}>
          编辑
        </Button>
      ),
    },
  ];

  return (
    <Card
      title={
        <div>
          <div style={{ fontSize: 16, fontWeight: 500 }}>组织配置</div>
          <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>
            管理选举组织架构
          </div>
        </div>
      }
    >
      <Table<Organization>
        rowKey="id"
        columns={columns}
        dataSource={orgs}
        loading={loading}
        pagination={false}
        size="small"
        locale={{
          emptyText: (
            <div style={{ padding: '48px 0', textAlign: 'center', color: '#9CA3AF', fontSize: 13 }}>
              暂无组织数据
            </div>
          ),
        }}
      />

      {editingOrg && (
        <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid #E5E1DB' }}>
          <h3 style={{ fontSize: 14, fontWeight: 500, marginBottom: 16, marginTop: 0 }}>
            编辑组织：{editingOrg.name}
          </h3>
          <Form layout="vertical">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <Form.Item label="组织名称">
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </Form.Item>
              <Form.Item label="所属镇街">
                <Input
                  value={form.town}
                  onChange={(e) => setForm({ ...form, town: e.target.value })}
                />
              </Form.Item>
              <Form.Item label="组织类型">
                <Select
                  value={form.type}
                  onChange={(v) => setForm({ ...form, type: v })}
                >
                  <Select.Option value="platform">平台管理</Select.Option>
                  <Select.Option value="community_committee">社区居委会</Select.Option>
                  <Select.Option value="village_committee">村民委员会</Select.Option>
                </Select>
              </Form.Item>
              <Form.Item label="联系电话">
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="请输入联系电话"
                />
              </Form.Item>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
              <Space>
                <Button onClick={() => setEditingOrg(null)}>取消</Button>
                <Button type="primary" icon={<SaveOutlined />} onClick={handleSave}>
                  保存
                </Button>
              </Space>
            </div>
          </Form>
        </div>
      )}
    </Card>
  );
};

export default OrgConfigPanel;
