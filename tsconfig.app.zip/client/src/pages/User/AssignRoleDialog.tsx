import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import {
  Modal,
  Form,
  Checkbox,
  Button,
  Space,
} from 'antd';
import { accountsApi, type AccountItem, type RoleDef } from '@/api/user';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  account: AccountItem | null;
  roleOptions: RoleDef[];
  roleQuotas: Record<string, number>;
  onSuccess: () => void;
}

const AssignRoleDialog = ({
  open,
  onOpenChange,
  account,
  roleOptions,
  roleQuotas,
  onSuccess,
}: Props) => {
  const [roles, setRoles] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && account) {
      setRoles([...account.roles]);
    }
  }, [open, account]);

  const handleSubmit = async () => {
    if (!account) return;
    setLoading(true);
    try {
      await accountsApi.assignRoles(account.id, roles, 'current_user');
      toast.success('角色分配成功');
      onOpenChange(false);
      onSuccess();
    } catch (error) {
      toast.error((error as Error).message || '角色分配失败');
    } finally {
      setLoading(false);
    }
  };

  const toggleRole = (roleKey: string, checked: boolean) => {
    if (checked) {
      setRoles([...roles, roleKey]);
    } else {
      setRoles(roles.filter((r) => r !== roleKey));
    }
  };

  return (
    <Modal
      open={open}
      onCancel={() => onOpenChange(false)}
      title="分配角色"
      footer={
        <Space>
          <Button onClick={() => onOpenChange(false)} disabled={loading}>
            取消
          </Button>
          <Button type="primary" onClick={handleSubmit} loading={loading}>
            保存
          </Button>
        </Space>
      }
      width={480}
      destroyOnClose
    >
      <p style={{ color: '#6B7280', fontSize: 13, marginTop: -4, marginBottom: 16 }}>
        {account ? `为账号「${account.name}」分配角色权限` : ''}
      </p>
      <Form layout="vertical">
        <Form.Item label="角色列表">
          <Checkbox.Group
            value={roles}
            onChange={(checkedValues) => {
              setRoles(checkedValues as string[]);
            }}
            style={{ width: '100%' }}
          >
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {roleOptions.map((role) => (
                <div key={role.key} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Checkbox
                    value={role.key}
                    checked={roles.includes(role.key)}
                    onChange={(e) => toggleRole(role.key, e.target.checked)}
                  >
                    {role.label}
                  </Checkbox>
                  {roleQuotas[role.key] && roleQuotas[role.key] < 999 && (
                    <span style={{ fontSize: 12, color: '#9CA3AF' }}>
                      (限{roleQuotas[role.key]}人)
                    </span>
                  )}
                </div>
              ))}
            </div>
          </Checkbox.Group>
        </Form.Item>
      </Form>
      <p style={{ fontSize: 12, color: '#9CA3AF', marginTop: 8, marginBottom: 0 }}>
        注：角色配额基于所属组织统计，超配额时将保存失败
      </p>
    </Modal>
  );
};

export default AssignRoleDialog;
