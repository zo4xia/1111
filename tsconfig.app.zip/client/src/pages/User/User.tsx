import { useState, useEffect } from 'react';
import { PlusOutlined, UserOutlined, SafetyOutlined, PoweroffOutlined } from '@ant-design/icons';
import { toast } from 'sonner';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import {
  Table,
  Tag,
  Button,
  Select,
  Empty,
  Space,
  Card,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { accountsApi, type AccountItem, type RoleDef } from '@/api/user';
import { organizationApi } from '@/api/organization';
import type { Organization } from '@shared/api.interface';
import dayjs from 'dayjs';
import AccountCreateDialog from './AccountCreateDialog';
import AssignRoleDialog from './AssignRoleDialog';

const ROLE_LABELS: Record<string, string> = {
  platform_admin: '平台管理员',
  sub_admin: '子管理员',
  operator: '操作员',
  editor: '编辑',
  reviewer: '审核员',
  voter: '选民',
};

const UserPage = () => {
  const [accounts, setAccounts] = useState<AccountItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [orgFilter, setOrgFilter] = useState<string>('');
  const [roleFilter, setRoleFilter] = useState<string>('');
  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [roleDefs, setRoleDefs] = useState<RoleDef[]>([]);
  const [roleQuotas, setRoleQuotas] = useState<Record<string, number>>({});

  const [createOpen, setCreateOpen] = useState(false);
  const [assignOpen, setAssignOpen] = useState(false);
  const [currentAccount, setCurrentAccount] = useState<AccountItem | null>(null);

  useEffect(() => {
    void loadOrgs();
    void loadRoleMeta();
  }, []);

  useEffect(() => {
    void loadAccounts();
  }, [orgFilter, roleFilter]);

  const loadOrgs = async () => {
    try {
      const result = await organizationApi.list();
      setOrgs(result.items || []);
    } catch (error) {
      toast.error('加载组织列表失败');
    }
  };

  const loadRoleMeta = async () => {
    try {
      const result = await accountsApi.getRoleMeta();
      setRoleDefs(result.roles);
      setRoleQuotas(result.quotas);
    } catch (error) {
      // ignore
    }
  };

  const loadAccounts = async () => {
    setLoading(true);
    try {
      const result = await accountsApi.list({
        orgId: orgFilter || undefined,
        role: roleFilter || undefined,
        page: 1,
        pageSize: 50,
      });
      setAccounts(result.items);
      setTotal(result.total);
    } catch (error) {
      toast.error('加载账号列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAssignRole = (account: AccountItem) => {
    setCurrentAccount(account);
    setAssignOpen(true);
  };

  const handleToggleStatus = async (account: AccountItem) => {
    const nextStatus: 'active' | 'disabled' =
      account.status === 'active' ? 'disabled' : 'active';
    try {
      await accountsApi.toggleStatus(account.id, nextStatus);
      toast.success(nextStatus === 'active' ? '账号已启用' : '账号已禁用');
      void loadAccounts();
    } catch (error) {
      toast.error((error as Error).message || '操作失败');
    }
  };

  const roleOptions =
    roleDefs.length > 0
      ? roleDefs
      : Object.entries(ROLE_LABELS).map(([key, label]) => ({ key, label }));

  const columns: ColumnsType<AccountItem> = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      width: 120,
      render: (text: string) => <span className="font-medium">{text}</span>,
    },
    {
      title: '手机号',
      dataIndex: 'phone',
      key: 'phone',
      width: 140,
      render: (text: string) => (
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13 }}>
          {text || '-'}
        </span>
      ),
    },
    {
      title: '所属组织',
      dataIndex: 'orgName',
      key: 'orgName',
      width: 160,
    },
    {
      title: '角色',
      dataIndex: 'roles',
      key: 'roles',
      width: 240,
      render: (roles: string[]) => (
        <Space size={[4, 4]} wrap>
          {roles.map((role: string) => (
            <Tag key={role} color="blue">
              {ROLE_LABELS[role] || role}
            </Tag>
          ))}
        </Space>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 80,
      render: (status: string) =>
        status === 'active' ? (
          <Tag color="success">启用</Tag>
        ) : (
          <Tag color="error">禁用</Tag>
        ),
    },
    {
      title: '最后登录',
      dataIndex: 'lastLogin',
      key: 'lastLogin',
      width: 160,
      render: (text: string) => (
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: '#6B7280' }}>
          {text ? dayjs(text).format('YYYY-MM-DD HH:mm') : '-'}
        </span>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 200,
      align: 'right',
      render: (_: unknown, record: AccountItem) => (
        <Space size={4}>
          <Button
            type="text"
            size="small"
            icon={<SafetyOutlined />}
            onClick={() => handleAssignRole(record)}
          >
            分配角色
          </Button>
          <Button
            type="text"
            size="small"
            icon={<PoweroffOutlined />}
            onClick={() => handleToggleStatus(record)}
          >
            {record.status === 'active' ? '禁用' : '启用'}
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <PageBreadcrumb items={[{ label: '用户管理' }]} />
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#1F2937', margin: 0 }}>
          用户管理
        </h1>
        <p style={{ fontSize: 14, color: '#6B7280', marginTop: 4, marginBottom: 0 }}>
          管理系统账号与角色权限
        </p>
      </div>

      <Card
        styles={{ body: { padding: 0 } }}
        title={
          <Space size={16} wrap>
            <Space size={8}>
              <span style={{ fontSize: 14, color: '#6B7280', width: 64, display: 'inline-block' }}>
                所属组织
              </span>
              <Select
                value={orgFilter}
                onChange={setOrgFilter}
                placeholder="全部组织"
                style={{ width: 176 }}
                allowClear
              >
                <Select.Option value="">全部组织</Select.Option>
                {orgs.map((org) => (
                  <Select.Option key={org.id} value={org.slug}>
                    {org.name}
                  </Select.Option>
                ))}
              </Select>
            </Space>
            <Space size={8}>
              <span style={{ fontSize: 14, color: '#6B7280', width: 64, display: 'inline-block' }}>
                角色
              </span>
              <Select
                value={roleFilter}
                onChange={setRoleFilter}
                placeholder="全部角色"
                style={{ width: 144 }}
                allowClear
              >
                <Select.Option value="">全部角色</Select.Option>
                {roleOptions.map((r) => (
                  <Select.Option key={r.key} value={r.key}>
                    {r.label}
                  </Select.Option>
                ))}
              </Select>
            </Space>
          </Space>
        }
        extra={
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => setCreateOpen(true)}
          >
            新增账号
          </Button>
        }
        headStyle={{ padding: '12px 16px' }}
      >
        <div style={{ padding: 16 }}>
          <Table<AccountItem>
            rowKey="id"
            columns={columns}
            dataSource={accounts}
            loading={loading}
            locale={{
              emptyText: (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <span>
                      <UserOutlined style={{ marginRight: 6 }} />
                      暂无账号
                    </span>
                  }
                >
                  <span style={{ color: '#6B7280', fontSize: 12 }}>
                    当前没有找到相关账号数据
                  </span>
                </Empty>
              ),
            }}
            pagination={{
              total,
              pageSize: 10,
              showSizeChanger: false,
              showTotal: (t) => `共 ${t} 条记录`,
            }}
            size="small"
          />
        </div>
      </Card>

      <AccountCreateDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        orgs={orgs}
        roleOptions={roleOptions}
        roleQuotas={roleQuotas}
        onSuccess={loadAccounts}
      />
      <AssignRoleDialog
        open={assignOpen}
        onOpenChange={setAssignOpen}
        account={currentAccount}
        roleOptions={roleOptions}
        roleQuotas={roleQuotas}
        onSuccess={loadAccounts}
      />
    </div>
  );
};

export default UserPage;
