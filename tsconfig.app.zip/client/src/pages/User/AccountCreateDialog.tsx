import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import {
  Modal,
  Form,
  Input,
  Select,
  Checkbox,
  Button,
  Space,
} from 'antd';
import { accountsApi } from '@/api/user';
import type { RoleDef } from '@/api/user';
import type { Organization } from '@shared/api.interface';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orgs: Organization[];
  roleOptions: RoleDef[];
  roleQuotas: Record<string, number>;
  onSuccess: () => void;
}

const AccountCreateDialog = ({
  open,
  onOpenChange,
  orgs,
  roleOptions,
  roleQuotas,
  onSuccess,
}: Props) => {
  const [form, setForm] = useState({
    phone: '',
    name: '',
    orgId: '',
    roles: [] as string[],
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setForm({ phone: '', name: '', orgId: '', roles: [] });
    }
  }, [open]);

  const handleSubmit = async () => {
    if (!form.phone || !form.name || !form.orgId) {
      toast.warning('请填写完整信息');
      return;
    }
    if (form.roles.length === 0) {
      toast.warning('请至少选择一个角色');
      return;
    }
    setLoading(true);
    try {
      await accountsApi.create({ ...form, createdBy: 'current_user' });
      toast.success('账号创建成功');
      onOpenChange(false);
      onSuccess();
    } catch (error) {
      toast.error((error as Error).message || '创建失败');
    } finally {
      setLoading(false);
    }
  };

  const toggleRole = (roleKey: string, checked: boolean) => {
    if (checked) {
      setForm({ ...form, roles: [...form.roles, roleKey] });
    } else {
      setForm({ ...form, roles: form.roles.filter((r) => r !== roleKey) });
    }
  };

  return (
    <Modal
      open={open}
      onCancel={() => onOpenChange(false)}
      title="新增账号"
      footer={
        <Space>
          <Button onClick={() => onOpenChange(false)} disabled={loading}>
            取消
          </Button>
          <Button type="primary" onClick={handleSubmit} loading={loading}>
            确认创建
          </Button>
        </Space>
      }
      width={480}
      destroyOnClose
    >
      <p style={{ color: '#6B7280', fontSize: 13, marginTop: -4, marginBottom: 16 }}>
        创建一个新的系统账号并分配角色
      </p>
      <Form layout="vertical">
        <Form.Item label="姓名" required>
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="请输入姓名"
          />
        </Form.Item>
        <Form.Item label="手机号" required>
          <Input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="请输入手机号"
          />
        </Form.Item>
        <Form.Item label="所属组织" required>
          <Select
            value={form.orgId}
            onChange={(v) => setForm({ ...form, orgId: v })}
            placeholder="请选择组织"
          >
            {orgs.map((org) => (
              <Select.Option key={org.id} value={org.slug}>
                {org.name}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item label="角色" required>
          <Checkbox.Group
            value={form.roles}
            onChange={(checkedValues) => {
              setForm({ ...form, roles: checkedValues as string[] });
            }}
            style={{ width: '100%' }}
          >
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {roleOptions.map((role) => (
                <div key={role.key} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Checkbox
                    value={role.key}
                    checked={form.roles.includes(role.key)}
                    onChange={(e) => toggleRole(role.key, e.target.checked)}
                  >
                    {role.label}
                  </Checkbox>
                  {roleQuotas[role.key] && roleQuotas[role.key] < 999 && (
                    <span style={{ fontSize: 12, color: '#9CA3AF' }}>
                      (限{roleQuotas[role.key]}人)
                    </span>
                  )}
                </div>
              ))}
            </div>
          </Checkbox.Group>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default AccountCreateDialog;
