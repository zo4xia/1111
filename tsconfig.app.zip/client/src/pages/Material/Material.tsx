import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Alert,
  Card,
  Statistic,
  Tabs,
  Select,
  Table,
  Tag,
  Modal,
  Descriptions,
  Button,
  Input,
  Space,
  Row,
  Col,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import {
  WarningOutlined,
  ReloadOutlined,
  EyeOutlined,
  AuditOutlined,
} from '@ant-design/icons';
import { useElection } from '@client/src/contexts/ElectionContext';
import { materialApi } from '@client/src/api/material';
import type { Material, MaterialDetail, MaterialStats } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';

const TYPE_TABS = [
  { key: '', label: '全部' },
  { key: '个人自荐', label: '个人自荐' },
  { key: '组织推荐', label: '组织推荐' },
];

const STATUS_FILTERS = [
  { key: '', label: '全部状态' },
  { key: 'submitted', label: '待审核' },
  { key: 'resubmitted', label: '重新提交' },
  { key: 'needs_correction', label: '需补正' },
  { key: 'approved', label: '已通过' },
  { key: 'rejected', label: '已驳回' },
];

const STATUS_TAG_COLOR: Record<string, string> = {
  submitted: 'processing',
  resubmitted: 'processing',
  needs_correction: 'warning',
  approved: 'success',
  rejected: 'error',
};

function getStatusInfo(status: string) {
  const map: Record<string, { label: string; color: string }> = {
    submitted: { label: '待审核', color: 'processing' },
    resubmitted: { label: '重新提交', color: 'processing' },
    needs_correction: { label: '需补正', color: 'warning' },
    approved: { label: '已通过', color: 'success' },
    rejected: { label: '已驳回', color: 'error' },
  };
  return map[status] || { label: status, color: 'default' };
}

interface StatCardProps {
  label: string;
  value: number;
  valueColor: string;
  dotColor: string;
  onClick?: () => void;
  active?: boolean;
}

function StatCard({ label, value, valueColor, dotColor, onClick, active }: StatCardProps) {
  return (
    <Card
      hoverable
      onClick={onClick}
      style={{
        borderColor: active ? undefined : undefined,
        boxShadow: active ? '0 0 0 2px rgba(140, 31, 40, 0.15)' : 'none',
        border: active ? '1px solid #8c1f28' : undefined,
        cursor: 'pointer',
      }}
      styles={{ body: { padding: 16 } }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 13, color: '#6B7280' }}>{label}</span>
        <span
          style={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            backgroundColor: dotColor,
            display: 'inline-block',
          }}
        />
      </div>
      <Statistic
        value={value}
        valueStyle={{ color: valueColor, fontSize: 26, fontWeight: 700, marginTop: 4 }}
      />
    </Card>
  );
}

const MaterialPage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [typeFilter, setTypeFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [materials, setMaterials] = useState<Material[]>([]);
  const [stats, setStats] = useState<MaterialStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  const [reviewDialogOpen, setReviewDialogOpen] = useState<boolean>(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState<boolean>(false);
  const [detail, setDetail] = useState<MaterialDetail | null>(null);
  const [action, setAction] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const loadList = useCallback(async () => {
    if (!currentOrg) return;
    setLoading(true);
    try {
      const data = await materialApi.list({
        orgId: currentOrg.slug,
        electionId: currentElection?.id,
        type: typeFilter || undefined,
        status: statusFilter || undefined,
        pageSize: 200,
      });
      setMaterials(data.items);
    } catch (err) {
      logger.error(`加载材料列表失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [currentOrg, currentElection, typeFilter, statusFilter]);

  const loadStats = useCallback(async () => {
    if (!currentOrg) return;
    setStatsLoading(true);
    try {
      const data = await materialApi.stats({
        orgId: currentOrg.slug,
        electionId: currentElection?.id,
      });
      setStats(data);
    } catch (err) {
      logger.error(`加载材料统计失败: ${(err as Error).message}`);
    } finally {
      setStatsLoading(false);
    }
  }, [currentOrg, currentElection]);

  useEffect(() => {
    loadList();
  }, [loadList]);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const refreshAll = useCallback(async () => {
    await Promise.all([loadList(), loadStats()]);
  }, [loadList, loadStats]);

  const openReview = async (mat: Material) => {
    try {
      const d = await materialApi.getById(mat.id);
      setDetail(d);
      setAction('');
      setComment('');
      setReviewDialogOpen(true);
    } catch (err) {
      logger.error(`加载材料详情失败: ${(err as Error).message}`);
    }
  };

  const openDetail = async (mat: Material) => {
    try {
      const d = await materialApi.getById(mat.id);
      setDetail(d);
      setDetailDialogOpen(true);
    } catch (err) {
      logger.error(`加载材料详情失败: ${(err as Error).message}`);
    }
  };

  const handleReviewSubmit = async () => {
    if (!detail || !action) return;
    setSubmitting(true);
    try {
      await materialApi.review(detail.id, action, comment);
      await refreshAll();
      setReviewDialogOpen(false);
      setDetail(null);
    } catch (err) {
      logger.error(`材料审核失败: ${(err as Error).message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleResubmit = async (mat: Material) => {
    try {
      await materialApi.resubmit(mat.id);
      await refreshAll();
    } catch (err) {
      logger.error(`重新提交失败: ${(err as Error).message}`);
    }
  };
  if (ctxLoading || !currentOrg) {
    return <div style={{ padding: 16, color: '#6B7280' }}>加载中...</div>;
  }

  const isReviewable = (s: string) => s === 'submitted' || s === 'resubmitted';
  const isTerminal = (s: string) => s === 'approved' || s === 'rejected';
  const columns: ColumnsType<Material> = [
    {
      title: '#',
      key: 'index',
      width: 50,
      render: (_: unknown, __, index) => (
        <span className="text-muted-foreground font-mono text-xs">{index + 1}</span>
      ),
    },
    { title: '提交人', dataIndex: 'submitter', key: 'submitter', width: 120, render: (t: string) => <strong>{t || '—'}</strong> },
    { title: '竞选岗位', dataIndex: 'position', key: 'position', width: 140 },
    {
      title: '参选形式',
      dataIndex: 'type',
      key: 'type',
      width: 120,
      render: (t: string) => t || '—',
    },
    {
      title: '材料预览',
      key: 'preview',
      width: 120,
      render: () => (
        <Button type="link" size="small">查看</Button>
      ),
    },
    {
      title: '是否进入候选人池',
      dataIndex: 'enteredPool',
      key: 'enteredPool',
      width: 140,
      render: (v: boolean | string) => (
        <Tag color={v ? 'success' : 'default'}>
          {v ? '已进入' : '未进入'}
        </Tag>
      ),
    },
    { title: '审核状态', dataIndex: 'status', key: 'status', width: 100, render: (s: string) => <Tag color={getStatusInfo(s).color}>{getStatusInfo(s).label}</Tag> },
    {
      title: '操作',
      key: 'action',
      width: 220,
      align: 'right',
      fixed: 'right',
      render: (_: unknown, record: Material) => (
        <Space size="small" wrap>
          {isReviewable(record.status) && (
            <Button
              type="text"
              size="small"
              icon={<AuditOutlined />}
              onClick={() => openReview(record)}
            >
              审核
            </Button>
          )}
          {record.status === 'needs_correction' && (
            <>
              <Button
                type="text"
                size="small"
                icon={<ReloadOutlined />}
                style={{ color: '#c9a063' }}
                onClick={() => handleResubmit(record)}
              >
                重新提交
              </Button>
              <Button
                size="small"
                icon={<EyeOutlined />}
                onClick={() => openDetail(record)}
              >
                查看意见
              </Button>
            </>
          )}
          {isTerminal(record.status) && (
            <Button
              type="text"
              size="small"
              icon={<EyeOutlined />}
              onClick={() => openDetail(record)}
            >
              查看详情
            </Button>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <PageBreadcrumb
        items={[
          { label: '选举活动管理', href: '/elections' },
          { label: currentElection?.term || '第X届' },
          { label: '业务模块-材料管理' },
        ]}
      />
      {/* 当前届次上下文栏 */}
      <Card size="small" style={{ background: 'linear-gradient(135deg, #fff9f0 0%, #fff 100%)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>当前届次</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#1F2937' }}>
              {currentElection?.name || '—'}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>选举方式</div>
            <div style={{ fontSize: 14, color: '#1F2937' }}>
              {currentElection?.method || '—'}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>D日</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#8c1f28', fontFamily: 'monospace' }}>
              {currentElection?.electionDate || '—'}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>材料总数</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#1F2937' }}>
              {stats?.total ?? materials.length} 份
            </div>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <Button type="primary" size="small">新建材料</Button>
          </div>
        </div>
      </Card>
      {/* 页面标题 */}
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, margin: 0, color: '#2b2626' }}>
          材料管理
        </h1>
        <p style={{ fontSize: 13, color: '#6B7280', margin: '4px 0 0 0' }}>
          候选人申报材料审核，共 {stats?.total ?? materials.length} 份材料
        </p>
      </div>

      {/* 醒目提示：材料通过 ≠ 资格通过 */}
      <Alert
        type="warning"
        showIcon
        icon={<WarningOutlined />}
        message="材料审核通过 ≠ 候选人资格通过"
        description="材料通过仅表示形式审核合格，候选人资格需经代表会议审议通过方为有效。"
      />

      {/* 统计卡片 */}
      <Row gutter={[12, 12]} data-ai-section-type="card-stat">
        <Col xs={12} sm={12} md={6}>
          <StatCard
            label="待审查"
            value={(stats?.submitted ?? 0) + (stats?.resubmitted ?? 0)}
            valueColor="#8c1f28"
            dotColor="#8c1f28"
            active={statusFilter === 'submitted' || statusFilter === 'resubmitted'}
            onClick={() =>
              setStatusFilter((prev) =>
                prev === 'submitted' || prev === 'resubmitted' ? '' : 'submitted'
              )
            }
          />
        </Col>
        <Col xs={12} sm={12} md={6}>
          <StatCard
            label="需补正"
            value={stats?.needsCorrection ?? 0}
            valueColor="#c9a063"
            dotColor="#c9a063"
            active={statusFilter === 'needs_correction'}
            onClick={() =>
              setStatusFilter((prev) => (prev === 'needs_correction' ? '' : 'needs_correction'))
            }
          />
        </Col>
        <Col xs={12} sm={12} md={6}>
          <StatCard
            label="已通过"
            value={stats?.approved ?? 0}
            valueColor="#2D8B55"
            dotColor="#2D8B55"
            active={statusFilter === 'approved'}
            onClick={() =>
              setStatusFilter((prev) => (prev === 'approved' ? '' : 'approved'))
            }
          />
        </Col>
        <Col xs={12} sm={12} md={6}>
          <StatCard
            label="已驳回"
            value={stats?.rejected ?? 0}
            valueColor="#8c1f28"
            dotColor="#8c1f28"
            active={statusFilter === 'rejected'}
            onClick={() =>
              setStatusFilter((prev) => (prev === 'rejected' ? '' : 'rejected'))
            }
          />
        </Col>
      </Row>

      {/* 筛选栏 */}
      <Card styles={{ body: { padding: 0 } }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 16px 0 4px',
          }}
        >
          <Tabs
            activeKey={typeFilter}
            onChange={(key) => setTypeFilter(key)}
            items={TYPE_TABS.map((tab) => ({ key: tab.key, label: tab.label }))}
            style={{ marginBottom: 0 }}
          />
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 140 }}
            options={STATUS_FILTERS.map((f) => ({ value: f.key, label: f.label }))}
          />
        </div>
      </Card>

      {/* 材料列表 */}
      <Card
        title={<span style={{ fontSize: 14, fontWeight: 600 }}>材料列表</span>}
        styles={{ body: { padding: 0 } }}
      >
        <Table<Material>
          columns={columns}
          dataSource={materials}
          rowKey="id"
          loading={loading || statsLoading}
          pagination={{
            defaultPageSize: 10,
            showSizeChanger: true,
            showTotal: (total) => `共 ${total} 条`,
            pageSizeOptions: ['10', '20', '50'],
          }}
          scroll={{ x: 900 }}
          size="middle"
        />
      </Card>

      {/* 审核弹窗 */}
      <Modal
        open={reviewDialogOpen}
        onCancel={() => setReviewDialogOpen(false)}
        title="材料审核"
        width={640}
        footer={[
          <Button key="cancel" onClick={() => setReviewDialogOpen(false)}>
            取消
          </Button>,
          <Button
            key="submit"
            type="primary"
            onClick={handleReviewSubmit}
            disabled={!action || submitting}
            loading={submitting}
          >
            确认审核
          </Button>,
        ]}
      >
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* 醒目提示 */}
            <Alert
              type="warning"
              showIcon
              icon={<WarningOutlined />}
              message="材料审核通过 ≠ 候选人资格通过"
              description="资格需经代表会议审议通过方为有效。"
            />

            {/* 材料基本信息 */}
            <Descriptions
              title={
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 600 }}>{detail.applicant}</span>
                  <Tag color={getStatusInfo(detail.status).color}>
                    {getStatusInfo(detail.status).label}
                  </Tag>
                </div>
              }
              column={2}
              size="small"
              bordered
              style={{ marginTop: 8 }}
            >
              <Descriptions.Item label="岗位">{detail.position}</Descriptions.Item>
              <Descriptions.Item label="类型">{detail.type}</Descriptions.Item>
              <Descriptions.Item label="电话">
                {detail.applicantPhone || '-'}
              </Descriptions.Item>
              <Descriptions.Item label="提交时间">
                {detail.submitTime ? detail.submitTime.slice(0, 10) : '-'}
              </Descriptions.Item>
            </Descriptions>

            {/* 材料内容 */}
            <div>
              <div style={{ fontWeight: 500, marginBottom: 8, fontSize: 14 }}>
                材料内容
              </div>
              <div
                style={{
                  border: '1px solid #E5E1DB',
                  borderRadius: 4,
                  padding: 12,
                  minHeight: 80,
                  fontSize: 13,
                  whiteSpace: 'pre-wrap',
                  backgroundColor: '#fff',
                }}
              >
                {detail.content || '无'}
              </div>
            </div>

            {/* 已有审核信息 */}
            {detail.status !== 'submitted' && detail.status !== 'resubmitted' && (
              <div>
                <div style={{ fontWeight: 500, marginBottom: 8, fontSize: 14 }}>
                  当前审核信息
                </div>
                <div
                  style={{
                    border: '1px solid #E5E1DB',
                    borderRadius: 4,
                    padding: 12,
                    fontSize: 13,
                    backgroundColor: '#FAF8F5',
                  }}
                >
                  <div style={{ marginBottom: 4 }}>
                    <span style={{ color: '#6B7280' }}>审核人：</span>
                    {detail.reviewer || '-'}
                  </div>
                  <div style={{ marginBottom: 4 }}>
                    <span style={{ color: '#6B7280' }}>审核时间：</span>
                    {detail.reviewTime || '-'}
                  </div>
                  {detail.reviewComment && (
                    <div>
                      <span style={{ color: '#6B7280' }}>审核意见：</span>
                      {detail.reviewComment}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 审核结论 */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ fontWeight: 500, fontSize: 14 }}>审核结论</div>
              <Select
                value={action || undefined}
                onChange={setAction}
                placeholder="请选择审核结果"
                options={[
                  { value: 'approve', label: '通过（材料形式审核合格）' },
                  { value: 'need_correction', label: '要求补正' },
                  { value: 'reject', label: '驳回' },
                ]}
              />
              <Input.TextArea
                placeholder="请输入审核意见（选填）"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
              />
            </div>
          </div>
        )}
      </Modal>

      {/* 查看详情弹窗 */}
      <Modal
        open={detailDialogOpen}
        onCancel={() => setDetailDialogOpen(false)}
        title="材料详情"
        width={640}
        footer={[
          <Button key="close" type="primary" onClick={() => setDetailDialogOpen(false)}>
            关闭
          </Button>,
        ]}
      >
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* 醒目提示 */}
            {detail.status === 'approved' && (
              <Alert
                type="warning"
                showIcon
                icon={<WarningOutlined />}
                message="材料审核通过 ≠ 候选人资格通过"
                description="材料通过仅表示形式审核合格，候选人资格需经代表会议审议通过方为有效。"
              />
            )}

            {/* 基本信息 */}
            <Descriptions
              title={
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 600 }}>{detail.applicant}</span>
                  <Tag color={getStatusInfo(detail.status).color}>
                    {getStatusInfo(detail.status).label}
                  </Tag>
                </div>
              }
              column={2}
              size="small"
              bordered
              style={{ marginTop: 8 }}
            >
              <Descriptions.Item label="岗位">{detail.position}</Descriptions.Item>
              <Descriptions.Item label="类型">{detail.type}</Descriptions.Item>
              <Descriptions.Item label="电话">
                {detail.applicantPhone || '-'}
              </Descriptions.Item>
              <Descriptions.Item label="提交时间">
                {detail.submitTime ? detail.submitTime.slice(0, 10) : '-'}
              </Descriptions.Item>
              {detail.stage && (
                <Descriptions.Item label="阶段" span={2}>
                  {detail.stage}
                </Descriptions.Item>
              )}
            </Descriptions>

            {/* 材料内容 */}
            <div>
              <div style={{ fontWeight: 500, marginBottom: 8, fontSize: 14 }}>
                材料内容
              </div>
              <div
                style={{
                  border: '1px solid #E5E1DB',
                  borderRadius: 4,
                  padding: 12,
                  minHeight: 80,
                  fontSize: 13,
                  whiteSpace: 'pre-wrap',
                  backgroundColor: '#fff',
                }}
              >
                {detail.content || '无'}
              </div>
            </div>

            {/* 审核信息 */}
            {(detail.reviewer || detail.reviewComment) && (
              <div>
                <div style={{ fontWeight: 500, marginBottom: 8, fontSize: 14 }}>
                  审核信息
                </div>
                <div
                  style={{
                    border: '1px solid #E5E1DB',
                    borderRadius: 4,
                    padding: 12,
                    fontSize: 13,
                    backgroundColor: '#FAF8F5',
                  }}
                >
                  <div style={{ marginBottom: 4 }}>
                    <span style={{ color: '#6B7280' }}>审核人：</span>
                    {detail.reviewer || '-'}
                  </div>
                  <div style={{ marginBottom: 4 }}>
                    <span style={{ color: '#6B7280' }}>审核时间：</span>
                    {detail.reviewTime || '-'}
                  </div>
                  {detail.reviewComment && (
                    <div style={{ marginBottom: 4 }}>
                      <span style={{ color: '#6B7280' }}>审核意见：</span>
                      {detail.reviewComment}
                    </div>
                  )}
                  {detail.candidateId && (
                    <div>
                      <span style={{ color: '#6B7280' }}>候选人ID：</span>
                      {detail.candidateId}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 补正意见（需补正状态下突出显示） */}
            {detail.status === 'needs_correction' && detail.reviewComment && (
              <Alert
                type="warning"
                showIcon
                icon={<WarningOutlined />}
                message="补正意见"
                description={detail.reviewComment}
              />
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MaterialPage;
