import { Loader2 } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import type { AnnouncementDetail } from '@shared/api.interface';

const STATUS_LABEL: Record<string, string> = {
  draft: '草稿',
  pending_review: '待审核',
  reviewed: '已审核',
  published: '已发布',
  frozen: '已冻结',
};

function getStatusBadgeClass(status: string): string {
  switch (status) {
    case 'published':
    case 'reviewed':
      return 'text-[hsl(152_60%_40%)] bg-[hsl(152_50%_95%)] border-transparent';
    case 'pending_review':
      return 'bg-[hsl(217_50%_94%)] text-primary border-transparent';
    case 'frozen':
      return 'text-[hsl(0_65%_50%)] bg-[hsl(0_55%_95%)] border-transparent';
    case 'draft':
      return 'text-muted-foreground bg-[hsl(215_15%_94%)] border-transparent';
    default:
      return 'text-muted-foreground bg-transparent';
  }
}

interface AnnouncementViewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  loading: boolean;
  data: AnnouncementDetail | null;
}

const AnnouncementViewDialog = ({
  open,
  onOpenChange,
  loading,
  data,
}: AnnouncementViewDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>公告详情</DialogTitle>
        </DialogHeader>
        {loading || !data ? (
          <div className="py-8 text-center text-muted-foreground">
            <Loader2 size={20} className="animate-spin inline-block mr-2" />
            加载中...
          </div>
        ) : (
          <div className="space-y-3 max-h-[60vh] overflow-y-auto">
            <div className="flex items-center gap-3">
              <span className="font-mono bg-accent px-2 py-0.5 rounded-sm text-xs">
                {data.code}
              </span>
              <Badge variant="outline" className={getStatusBadgeClass(data.status)}>
                {STATUS_LABEL[data.status] || data.status}
              </Badge>
              <span className="text-xs text-muted-foreground font-mono">
                v{data.version}
              </span>
            </div>
            <h3 className="text-lg font-semibold">{data.title}</h3>
            <div className="grid grid-cols-2 gap-3 text-xs text-muted-foreground">
              <div>编辑人：{data.editor || '-'}</div>
              <div>审核人：{data.reviewer || '-'}</div>
              <div>编辑时间：{data.editTime || '-'}</div>
              <div>审核时间：{data.reviewTime || '-'}</div>
              <div>发布时间：{data.publishTime || '-'}</div>
              <div>公示截止：{data.publicityDeadline || '-'}</div>
            </div>
            {data.reviewComment && (
              <div className="text-xs text-muted-foreground bg-accent/50 p-2 rounded-sm">
                审核意见：{data.reviewComment}
              </div>
            )}
            <div className="border-t border-border pt-3 whitespace-pre-wrap text-sm leading-relaxed">
              {data.content || (
                <span className="text-muted-foreground">暂无内容</span>
              )}
            </div>
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            关闭
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AnnouncementViewDialog;
