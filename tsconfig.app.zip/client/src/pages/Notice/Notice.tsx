import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Edit3,
  Eye,
  Send,
  CheckCircle2,
  XCircle,
  Snowflake,
  Play,
  FileText,
  ListChecks,
} from 'lucide-react';
import { Tabs, Table, Tag, Button, Space } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { announcementApi } from '@client/src/api/announcement';
import type { Announcement, AnnouncementDetail } from '@shared/api.interface';
import type { AnnouncementStatus } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import TemplateTab from './TemplateTab';
import RejectDialog from './RejectDialog';
import AnnouncementEditDialog from './AnnouncementEditDialog';
import AnnouncementViewDialog from './AnnouncementViewDialog';

const STATUS_LABEL: Record<AnnouncementStatus, string> = {
  draft: '草稿',
  pending_publish: '待发布',
  published: '已发布',
  correction: '更正中',
  frozen: '已冻结',
};

const STATUS_TABS: Array<{ key: string | 'all'; label: string }> = [
  { key: 'all', label: '全部' },
  { key: 'draft', label: '草稿' },
  { key: 'pending_publish', label: '待发布' },
  { key: 'published', label: '已发布' },
  { key: 'correction', label: '更正中' },
  { key: 'frozen', label: '已冻结' },
];

/**
 * 状态标签颜色（严格按参考HTML规范）
 * 已发布=绿 · 草稿=灰 · 待发布=橙 · 更正中=金 · 已冻结=红
 */
function getStatusTagColor(status: string): string {
  switch (status) {
    case 'published':
      return 'green';
    case 'pending_publish':
      return 'orange';
    case 'correction':
      return 'gold';
    case 'frozen':
      return 'red';
    case 'draft':
      return 'default';
    default:
      return 'default';
  }
}

const PAGE_TABS = [
  { key: 'announcements', label: '公告列表', icon: ListChecks },
  { key: 'templates', label: '公告模板', icon: FileText },
];

const NoticePage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [pageTab, setPageTab] = useState<string>('announcements');

  const breadcrumbItems = [
    { label: '公告通知' },
  ];

  // 公告列表
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('all');
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;

  // 编辑弹窗
  const [editDialogOpen, setEditDialogOpen] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editInitial, setEditInitial] = useState({
    title: '',
    content: '',
    publicityDeadline: '',
  });
  const [saving, setSaving] = useState<boolean>(false);

  // 查看弹窗
  const [viewDialogOpen, setViewDialogOpen] = useState<boolean>(false);
  const [viewData, setViewData] = useState<AnnouncementDetail | null>(null);
  const [viewLoading, setViewLoading] = useState<boolean>(false);

  // 驳回弹窗
  const [rejectOpen, setRejectOpen] = useState<boolean>(false);
  const [rejectId, setRejectId] = useState<string | null>(null);
  const [rejectLoading, setRejectLoading] = useState<boolean>(false);

  // 使用模板
  const [usingTemplateId, setUsingTemplateId] = useState<string | null>(null);

  const isCommunity = currentOrg?.type === 'community_committee';

  // ========================= 数据加载 =========================

  const loadList = async () => {
    if (!currentOrg || !currentElection) return;
    setLoading(true);
    try {
      const params: Record<string, unknown> = {
        electionId: currentElection.id,
        orgId: currentOrg.slug,
        page,
        pageSize,
      };
      if (activeTab !== 'all') {
        params.status = activeTab;
      }
      const result = await announcementApi.list(params);
      setAnnouncements(result.items);
      setTotal(result.total);
    } catch (err) {
      logger.error(`加载公告列表失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!currentOrg || !currentElection) return;
    if (pageTab !== 'announcements') return;
    setPage(1);
    loadList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentOrg, currentElection, activeTab, pageTab]);

  useEffect(() => {
    if (!currentOrg || !currentElection) return;
    if (pageTab !== 'announcements') return;
    loadList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  // ========================= 编辑/查看 =========================

  const handleEdit = async (ann: Announcement) => {
    setViewLoading(true);
    try {
      const detail = await announcementApi.getById(ann.id);
      setEditingId(ann.id);
      setEditInitial({
        title: detail.title,
        content: detail.content,
        publicityDeadline: detail.publicityDeadline,
      });
      setEditDialogOpen(true);
    } catch (err) {
      logger.error(`加载公告详情失败: ${(err as Error).message}`);
    } finally {
      setViewLoading(false);
    }
  };

  const handleView = async (ann: Announcement) => {
    setViewLoading(true);
    setViewDialogOpen(true);
    setViewData(null);
    try {
      const detail = await announcementApi.getById(ann.id);
      setViewData(detail);
    } catch (err) {
      logger.error(`加载公告详情失败: ${(err as Error).message}`);
    } finally {
      setViewLoading(false);
    }
  };

  const handleSaveDraft = async (data: {
    title: string;
    content: string;
    publicityDeadline: string;
  }) => {
    if (!editingId) return;
    setSaving(true);
    try {
      await announcementApi.update(editingId, data);
      setEditDialogOpen(false);
      await loadList();
    } catch (err) {
      logger.error(`保存公告失败: ${(err as Error).message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleSubmitReview = async (data: {
    title: string;
    content: string;
    publicityDeadline: string;
  }) => {
    if (!editingId) return;
    setSaving(true);
    try {
      await announcementApi.update(editingId, data);
      await announcementApi.submitReview(editingId);
      setEditDialogOpen(false);
      await loadList();
    } catch (err) {
      logger.error(`提交审核失败: ${(err as Error).message}`);
    } finally {
      setSaving(false);
    }
  };

  // ========================= 状态操作 =========================

  const handleSubmitReviewDirect = async (id: string) => {
    try {
      await announcementApi.submitReview(id);
      await loadList();
    } catch (err) {
      logger.error(`提交审核失败: ${(err as Error).message}`);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await announcementApi.approve(id);
      await loadList();
    } catch (err) {
      logger.error(`审核通过失败: ${(err as Error).message}`);
    }
  };

  const handleRejectClick = (id: string) => {
    setRejectId(id);
    setRejectOpen(true);
  };

  const handleRejectConfirm = async (comment: string) => {
    if (!rejectId) return;
    setRejectLoading(true);
    try {
      await announcementApi.reject(rejectId, comment);
      setRejectOpen(false);
      await loadList();
    } catch (err) {
      logger.error(`驳回失败: ${(err as Error).message}`);
    } finally {
      setRejectLoading(false);
    }
  };

  const handlePublish = async (id: string) => {
    try {
      await announcementApi.publish(id);
      await loadList();
    } catch (err) {
      logger.error(`发布失败: ${(err as Error).message}`);
    }
  };

  const handleFreeze = async (id: string) => {
    try {
      await announcementApi.freeze(id);
      await loadList();
    } catch (err) {
      logger.error(`冻结失败: ${(err as Error).message}`);
    }
  };

  const handleUnfreeze = async (id: string) => {
    try {
      await announcementApi.unfreeze(id);
      await loadList();
    } catch (err) {
      logger.error(`解冻失败: ${(err as Error).message}`);
    }
  };

  // ========================= 使用模板 =========================

  const handleUseTemplate = async (templateId: string) => {
    if (!currentElection || !currentOrg) return;
    setUsingTemplateId(templateId);
    try {
      const newAnn = await announcementApi.useTemplate(
        templateId,
        currentElection.id,
        currentOrg.slug,
      );
      setEditingId(newAnn.id);
      setEditInitial({
        title: newAnn.title,
        content: newAnn.content,
        publicityDeadline: newAnn.publicityDeadline,
      });
      setEditDialogOpen(true);
      setPageTab('announcements');
      await loadList();
    } catch (err) {
      logger.error(`从模板创建公告失败: ${(err as Error).message}`);
    } finally {
      setUsingTemplateId(null);
    }
  };

  // ========================= 操作按钮渲染 =========================

  const renderActions = (ann: Announcement) => {
    const status = ann.status as AnnouncementStatus;
    const actions: React.ReactNode[] = [];

    actions.push(
      <Button
        key="view"
        type="text"
        size="small"
        icon={<Eye size={14} />}
        onClick={() => handleView(ann)}
      >
        查看
      </Button>,
    );

    // 草稿：编辑 + 提交审核
    if (status === 'draft') {
      actions.push(
        <Button
          key="edit"
          type="text"
          size="small"
          icon={<Edit3 size={14} />}
          onClick={() => handleEdit(ann)}
        >
          编辑
        </Button>,
      );
      actions.push(
        <Button
          key="submit"
          type="text"
          size="small"
          icon={<Send size={14} />}
          onClick={() => handleSubmitReviewDirect(ann.id)}
        >
          提交审核
        </Button>,
      );
    }

    // 待发布：审核通过 + 驳回
    if (status === 'pending_publish') {
      actions.push(
        <Button
          key="approve"
          type="text"
          size="small"
          style={{ color: '#52c41a' }}
          icon={<CheckCircle2 size={14} />}
          onClick={() => handleApprove(ann.id)}
        >
          审核通过
        </Button>,
      );
      actions.push(
        <Button
          key="reject"
          type="text"
          size="small"
          danger
          icon={<XCircle size={14} />}
          onClick={() => handleRejectClick(ann.id)}
        >
          驳回
        </Button>,
      );
    }

    // 更正中：重新发布
    if (status === 'correction') {
      actions.push(
        <Button
          key="publish"
          type="text"
          size="small"
          style={{ color: '#52c41a' }}
          icon={<Play size={14} />}
          onClick={() => handlePublish(ann.id)}
        >
          重新发布
        </Button>,
      );
    }

    // 已发布：冻结
    if (status === 'published') {
      actions.push(
        <Button
          key="freeze"
          type="text"
          size="small"
          danger
          icon={<Snowflake size={14} />}
          onClick={() => handleFreeze(ann.id)}
        >
          冻结
        </Button>,
      );
    }

    // 已冻结：解冻
    if (status === 'frozen') {
      actions.push(
        <Button
          key="unfreeze"
          type="text"
          size="small"
          style={{ color: '#52c41a' }}
          icon={<Play size={14} />}
          onClick={() => handleUnfreeze(ann.id)}
        >
          解冻
        </Button>,
      );
    }

    return <Space size={2}>{actions}</Space>;
  };

  // ========================= 表格列定义 =========================

  const columns: ColumnsType<Announcement> = [
    {
      title: '#',
      key: 'index',
      width: 50,
      render: (_: unknown, __, index) => (
        <span className="text-muted-foreground font-mono text-xs">{index + 1}</span>
      ),
    },
    {
      title: '公告编号',
      dataIndex: 'code',
      key: 'code',
      width: 140,
      render: (text: string) => (
        <span className="font-mono font-medium text-sm">{text || '—'}</span>
      ),
    },
    {
      title: '关联阶段',
      dataIndex: 'stageKey',
      key: 'stageKey',
      width: 140,
      render: (text: string) => text || <span className="text-muted-foreground">—</span>,
    },
    {
      title: '公告标题',
      dataIndex: 'title',
      key: 'title',
      ellipsis: true,
    },
    {
      title: '发布时间',
      dataIndex: 'publishTime',
      key: 'publishTime',
      width: 170,
      render: (text: string) => (
        <span className="font-mono text-xs text-muted-foreground">{text || '—'}</span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: string) => (
        <Tag color={getStatusTagColor(status)}>
          {STATUS_LABEL[status as AnnouncementStatus] || status}
        </Tag>
      ),
    },
    {
      title: '操作',
      key: 'actions',
      width: 200,
      align: 'right',
      render: (_, record) => renderActions(record),
    },
  ];

  // ========================= 渲染 =========================

  if (ctxLoading) {
    return (
      <div className="space-y-4 text-sm text-muted-foreground">加载中...</div>
    );
  }

  if (!currentOrg) {
    return (
      <div className="space-y-4">
        <div className="bg-card border border-border rounded-sm p-12 flex flex-col items-center justify-center text-muted-foreground">
          <div className="text-sm">暂无组织数据</div>
        </div>
      </div>
    );
  }

  const pageTabItems = PAGE_TABS.map((tab) => {
    const Icon = tab.icon;
    return {
      key: tab.key,
      label: (
        <span>
          <Icon size={14} className="mr-1.5" />
          {tab.label}
        </span>
      ),
    };
  });

  const statusTabItems = STATUS_TABS.map((tab) => ({
    key: tab.key,
    label: tab.label,
  }));

  const handleTablePageChange = (p: number) => {
    setPage(p);
  };

  const handleEmptyCreate = (
    <span>
      暂无公告数据，可从
      <span
        className="text-[#8c1f28] cursor-pointer mx-1"
        onClick={() => setPageTab('templates')}
      >
        公告模板
      </span>
      创建
    </span>
  );

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={breadcrumbItems} />
      {/* 顶部标题区 */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">公告管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {currentOrg.name} · 选举公告发布与审核
          </p>
        </div>
      </div>

      {/* 页面级 Tabs */}
      <div className="bg-card border border-border rounded-sm">
        <div className="px-4 pt-3">
          <Tabs
            activeKey={pageTab}
            onChange={setPageTab}
            items={pageTabItems}
          />
        </div>

        {/* 公告列表 Tab */}
        {pageTab === 'announcements' && (
          <div>
            {/* 筛选 Tabs */}
            <div className="px-4 pt-3 border-t border-border">
              <Tabs
                activeKey={activeTab}
                onChange={setActiveTab}
                items={statusTabItems}
                size="small"
              />
            </div>

            {/* 表格 */}
            <Table<Announcement>
              rowKey="id"
              columns={columns}
              dataSource={announcements}
              loading={loading}
              pagination={{
                current: page,
                pageSize,
                total,
                onChange: handleTablePageChange,
                showSizeChanger: false,
                showTotal: (t) => `共 ${t} 条`,
              }}
              locale={{ emptyText: handleEmptyCreate }}
              size="middle"
              bordered={false}
            />
          </div>
        )}

        {/* 模板 Tab */}
        {pageTab === 'templates' && (
          <div>
            <TemplateTab
              onUseTemplate={handleUseTemplate}
              usingTemplateId={usingTemplateId}
            />
          </div>
        )}
      </div>

      {/* 编辑弹窗 */}
      <AnnouncementEditDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        initialTitle={editInitial.title}
        initialContent={editInitial.content}
        initialDeadline={editInitial.publicityDeadline}
        saving={saving}
        onSaveDraft={handleSaveDraft}
        onSubmitReview={handleSubmitReview}
      />

      {/* 查看弹窗 */}
      <AnnouncementViewDialog
        open={viewDialogOpen}
        onOpenChange={setViewDialogOpen}
        loading={viewLoading}
        data={viewData}
      />

      {/* 驳回弹窗 */}
      <RejectDialog
        open={rejectOpen}
        onOpenChange={setRejectOpen}
        loading={rejectLoading}
        onConfirm={handleRejectConfirm}
      />
    </div>
  );
};

export default NoticePage;
