import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Search,
  FileText,
  Loader2,
  Bell,
  Info,
} from 'lucide-react';
import type { AnnouncementTemplate } from '@shared/api.interface';
import { announcementApi } from '@client/src/api/announcement';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Badge } from '@client/src/components/ui/badge';

interface TemplateTabProps {
  onUseTemplate: (templateId: string) => void;
  usingTemplateId: string | null;
}

const TemplateTab = ({ onUseTemplate, usingTemplateId }: TemplateTabProps) => {
  const [templates, setTemplates] = useState<AnnouncementTemplate[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [keyword, setKeyword] = useState<string>('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] =
    useState<AnnouncementTemplate | null>(null);
  const [detailLoading, setDetailLoading] = useState<boolean>(false);

  // 加载模板列表
  const loadTemplates = async () => {
    setLoading(true);
    try {
      const result = await announcementApi.listTemplates({
        pageSize: 50,
        name: keyword || undefined,
        code: keyword || undefined,
      });
      setTemplates(result.items);
      if (result.items.length > 0 && !selectedId) {
        setSelectedId(result.items[0].id);
      }
    } catch (err) {
      logger.error(`加载模板列表失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 选中项变化时加载详情
  useEffect(() => {
    if (!selectedId) return;
    const current = templates.find((t) => t.id === selectedId);
    if (current && current.content) {
      setSelectedTemplate(current);
      return;
    }
    const loadDetail = async () => {
      setDetailLoading(true);
      try {
        const detail = await announcementApi.getTemplateById(selectedId);
        setSelectedTemplate(detail);
      } catch (err) {
        logger.error(`加载模板详情失败: ${(err as Error).message}`);
      } finally {
        setDetailLoading(false);
      }
    };
    loadDetail();
  }, [selectedId, templates]);

  const handleSearch = () => {
    loadTemplates();
  };

  return (
    <div className="bg-card border border-border rounded-sm flex" style={{ minHeight: 520 }}>
      {/* 左侧模板列表 */}
      <div className="w-72 border-r border-border flex flex-col">
        <div className="p-3 border-b border-border">
          <div className="relative">
            <Search
              size={14}
              className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="搜索模板名称/编号"
              className="pl-7 h-8 text-xs"
            />
          </div>
          <div className="text-xs text-muted-foreground mt-2">
            共 {templates.length} 套模板
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="py-8 text-center text-muted-foreground text-xs">
              <Loader2
                size={16}
                className="animate-spin inline-block mr-1"
              />
              加载中...
            </div>
          ) : templates.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground text-xs">
              暂无模板
            </div>
          ) : (
            templates.map((tpl) => (
              <div
                key={tpl.id}
                onClick={() => setSelectedId(tpl.id)}
                className={`px-3 py-2.5 border-b border-border cursor-pointer transition-colors ${
                  selectedId === tpl.id
                    ? 'bg-accent/60 border-l-[3px] border-l-primary pl-[10px]'
                    : 'hover:bg-accent/30 border-l-[3px] border-l-transparent'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <FileText size={13} className="text-primary shrink-0" />
                  <span className="text-xs font-medium text-foreground truncate">
                    {tpl.code}
                  </span>
                  {tpl.needRemind && (
                    <Bell
                      size={11}
                      className="text-[hsl(38_85%_45%)] shrink-0"
                    />
                  )}
                </div>
                <div className="text-xs text-muted-foreground truncate mt-0.5 pl-[18px]">
                  {tpl.name}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 右侧预览区 */}
      <div className="flex-1 flex flex-col">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs font-mono bg-accent/50 border-transparent">
              {selectedTemplate?.code || '-'}
            </Badge>
            <span className="text-sm font-medium">
              {selectedTemplate?.name || '模板预览'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {selectedTemplate?.needRemind && (
              <Badge
                variant="outline"
                className="text-[hsl(38_85%_45%)] bg-[hsl(38_70%_94%)] border-transparent text-xs"
              >
                <Bell size={11} className="mr-1" />
                需提醒
              </Badge>
            )}
            <Badge variant="outline" className="text-xs font-mono">
              v{selectedTemplate?.version || '-'}
            </Badge>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {detailLoading || !selectedTemplate ? (
            <div className="py-16 text-center text-muted-foreground text-sm">
              <Loader2
                size={18}
                className="animate-spin inline-block mr-2"
              />
              加载中...
            </div>
          ) : (
            <div className="space-y-3">
              {selectedTemplate.note && (
                <div className="flex items-start gap-2 text-xs text-muted-foreground bg-accent/50 p-2.5 rounded-sm">
                  <Info size={14} className="shrink-0 mt-0.5 text-primary" />
                  <div>
                    <span className="font-medium text-foreground">使用说明：</span>
                    {selectedTemplate.note}
                  </div>
                </div>
              )}
              <div className="whitespace-pre-wrap text-sm leading-relaxed bg-accent/20 p-4 rounded-sm border border-border">
                {selectedTemplate.content || (
                  <span className="text-muted-foreground">暂无内容</span>
                )}
              </div>
            </div>
          )}
        </div>
        <div className="px-4 py-3 border-t border-border flex justify-end">
          <Button
            onClick={() => selectedId && onUseTemplate(selectedId)}
            disabled={!selectedId || usingTemplateId === selectedId}
          >
            {usingTemplateId === selectedId ? (
              <>
                <Loader2 size={14} className="mr-1 animate-spin" />
                创建中...
              </>
            ) : (
              <>
                <FileText size={14} className="mr-1" />
                使用此模板创建公告
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TemplateTab;
