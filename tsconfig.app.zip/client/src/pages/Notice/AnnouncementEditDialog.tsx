import { useState, useEffect } from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Label } from '@client/src/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar } from '@client/src/components/ui/calendar';

interface AnnouncementEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTitle: string;
  initialContent: string;
  initialDeadline: string;
  saving: boolean;
  onSaveDraft: (data: { title: string; content: string; publicityDeadline: string }) => void;
  onSubmitReview: (data: { title: string; content: string; publicityDeadline: string }) => void;
}

const AnnouncementEditDialog = ({
  open,
  onOpenChange,
  initialTitle,
  initialContent,
  initialDeadline,
  saving,
  onSaveDraft,
  onSubmitReview,
}: AnnouncementEditDialogProps) => {
  const [title, setTitle] = useState<string>(initialTitle);
  const [content, setContent] = useState<string>(initialContent);
  const [publicityDeadline, setPublicityDeadline] = useState<string>(initialDeadline);
  const [calendarOpen, setCalendarOpen] = useState<boolean>(false);

  // 同步外部初始值
  useEffect(() => {
    setTitle(initialTitle);
    setContent(initialContent);
    setPublicityDeadline(initialDeadline);
  }, [initialTitle, initialContent, initialDeadline]);

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    setPublicityDeadline(`${y}-${m}-${d}`);
    setCalendarOpen(false);
  };

  const data = { title, content, publicityDeadline };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>编辑公告</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>标题</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="请输入公告标题"
            />
          </div>
          <div className="space-y-1.5">
            <Label>正文</Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="请输入公告正文内容"
              rows={10}
            />
          </div>
          <div className="space-y-1.5">
            <Label>公示截止日</Label>
            <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start font-mono">
                  <CalendarIcon size={14} className="mr-2" />
                  {publicityDeadline || '请选择日期'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={publicityDeadline ? new Date(publicityDeadline) : undefined}
                  onSelect={handleDateSelect}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={saving}
          >
            取消
          </Button>
          <Button
            variant="secondary"
            onClick={() => onSaveDraft(data)}
            disabled={saving}
          >
            {saving ? '保存中...' : '保存草稿'}
          </Button>
          <Button onClick={() => onSubmitReview(data)} disabled={saving}>
            {saving ? '提交中...' : '提交审核'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AnnouncementEditDialog;
