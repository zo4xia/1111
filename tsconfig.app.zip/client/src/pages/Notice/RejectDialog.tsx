import { useState, useEffect } from 'react';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Textarea } from '@client/src/components/ui/textarea';
import { Label } from '@client/src/components/ui/label';

interface RejectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  loading: boolean;
  onConfirm: (comment: string) => void;
}

const RejectDialog = ({
  open,
  onOpenChange,
  title = '驳回公告',
  loading,
  onConfirm,
}: RejectDialogProps) => {
  const [comment, setComment] = useState<string>('');

  useEffect(() => {
    if (open) {
      setComment('');
    }
  }, [open]);

  const handleConfirm = () => {
    if (!comment.trim()) return;
    onConfirm(comment.trim());
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-2 py-2">
          <Label>
            驳回意见 <span className="text-[hsl(0_65%_50%)]">*</span>
          </Label>
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="请输入驳回意见，便于编辑人修改..."
            rows={5}
          />
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            取消
          </Button>
          <Button
            variant="destructive"
            onClick={handleConfirm}
            disabled={loading || !comment.trim()}
          >
            {loading ? '提交中...' : '确认驳回'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RejectDialog;
