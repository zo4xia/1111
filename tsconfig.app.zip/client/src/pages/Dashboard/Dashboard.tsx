import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { useElection } from '@client/src/contexts/ElectionContext';
import { dashboardApi } from '@client/src/api/dashboard';
import type { WorkstationData } from '@shared/api.interface';
import {
  FileText,
  Users,
  Calendar,
  Settings,
  UserCog,
  Vote,
  ClipboardList,
  Megaphone,
  Archive,
  ChevronRight,
  Plus,
  Bell,
  UserCheck,
} from 'lucide-react';

const DashboardPage = () => {
  const navigate = useNavigate();
  const { currentOrg, loading: ctxLoading } = useElection();
  const [data, setData] = useState<WorkstationData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!currentOrg) return;
    let mounted = true;

    (async () => {
      setLoading(true);
      setError(null);
      try {
        const result = await dashboardApi.getWorkstation(currentOrg.slug);
        if (mounted) setData(result);
      } catch (err) {
        logger.error(`加载工作台数据失败: ${(err as Error).message}`);
        if (mounted) setError((err as Error).message || '数据加载失败');
      } finally {
        if (mounted) setLoading(false);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [currentOrg]);

  const currentStage = useMemo(() => {
    if (!data?.stages.length) return null;
    const active = data.stages.find((s) => s.status === '办理中');
    if (active) return active;
    const pending = data.stages.find((s) => s.status === '未开始');
    if (pending) return pending;
    return data.stages[data.stages.length - 1];
  }, [data?.stages]);

  const pendingStageCount = useMemo(() => {
    if (!data?.stages.length) return 0;
    return data.stages.filter((s) => !s.planStart || s.status === '未开始').length;
  }, [data?.stages]);

  if (ctxLoading || !currentOrg) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        加载中...
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-sm text-red-700">
        {error}
      </div>
    );
  }

  const { currentElection, elections, proposals, positions, roster, stats, stages } = data || {
    currentElection: null,
    elections: [],
    proposals: [],
    positions: [],
    roster: [],
    stats: { pendingMaterials: 0, passedCandidates: 0, publishedAnnouncements: 0, archives: 0 },
    stages: [],
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-bold text-foreground">
            {currentOrg.name} · 工作台
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {currentOrg.town} · 换届选举管理驾驶舱
          </p>
        </div>
        {currentElection && (
          <div className="text-sm text-muted-foreground">
            当前届次：
            <span className="font-semibold text-foreground ml-1">
              {currentElection.term}
            </span>
            <span className="ml-2 px-2 py-0.5 bg-info/10 text-info rounded-full text-xs font-medium">
              进行中
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1.6fr_1fr] gap-4">
        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 bg-destructive rounded-sm" />
              <h3 className="text-sm font-bold text-foreground">选举日程</h3>
            </div>
            <span className="text-xs text-muted-foreground">
              共 {stages.length} 个阶段
            </span>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-7 gap-1.5 mb-2">
              {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((wd) => (
                <div
                  key={wd}
                  className="text-center text-xs font-semibold text-muted-foreground py-1"
                >
                  {wd}
                </div>
              ))}
            </div>
            <StageWeek stages={stages} />
            {currentStage && (
              <div
                className="mt-4 p-3 bg-info/5 border-l-2 border-info rounded-r-sm"
                style={{ borderLeftColor: 'hsl(217 65% 32%)' }}
              >
                <p className="text-sm text-foreground">
                  <span className="text-muted-foreground">当前阶段：</span>
                  <span className="font-semibold">{currentStage.stageName}</span>
                  {currentStage.planStart && (
                    <span className="text-xs text-muted-foreground ml-2">
                      起于 {currentStage.planStart}
                    </span>
                  )}
                  {pendingStageCount > 0 && (
                    <span className="text-xs text-destructive ml-2">
                      （另有 {pendingStageCount} 个阶段时间待公示）
                    </span>
                  )}
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 bg-success rounded-sm" />
              <h3 className="text-sm font-bold text-foreground">管理员配置</h3>
            </div>
            <button
              className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
              onClick={() => navigate('/user')}
            >
              管理 <ChevronRight size={12} />
            </button>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-2 gap-3">
              <div
                className="flex items-center gap-3 p-3 bg-success/5 border border-success/20 rounded-sm cursor-pointer hover:translate-y-[-2px] transition-transform"
                onClick={() => navigate('/user')}
              >
                <div className="w-10 h-10 rounded-full bg-success text-white flex items-center justify-center font-bold text-base flex-shrink-0">
                  管
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">
                    当前角色
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    编辑我的信息 →
                  </div>
                </div>
              </div>
              <div
                className="flex items-center gap-3 p-3 bg-info/5 border border-info/20 rounded-sm cursor-pointer hover:translate-y-[-2px] transition-transform"
                onClick={() => navigate('/user')}
              >
                <div className="w-10 h-10 rounded-full bg-info text-white flex items-center justify-center flex-shrink-0">
                  <Settings size={18} />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">
                    账号配置
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    管理各角色账号 →
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-3 min-h-[60px] border border-dashed border-border rounded-sm flex flex-col items-center justify-center gap-1 text-muted-foreground">
              <UserCheck size={18} className="opacity-40" />
              <div className="text-xs opacity-60">预留扩展区</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 bg-destructive rounded-sm" />
              <h3 className="text-sm font-bold text-foreground">提案审批</h3>
            </div>
            <button
              className="text-xs px-2.5 py-1 bg-destructive text-destructive-foreground rounded-sm font-medium hover:opacity-90 transition-opacity flex items-center gap-1"
              onClick={() => navigate('/proposal')}
            >
              <Plus size={12} /> 新建
            </button>
          </div>
          <div className="p-3">
            {loading ? (
              <div className="py-8 text-center text-muted-foreground text-sm">加载中...</div>
            ) : proposals.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">暂无提案</div>
            ) : (
              proposals.slice(0, 5).map((p) => (
                <div
                  key={p.id}
                  className="flex items-center gap-2 py-2.5 border-b border-dashed border-border last:border-b-0"
                >
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${
                      p.status === 'approved'
                        ? 'bg-success/10 text-success'
                        : p.status === 'rejected'
                          ? 'bg-destructive/10 text-destructive'
                          : 'bg-warning/10 text-warning'
                    }`}
                  >
                    {p.status === 'approved'
                      ? '通过'
                      : p.status === 'rejected'
                        ? '驳回'
                        : p.status === 'submitted' || p.status === 'pending'
                          ? '待审批'
                          : '草稿'}
                  </span>
                  <span className="flex-1 text-sm text-foreground truncate">{p.title}</span>
                  <button
                    className="text-xs text-info hover:text-destructive transition-colors flex-shrink-0"
                    onClick={() => navigate('/proposal')}
                  >
                    查看
                  </button>
                </div>
              ))
            )}
            {proposals.length > 5 && (
              <div className="text-center pt-2">
                <button
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => navigate('/proposal')}
                >
                  查看更多 →
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 bg-destructive rounded-sm" />
              <h3 className="text-sm font-bold text-foreground">选举活动列表</h3>
            </div>
          </div>
          <div className="p-3">
            {loading ? (
              <div className="py-8 text-center text-muted-foreground text-sm">加载中...</div>
            ) : elections.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">暂无选举活动</div>
            ) : (
              elections.map((e) => (
                <div
                  key={e.id}
                  className="flex items-center justify-between gap-2 p-3 mb-2 last:mb-0 bg-muted/50 rounded-sm cursor-pointer hover:bg-destructive/5 transition-colors"
                  onClick={() => {
                    navigate('/election');
                  }}
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-foreground truncate">
                      {e.name}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {e.status === 'in_progress' ? '进行中' : '已归档'}
                    </div>
                  </div>
                  <span
                    className={`text-xs font-semibold whitespace-nowrap ${
                      e.status === 'in_progress' ? 'text-destructive' : 'text-muted-foreground'
                    }`}
                  >
                    {e.status === 'in_progress' ? '进入管理 →' : '查看 →'}
                  </span>
                </div>
              ))
            )}
            <div className="text-center pt-2">
              <button
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => navigate('/election')}
              >
                查看更多 →
              </button>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 bg-destructive rounded-sm" />
              <h3 className="text-sm font-bold text-foreground">本期选举岗位</h3>
            </div>
            <button
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => navigate('/position')}
            >
              管理 →
            </button>
          </div>
          <div className="p-3">
            {loading ? (
              <div className="py-8 text-center text-muted-foreground text-sm">加载中...</div>
            ) : positions.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground text-sm">暂无岗位数据</div>
            ) : (
              positions.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between py-2.5 border-b border-dashed border-border last:border-b-0"
                >
                  <div>
                    <span className="text-sm font-semibold text-foreground">{p.type}</span>
                    <span className="text-xs text-muted-foreground ml-2">
                      需求 {p.quota} 人
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium bg-info/10 text-info">
                    <span className="w-1.5 h-1.5 rounded-full bg-current" />
                    竞选报名
                  </span>
                </div>
              ))
            )}
            <div className="mt-2 p-2.5 bg-gold/5 border border-gold/20 rounded-sm text-xs text-gold-foreground">
              💡 点岗位可进入对应操作：在岗→花名册，竞选报名→材料/公告
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_1.4fr] gap-4">
        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 rounded-sm" style={{ background: 'hsl(280 40% 45%)' }} />
              <h3 className="text-sm font-bold text-foreground">当期干部花名册</h3>
            </div>
            <button
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              onClick={() => navigate('/result')}
            >
              历史名录 →
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr
                  className="text-left text-xs font-bold"
                  style={{ background: 'hsl(42 70% 95%)', color: 'hsl(38 85% 40%)' }}
                >
                  <th className="px-4 py-2.5 font-bold">岗位</th>
                  <th className="px-4 py-2.5 font-bold">姓名</th>
                  <th className="px-4 py-2.5 font-bold">联系方式</th>
                  <th className="px-4 py-2.5 font-bold">本届任期</th>
                </tr>
              </thead>
              <tbody>
                {loading || roster.length === 0 ? (
                  <tr>
                    <td
                      colSpan={4}
                      className="text-center text-muted-foreground py-8 text-sm"
                    >
                      {loading ? '加载中...' : '暂无数据'}
                    </td>
                  </tr>
                ) : (
                  roster.map((r) => (
                    <tr key={r.id} className="border-b border-border last:border-b-0 hover:bg-accent/50 transition-colors">
                      <td className="px-4 py-2.5 text-foreground">{r.position}</td>
                      <td className="px-4 py-2.5 text-foreground font-medium">{r.name}</td>
                      <td className="px-4 py-2.5 text-muted-foreground">
                        {r.phone || '—'}
                      </td>
                      <td className="px-4 py-2.5 text-muted-foreground">{r.term}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-card border border-border rounded-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 rounded-sm" style={{ background: 'hsl(280 40% 45%)' }} />
              <h3 className="text-sm font-bold text-foreground">岗位换届状态</h3>
            </div>
            <span className="text-xs text-muted-foreground">
              {currentElection?.term || '—'}
            </span>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-2 gap-3">
              <div
                className="p-4 bg-info/5 rounded-sm cursor-pointer hover:bg-info/10 transition-colors"
                onClick={() => navigate('/material')}
              >
                <div className="flex items-center gap-2 text-info text-xs font-semibold mb-1">
                  <FileText size={14} /> 竞选材料
                </div>
                <div className="text-2xl font-bold text-foreground">
                  {stats.pendingMaterials}
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    份待审
                  </span>
                </div>
              </div>
              <div
                className="p-4 bg-destructive/5 rounded-sm cursor-pointer hover:bg-destructive/10 transition-colors"
                onClick={() => navigate('/candidate')}
              >
                <div className="flex items-center gap-2 text-destructive text-xs font-semibold mb-1">
                  <Users size={14} /> 候选人
                </div>
                <div className="text-2xl font-bold text-foreground">
                  {stats.passedCandidates}
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    已入围
                  </span>
                </div>
              </div>
              <div
                className="p-4 bg-warning/5 rounded-sm cursor-pointer hover:bg-warning/10 transition-colors"
                onClick={() => navigate('/notice')}
              >
                <div className="flex items-center gap-2 text-warning text-xs font-semibold mb-1">
                  <Megaphone size={14} /> 阶段公告
                </div>
                <div className="text-2xl font-bold text-foreground">
                  {stats.publishedAnnouncements}
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    条已发
                  </span>
                </div>
              </div>
              <div
                className="p-4 bg-success/5 rounded-sm cursor-pointer hover:bg-success/10 transition-colors"
                onClick={() => navigate('/archive')}
              >
                <div className="flex items-center gap-2 text-success text-xs font-semibold mb-1">
                  <Archive size={14} /> 归档件
                </div>
                <div className="text-2xl font-bold text-foreground">
                  {stats.archives}
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    份
                  </span>
                </div>
              </div>
            </div>
            <div className="mt-3 p-3 bg-muted/50 rounded-sm text-xs text-muted-foreground flex items-center gap-2">
              <Bell size={14} className="text-info flex-shrink-0" />
              <span>
                提示：点击以上卡片可进入对应业务模块进行审核与管理操作
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface StageWeekProps {
  stages: Array<{
    stageKey: string;
    stageName: string;
    status: string;
    planStart: string;
    planEnd: string;
    order: number;
  }>;
}

const StageWeek = ({ stages }: StageWeekProps) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const monday = new Date(today);
  const dayOfWeek = monday.getDay();
  const diff = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  monday.setDate(monday.getDate() + diff);

  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d;
  });

  const formatDate = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };

  const stageForDate = (dateStr: string) => {
    return stages.find((s) => {
      if (!s.planStart) return false;
      if (s.planStart === dateStr) return true;
      if (s.planEnd && dateStr >= s.planStart && dateStr <= s.planEnd) return true;
      return false;
    });
  };

  return (
    <div className="grid grid-cols-7 gap-1.5">
      {weekDays.map((d, i) => {
        const dateStr = formatDate(d);
        const isToday = dateStr === formatDate(today);
        const stage = stageForDate(dateStr);
        const hasStage = !!stage;

        return (
          <div
            key={i}
            className={`text-center rounded-sm p-2 min-h-[72px] flex flex-col items-center gap-1 ${
              isToday
                ? 'bg-destructive/5 border border-destructive'
                : hasStage
                  ? 'bg-destructive/5 border border-destructive/30'
                  : 'bg-muted/50 border border-transparent'
            }`}
          >
            <div className="relative">
              <span
                className={`text-base font-bold ${
                  isToday ? 'text-destructive' : hasStage ? 'text-destructive' : 'text-muted-foreground'
                }`}
                style={{ fontFamily: 'var(--font-serif)' }}
              >
                {d.getDate()}
              </span>
              {hasStage && (
                <span className="absolute -top-1 -right-2 w-2 h-2 rounded-full bg-destructive border-2 border-white" />
              )}
            </div>
            {stage ? (
              <div className="text-[10px] leading-tight px-1 py-0.5 rounded bg-destructive text-white font-medium truncate w-full">
                {stage.stageName}
              </div>
            ) : (
              <div className="text-[10px] text-muted-foreground opacity-50">—</div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default DashboardPage;
