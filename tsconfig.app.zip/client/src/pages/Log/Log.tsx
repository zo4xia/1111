import { useState, useEffect } from 'react';
import {
  FileTextOutlined,
  SearchOutlined,
  CalendarOutlined,
} from '@ant-design/icons';
import { toast } from 'sonner';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import {
  Table,
  Tag,
  Button,
  Input,
  Select,
  DatePicker,
  Empty,
  Card,
  Space,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { logApi, LOG_TYPE_OPTIONS, LOG_TYPE_LABELS, type OperationLog } from '@/api/log';
import dayjs from 'dayjs';

const { RangePicker } = DatePicker;

const LogPage = () => {
  const [logs, setLogs] = useState<OperationLog[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [operator, setOperator] = useState('');
  const [type, setType] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    void loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const result = await logApi.list({
        operator: operator || undefined,
        type: type || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        page: 1,
        pageSize: 50,
      });
      setLogs(result.items);
      setTotal(result.total);
    } catch (error) {
      toast.error('加载日志列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    void loadLogs();
  };

  const handleReset = () => {
    setOperator('');
    setType('');
    setStartDate('');
    setEndDate('');
    setTimeout(() => {
      void loadLogs();
    }, 0);
  };

  const getTypeTag = (logType: string) => {
    const colorMap: Record<string, string> = {
      login: 'blue',
      create: 'green',
      update: 'gold',
      delete: 'red',
      approve: 'blue',
      export: 'default',
    };
    const color = colorMap[logType] || 'gold';
    return <Tag color={color}>{LOG_TYPE_LABELS[logType] || logType}</Tag>;
  };

  const columns: ColumnsType<OperationLog> = [
    {
      title: '操作时间',
      dataIndex: 'operationTime',
      key: 'operationTime',
      width: 176,
      render: (text: string) => (
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
          {dayjs(text).format('YYYY-MM-DD HH:mm:ss')}
        </span>
      ),
    },
    {
      title: '操作人',
      dataIndex: 'operator',
      key: 'operator',
      width: 112,
    },
    {
      title: '操作类型',
      dataIndex: 'type',
      key: 'type',
      width: 96,
      render: (logType: string) => getTypeTag(logType),
    },
    {
      title: '操作对象',
      dataIndex: 'target',
      key: 'target',
      width: 128,
    },
    {
      title: '操作摘要',
      dataIndex: 'summary',
      key: 'summary',
      render: (text: string) => (
        <span style={{ fontSize: 13, color: '#6B7280' }}>{text}</span>
      ),
    },
    {
      title: 'IP地址',
      dataIndex: 'ip',
      key: 'ip',
      width: 128,
      render: (text: string) => (
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
          {text}
        </span>
      ),
    },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <PageBreadcrumb items={[{ label: '日志管理' }]} />
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: '#1F2937', margin: 0 }}>
          日志管理
        </h1>
        <p style={{ fontSize: 14, color: '#6B7280', marginTop: 4, marginBottom: 0 }}>
          查看系统操作日志与审计记录
        </p>
      </div>

      <Card
        styles={{ body: { padding: 0 } }}
        title={
          <Space size={16} wrap>
            <Space size={8}>
              <span
                style={{
                  fontSize: 14,
                  color: '#6B7280',
                  width: 64,
                  display: 'inline-block',
                  whiteSpace: 'nowrap',
                }}
              >
                操作人
              </span>
              <Input
                value={operator}
                onChange={(e) => setOperator(e.target.value)}
                placeholder="请输入操作人"
                style={{ width: 160 }}
                allowClear
              />
            </Space>
            <Space size={8}>
              <span
                style={{
                  fontSize: 14,
                  color: '#6B7280',
                  width: 64,
                  display: 'inline-block',
                  whiteSpace: 'nowrap',
                }}
              >
                操作类型
              </span>
              <Select
                value={type}
                onChange={setType}
                placeholder="全部类型"
                style={{ width: 128 }}
                allowClear
              >
                <Select.Option value="">全部类型</Select.Option>
                {LOG_TYPE_OPTIONS.map((opt) => (
                  <Select.Option key={opt.value} value={opt.value}>
                    {opt.label}
                  </Select.Option>
                ))}
              </Select>
            </Space>
            <Space size={8}>
              <span
                style={{
                  fontSize: 14,
                  color: '#6B7280',
                  display: 'inline-block',
                  whiteSpace: 'nowrap',
                }}
              >
                <CalendarOutlined style={{ marginRight: 4 }} />
                时间范围
              </span>
              <RangePicker
                value={
                  startDate && endDate
                    ? [dayjs(startDate), dayjs(endDate)]
                    : null
                }
                onChange={(dates) => {
                  if (dates && dates[0] && dates[1]) {
                    setStartDate(dates[0].format('YYYY-MM-DD'));
                    setEndDate(dates[1].format('YYYY-MM-DD'));
                  } else {
                    setStartDate('');
                    setEndDate('');
                  }
                }}
                style={{ width: 280 }}
              />
            </Space>
          </Space>
        }
        extra={
          <Space>
            <Button onClick={handleReset}>重置</Button>
            <Button type="primary" icon={<SearchOutlined />} onClick={handleSearch}>
              查询
            </Button>
          </Space>
        }
        headStyle={{ padding: '12px 16px' }}
      >
        <div style={{ padding: 16 }}>
          <Table<OperationLog>
            rowKey="id"
            columns={columns}
            dataSource={logs}
            loading={loading}
            locale={{
              emptyText: (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description={
                    <span>
                      <FileTextOutlined style={{ marginRight: 6 }} />
                      暂无日志
                    </span>
                  }
                >
                  <span style={{ color: '#6B7280', fontSize: 12 }}>
                    当前没有找到相关操作日志
                  </span>
                </Empty>
              ),
            }}
            pagination={{
              total,
              pageSize: 10,
              showSizeChanger: false,
              showTotal: (t) => `共 ${t} 条记录`,
            }}
            size="small"
          />
        </div>
      </Card>
    </div>
  );
};

export default LogPage;
