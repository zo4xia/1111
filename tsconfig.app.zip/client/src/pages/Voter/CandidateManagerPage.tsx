import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  UserPlus,
  Search,
  FileCheck,
  Send,
  FileText,
} from 'lucide-react';
import {
  Button,
  Input,
  Select,
  Tabs,
  Card,
  Tag,
  Space,
  Table,
  Modal,
  Form,
  message,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { voterApi } from '@client/src/api/voter';
import { materialApi } from '@client/src/api/material';
import type { Voter } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';

const MATERIAL_STATUS_TABS = [
  { key: 'all', label: '全部' },
  { key: 'none', label: '未提交' },
  { key: 'submitted', label: '待审核' },
  { key: 'resubmitted', label: '重新提交' },
  { key: 'needs_correction', label: '需补正' },
  { key: 'approved', label: '通过' },
  { key: 'rejected', label: '驳回' },
];

const SOURCE_OPTIONS = [
  { value: '', label: '全部来源' },
  { value: 'self', label: '个人自荐' },
  { value: 'org_recommend', label: '组织推荐' },
];

const MATERIAL_TYPE_OPTIONS = [
  { value: '身份证', label: '身份证' },
  { value: '学历证明', label: '学历证明' },
  { value: '无犯罪记录', label: '无犯罪记录' },
  { value: '计生证明', label: '计生证明' },
  { value: '联审联查表', label: '联审联查表' },
];

function getSourceInfo(source: string) {
  const map: Record<string, { label: string; color: string }> = {
    self: { label: '个人自荐', color: 'blue' },
    org_recommend: { label: '组织推荐', color: 'gold' },
    registered: { label: '登记在册', color: 'default' },
  };
  return map[source] || { label: source || '登记在册', color: 'default' };
}

function getMaterialStatusInfo(status: string) {
  const map: Record<string, { label: string; color: string }> = {
    none: { label: '未提交', color: 'default' },
    submitted: { label: '待审核', color: 'processing' },
    resubmitted: { label: '重新提交', color: 'processing' },
    needs_correction: { label: '需补正', color: 'warning' },
    approved: { label: '通过', color: 'success' },
    rejected: { label: '驳回', color: 'error' },
  };
  return map[status] || { label: status, color: 'default' };
}

const CandidatePage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [list, setList] = useState<Voter[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);

  const [activeTab, setActiveTab] = useState<string>('all');
  const [searchText, setSearchText] = useState<string>('');
  const [sourceFilter, setSourceFilter] = useState<string>('');
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;

  const [submitOpen, setSubmitOpen] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [currentRow, setCurrentRow] = useState<Voter | null>(null);
  const [form] = Form.useForm();

  const loadList = useCallback(async () => {
    if (!currentOrg || !currentElection) return;
    setLoading(true);
    try {
      const params: Record<string, unknown> = {
        electionId: currentElection.id,
        orgId: currentOrg.slug,
        page,
        pageSize,
      };
      if (activeTab !== 'all') params.materialStatus = activeTab;
      if (searchText.trim()) params.search = searchText.trim();
      if (sourceFilter) params.source = sourceFilter;

      const result = await voterApi.list(params);
      setList(result.items);
      setTotal(result.total);
    } catch (err) {
      logger.error(`加载参选人列表失败: ${(err as Error).message}`);
    } finally {
      setLoading(false);
    }
  }, [currentOrg, currentElection, activeTab, searchText, sourceFilter, page]);

  useEffect(() => {
    if (!currentOrg || !currentElection) return;
    setPage(1);
    loadList();
  }, [currentOrg, currentElection, activeTab, sourceFilter, loadList]);

  useEffect(() => {
    if (!currentOrg || !currentElection) return;
    loadList();
  }, [page, loadList]);

  const handleSearch = () => {
    setPage(1);
    loadList();
  };

  const handleOpenSubmit = (row: Voter) => {
    setCurrentRow(row);
    form.resetFields();
    form.setFieldsValue({
      type: '身份证',
      applicant: row.name,
      applicantPhone: row.phone,
      position: row.positionId,
      content: '',
    });
    setSubmitOpen(true);
  };

  const handleSubmitMaterial = async () => {
    if (!currentRow || !currentOrg || !currentElection) return;
    setSubmitting(true);
    try {
      const values = await form.validateFields();
      await materialApi.create({
        ...values,
        orgId: currentOrg.slug,
        electionId: currentElection.id,
        submitter: values.applicant || currentRow.name,
        applicantId: currentRow.id,
      });
      message.success('材料提交成功，已进入审核');
      setSubmitOpen(false);
      await voterApi.update(currentRow.id, { materialStatus: 'submitted' });
      await loadList();
    } catch (err) {
      logger.error(`提交材料失败: ${(err as Error).message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const columns: ColumnsType<Voter> = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      width: 120,
      render: (v: string) => <strong>{v}</strong>,
    },
    { title: '性别', dataIndex: 'gender', key: 'gender', width: 80 },
    { title: '年龄', dataIndex: 'age', key: 'age', width: 80 },
    { title: '电话', dataIndex: 'phone', key: 'phone', width: 130 },
    {
      title: '参选岗位',
      dataIndex: 'positionId',
      key: 'positionId',
      width: 120,
      render: (v: string) => v || <span style={{ color: '#999' }}>未选择</span>,
    },
    {
      title: '来源',
      dataIndex: 'source',
      key: 'source',
      width: 120,
      render: (v: string) => {
        const info = getSourceInfo(v);
        return <Tag color={info.color}>{info.label}</Tag>;
      },
    },
    {
      title: '材料状态',
      dataIndex: 'materialStatus',
      key: 'materialStatus',
      width: 110,
      render: (v: string) => {
        const info = getMaterialStatusInfo(v);
        return <Tag color={info.color}>{info.label}</Tag>;
      },
    },
    {
      title: '操作',
      key: 'action',
      width: 200,
      align: 'right',
      fixed: 'right',
      render: (_, record: Voter) => (
        <Space size="small" wrap>
          <Button
            type="text"
            size="small"
            icon={<FileText size={14} />}
            onClick={() => handleOpenSubmit(record)}
          >
            提交材料
          </Button>
        </Space>
      ),
    },
  ];

  if (ctxLoading)
    return (
      <div className="space-y-4 text-sm text-muted-foreground">加载中...</div>
    );
  if (!currentOrg) {
    return (
      <div className="space-y-4">
        <div className="bg-card border border-border rounded-sm p-12 flex flex-col items-center justify-center text-muted-foreground">
          <div className="text-sm">暂无组织数据</div>
        </div>
      </div>
    );
  }

  const tabItems = MATERIAL_STATUS_TABS.map((t) => ({
    key: t.key,
    label: t.label,
  }));

  const statsApproved = list.filter((v) => v.materialStatus === 'approved').length;
  const statsSubmitted = list.filter(
    (v) => v.materialStatus === 'submitted' || v.materialStatus === 'resubmitted',
  ).length;
  const statsNone = list.filter((v) => !v.materialStatus || v.materialStatus === 'none').length;

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '参选人管理' }]} />
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">参选人管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {currentOrg.name} · 参选报名与材料提交跟踪
          </p>
        </div>
        <Button type="primary" icon={<UserPlus size={16} />}>
          新增参选
        </Button>
      </div>

      <div data-ai-section-type="card-stat">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          <Card size="small">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: '#6B7280' }}>参选总人数</span>
              <FileCheck size={14} style={{ color: '#8c1f28' }} />
            </div>
            <div style={{ fontSize: 26, fontWeight: 700, color: '#8c1f28', marginTop: 4 }}>
              {total}
            </div>
          </Card>
          <Card size="small">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: '#6B7280' }}>未提交材料</span>
              <Send size={14} style={{ color: '#999' }} />
            </div>
            <div style={{ fontSize: 26, fontWeight: 700, color: '#999', marginTop: 4 }}>
              {activeTab === 'all' ? statsNone : '-'}
            </div>
          </Card>
          <Card size="small">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: '#6B7280' }}>待审核</span>
              <Send size={14} style={{ color: '#1890ff' }} />
            </div>
            <div style={{ fontSize: 26, fontWeight: 700, color: '#1890ff', marginTop: 4 }}>
              {activeTab === 'all' ? statsSubmitted : '-'}
            </div>
          </Card>
          <Card size="small">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: '#6B7280' }}>材料通过</span>
              <FileCheck size={14} style={{ color: '#52c41a' }} />
            </div>
            <div style={{ fontSize: 26, fontWeight: 700, color: '#52c41a', marginTop: 4 }}>
              {activeTab === 'all' ? statsApproved : '-'}
            </div>
          </Card>
        </div>
      </div>

      <Card size="small" className="!p-0">
        <div className="px-4 pt-3 pb-2 flex flex-wrap items-center gap-3">
          <Input
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSearch();
            }}
            placeholder="搜索姓名或身份证号"
            prefix={<Search size={14} style={{ color: '#6B7280' }} />}
            style={{ width: 240 }}
            allowClear
          />
          <Select
            value={sourceFilter}
            onChange={setSourceFilter}
            placeholder="全部来源"
            style={{ width: 140 }}
            options={SOURCE_OPTIONS}
          />
          <Button type="default" onClick={handleSearch}>
            搜索
          </Button>
        </div>

        <div className="px-4">
          <Tabs
            activeKey={activeTab}
            onChange={setActiveTab}
            items={tabItems}
            size="small"
          />
        </div>

        <Table<Voter>
          rowKey="id"
          columns={columns}
          dataSource={list}
          loading={loading}
          pagination={false}
          size="small"
          scroll={{ x: 900 }}
        />

        {!loading && total > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <div className="text-xs text-muted-foreground">
              共 {total} 条，第 {page} / {Math.max(1, Math.ceil(total / pageSize))} 页
            </div>
            <Space>
              <Button
                size="small"
                disabled={page <= 1}
                onClick={() =>
                  setPage(Math.max(1, page - 1))
                }
              >
                上一页
              </Button>
              <Button
                size="small"
                disabled={page >= Math.max(1, Math.ceil(total / pageSize))}
                onClick={() =>
                  setPage(Math.min(Math.max(1, Math.ceil(total / pageSize)), page + 1))
                }
              >
                下一页
              </Button>
            </Space>
          </div>
        )}
      </Card>

      <Modal
        title="提交参选材料"
        open={submitOpen}
        onCancel={() => setSubmitOpen(false)}
        onOk={handleSubmitMaterial}
        confirmLoading={submitting}
        okText="提交审核"
        cancelText="取消"
        width={520}
      >
        <Form form={form} layout="vertical">
          <Form.Item label="参选人">
            <Form.Item noStyle name="applicant">
              <Input disabled />
            </Form.Item>
          </Form.Item>
          <Form.Item label="材料类型" name="type" rules={[{ required: true, message: '请选择材料类型' }]}>
            <Select options={MATERIAL_TYPE_OPTIONS} />
          </Form.Item>
          <Form.Item label="申报岗位" name="position">
            <Input placeholder="例如：主任/副主任/委员" />
          </Form.Item>
          <Form.Item label="联系电话" name="applicantPhone">
            <Input />
          </Form.Item>
          <Form.Item label="材料内容/说明" name="content">
            <Input.TextArea rows={4} placeholder="请填写材料说明或备注" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default CandidatePage;
