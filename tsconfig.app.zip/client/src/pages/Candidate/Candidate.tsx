import { useState, useEffect, useMemo } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';
import { toast } from 'sonner';
import { UserCheck, CheckCircle2, Clock, Circle, Lock, Plus, Edit2, Trash2 } from 'lucide-react';
import { useElection } from '@client/src/contexts/ElectionContext';
import { candidateApi } from '@client/src/api/candidate';
import type { Candidate, CandidateDetail, CandidateCreateDto, CandidateUpdateDto } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import {
  Tabs,
  Card,
  Statistic,
  Table,
  Tag,
  Modal,
  Descriptions,
  Select,
  Input,
  Button,
  Row,
  Col,
  Space,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';

const POSITION_TABS = ['全部', '主任', '副主任', '委员'];
const ROUND_NAMES = ['材料完整性', '镇级初审', '区级联审', '党委考察'];

const STATUS_TAG_COLOR: Record<string, string> = {
  通过: 'success',
  不通过: 'error',
  待审核: 'processing',
  已通过: 'success',
  驳回: 'error',
  未通过: 'error',
};

const STATUS_LABEL: Record<string, string> = {
  通过: '通过',
  不通过: '驳回',
  待审核: '待审',
  已通过: '通过',
  驳回: '驳回',
  未通过: '驳回',
};

const OVERALL_TAG_COLOR: Record<string, string> = {
  已通过: 'success',
  已淘汰: 'error',
  审核中: 'processing',
};

const OVERALL_LABEL: Record<string, string> = {
  已通过: '已通过',
  已淘汰: '已淘汰',
  审核中: '审核中',
};

function getStatusTagColor(status: string): string {
  return STATUS_TAG_COLOR[status] || 'default';
}

function getStatusLabel(status: string): string {
  return STATUS_LABEL[status] || status;
}

function getOverallTagColor(status: string): string {
  return OVERALL_TAG_COLOR[status] || 'default';
}

function getOverallLabel(status: string): string {
  return OVERALL_LABEL[status] || status;
}

function isPassed(status: string): boolean {
  return status === '通过' || status === '已通过';
}

function getRoundStats(list: Candidate[]) {
  return [0, 1, 2, 3].map((idx) => {
    let pending = 0, pass = 0, reject = 0;
    for (const c of list) {
      const s = [c.r1Status, c.r2Status, c.r3Status, c.r4Status][idx];
      if (isPassed(s)) pass += 1;
      else if (s === '不通过' || s === '驳回' || s === '未通过') reject += 1;
      else pending += 1;
    }
    return { round: idx + 1, name: ROUND_NAMES[idx], pendingCount: pending, passCount: pass, rejectCount: reject };
  });
}

function findNextPendingRound(detail: CandidateDetail): number {
  const statuses = [detail.r1Status, detail.r2Status, detail.r3Status, detail.r4Status];
  for (let i = 0; i < 4; i += 1) {
    if (statuses[i] === '待审核' || statuses[i] === '') {
      if (i === 0 || isPassed(statuses[i - 1])) return i + 1;
    }
  }
  return 1;
}

const CandidatePage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [position, setPosition] = useState<string>('全部');
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [detail, setDetail] = useState<CandidateDetail | null>(null);
  const [round, setRound] = useState<number>(1);
  const [result, setResult] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const [formOpen, setFormOpen] = useState<boolean>(false);
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create');
  const [editingCandidate, setEditingCandidate] = useState<Candidate | null>(null);
  const [formLoading, setFormLoading] = useState<boolean>(false);
  const [formData, setFormData] = useState<Partial<CandidateCreateDto>>({});

  useEffect(() => {
    if (!currentOrg) return;
    let mounted = true;
    (async () => {
      setLoading(true);
      try {
         const data = await candidateApi.list({
           orgId: currentOrg.slug,
           electionId: currentElection?.id,
           position: position === '全部' ? undefined : position,
           pageSize: 200,
         });
         if (mounted) setCandidates(data.items);
      } catch (err) {
        logger.error(`加载候选人列表失败: ${(err as Error).message}`);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [currentOrg, currentElection, position]);

  const roundStats = useMemo(() => getRoundStats(candidates), [candidates]);

  const refreshList = async () => {
    if (!currentOrg) return;
     const data = await candidateApi.list({
       orgId: currentOrg.slug,
       electionId: currentElection?.id,
       position: position === '全部' ? undefined : position,
       pageSize: 200,
     });
     setCandidates(data.items);
  };

  const openReview = async (cand: Candidate) => {
    try {
      const d = await candidateApi.getById(cand.id);
      setDetail(d);
      setRound(findNextPendingRound(d));
      setResult('');
      setComment('');
      setDialogOpen(true);
    } catch (err) {
      logger.error(`加载候选人详情失败: ${(err as Error).message}`);
    }
  };

   const handleSubmit = async () => {
     if (!detail || !result) return;
     setSubmitting(true);
     try {
       await candidateApi.review(detail.id, round, result, comment, '审核员');
       toast.success('审核提交成功');
       await refreshList();
       setDialogOpen(false);
       setDetail(null);
     } catch (err) {
       logger.error(`审核失败: ${(err as Error).message}`);
       toast.error((err as Error).message || '审核失败');
     } finally {
       setSubmitting(false);
     }
   };

   const openCreate = () => {
     setFormMode('create');
     setFormData({ position: position === '全部' ? '' : position, source: '选民联名', gender: '男' });
     setEditingCandidate(null);
     setFormOpen(true);
   };

   const openEdit = (cand: Candidate) => {
     setFormMode('edit');
     setEditingCandidate(cand);
     setFormData({
       name: cand.name,
       gender: cand.gender,
       age: cand.age,
       position: cand.position,
       source: cand.source,
     });
     setFormOpen(true);
   };

   const handleFormSubmit = async () => {
     if (!formData.name) {
       toast.error('姓名不能为空');
       return;
     }
     setFormLoading(true);
     try {
       const payload: CandidateCreateDto = {
         name: formData.name || '',
         gender: formData.gender || '男',
         age: Number(formData.age) || 0,
         position: formData.position || '',
         source: formData.source || '',
         orgId: currentOrg?.slug || '',
         electionId: currentElection?.id || '',
       };
       if (formMode === 'create') {
         await candidateApi.create(payload);
         toast.success('候选人创建成功');
       } else if (editingCandidate) {
         await candidateApi.update(editingCandidate.id, payload as CandidateUpdateDto);
         toast.success('候选人更新成功');
       }
       setFormOpen(false);
       await refreshList();
     } catch (err) {
       logger.error(`保存候选人失败: ${(err as Error).message}`);
       toast.error((err as Error).message || '保存失败');
     } finally {
       setFormLoading(false);
     }
   };

   const handleDelete = async (cand: Candidate) => {
     if (!(await showConfirm(`确定删除候选人"${cand.name}"吗？此操作不可撤销。`))) return;
     try {
       await candidateApi.remove(cand.id);
       toast.success('候选人已删除');
       await refreshList();
     } catch (err) {
       logger.error(`删除候选人失败: ${(err as Error).message}`);
       toast.error((err as Error).message || '删除失败');
     }
   };

  const isRoundLocked = (r: number): boolean => {
    if (!detail || r <= 1) return false;
    const prev = [detail.r1Status, detail.r2Status, detail.r3Status, detail.r4Status][r - 2];
    return !isPassed(prev);
  };

  const roundStatusIcon = (done: boolean, active: boolean) => {
    if (done) return <CheckCircle2 size={16} style={{ color: '#2D8B55' }} />;
    if (active) return <Clock size={16} style={{ color: '#8c1f28' }} />;
    return <Circle size={16} style={{ color: '#9ca3af' }} />;
  };

  const columns: ColumnsType<Candidate> = useMemo(() => [
    {
      title: '#',
      key: 'index',
      width: 50,
      render: (_: unknown, __, index) => (
        <span className="text-muted-foreground font-mono text-xs">{index + 1}</span>
      ),
    },
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      width: 100,
      render: (text: string) => <strong>{text}</strong>,
    },
    {
      title: '竞选岗位',
      dataIndex: 'position',
      key: 'position',
      width: 120,
    },
    {
      title: '参选形式',
      dataIndex: 'candidateType',
      key: 'candidateType',
      width: 100,
      render: (t: string) => t || '—',
    },
    {
      title: '来源（血缘）',
      dataIndex: 'source',
      key: 'source',
      width: 140,
      ellipsis: true,
      render: (t: string) => (
        <Tag color={t ? 'blue' : 'default'}>{t || '自荐'}</Tag>
      ),
    },
    {
      title: '当前阶段',
      key: 'currentStage',
      width: 120,
      render: (_: unknown, record: Candidate) => {
        const statuses = [record.r1Status, record.r2Status, record.r3Status, record.r4Status];
        let currentIdx = 0;
        for (let i = 0; i < 4; i += 1) {
          if (statuses[i] && statuses[i] !== '待审核') currentIdx = i;
        }
        return (
          <span style={{ fontSize: 12, color: '#1F2937' }}>
            第 {currentIdx + 1} 轮 · {ROUND_NAMES[currentIdx]}
          </span>
        );
      },
    },
    ...[0, 1, 2, 3].map((idx) => ({
      title: `第${idx + 1}轮`,
      key: `r${idx + 1}`,
      width: 90,
      render: (_: unknown, record: Candidate) => {
        const statuses = [record.r1Status, record.r2Status, record.r3Status, record.r4Status];
        const s = statuses[idx];
        const locked = idx > 0 && !isPassed(statuses[idx - 1]) && (s === '' || s === '待审核');
        if (locked) {
          return (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: '#9ca3af', fontSize: 12 }}>
              <Lock size={12} />锁定
            </span>
          );
        }
        return <Tag color={getStatusTagColor(s)}>{getStatusLabel(s)}</Tag>;
      },
    })),
    {
      title: '汇总状态',
      key: 'status',
      width: 100,
      render: (_: unknown, record: Candidate) => (
        <Tag color={getOverallTagColor(record.status)}>{getOverallLabel(record.status)}</Tag>
      ),
    },
     {
       title: '阶段操作',
       key: 'action',
       width: 180,
       align: 'right' as const,
       fixed: 'right' as const,
       render: (_: unknown, record: Candidate) => (
         <Space size={2}>
           <Button
             type="text"
             size="small"
             icon={<UserCheck size={14} />}
             onClick={() => openReview(record)}
           >
             审核
           </Button>
           <Button
             type="text"
             size="small"
             icon={<Edit2 size={14} />}
             onClick={() => openEdit(record)}
           >
             编辑
           </Button>
           <Button
             type="text"
             size="small"
             danger
             icon={<Trash2 size={14} />}
             onClick={() => handleDelete(record)}
           >
             删除
           </Button>
         </Space>
       ),
     },
   ], [openReview, openEdit, handleDelete]);

  if (ctxLoading || !currentOrg) {
    return <div style={{ padding: 16 }}>加载中...</div>;
  }

  return (
    <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
      <PageBreadcrumb
        items={[
          { label: '选举活动管理', href: '/elections' },
          { label: currentElection?.term || '第X届' },
          { label: '业务模块-候选人管理' },
        ]}
      />
      {/* 当前届次上下文栏 */}
      <Card size="small" style={{ background: 'linear-gradient(135deg, #fff9f0 0%, #fff 100%)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>当前届次</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#1F2937' }}>
              {currentElection?.name || '—'}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>候选人数</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#8c1f28' }}>
              {candidates.length} 人
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>已通过</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#166534' }}>
              {candidates.filter((c) => c.status === '已通过').length} 人
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: '#6B7280' }}>审核中</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#8c1f28' }}>
              {candidates.filter((c) => c.status === '审核中').length} 人
            </div>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <Button type="primary" size="small">批量导入</Button>
          </div>
        </div>
      </Card>
      {/* 阶段标签导航 */}
      <Card size="small" style={{ margin: 0 }}>
        <Tabs
          activeKey={position}
          onChange={setPosition}
          items={POSITION_TABS.map((tab) => ({
            key: tab,
            label: tab,
          }))}
          size="small"
        />
      </Card>
      <div>
        <h1 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>候选人管理</h1>
        <p style={{ fontSize: 13, color: '#6B7280', margin: '4px 0 0 0' }}>
          四轮审核全流程管理，共 {candidates.length} 位候选人
        </p>
      </div>

      {/* 岗位 Tab */}
      <Card size="small" styles={{ body: { padding: 0 } }}>
        <Tabs
          activeKey={position}
          onChange={setPosition}
          items={POSITION_TABS.map((tab) => ({
            key: tab,
            label: (
              <span>
                {tab}
                <span style={{ marginLeft: 6, fontSize: 12, fontFamily: 'monospace' }}>
                  ({candidates.length})
                </span>
              </span>
            ),
          }))}
        />
      </Card>

      {/* 四轮审核卡片行 */}
      <Row gutter={[12, 12]}>
        {roundStats.map((r) => {
          const done = r.pendingCount === 0 && r.passCount > 0;
          const active = r.passCount > 0 || r.rejectCount > 0;
          return (
            <Col xs={12} md={6} key={r.round}>
              <Card size="small">
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 500 }}>
                    第{r.round}轮 · {r.name}
                  </span>
                  {roundStatusIcon(done, active)}
                </div>
                <Statistic value={r.pendingCount} valueStyle={{ fontSize: 26, fontWeight: 700 }} />
                <Space size={12} style={{ fontSize: 12, marginTop: 4 }}>
                  <span style={{ color: '#2D8B55' }}>通过 {r.passCount}</span>
                  <span style={{ color: '#8c1f28' }}>驳回 {r.rejectCount}</span>
                </Space>
                <div style={{ marginTop: 8 }}>
                  <Tag color={done ? 'success' : active ? 'processing' : 'default'}>
                    {done ? '已完成' : active ? '办理中' : '未开始'}
                  </Tag>
                </div>
              </Card>
            </Col>
          );
        })}
      </Row>

       {/* 候选人列表 */}
       <Card
         size="small"
         title={`${position}候选人列表`}
         extra={
           <Button
             type="primary"
             size="small"
             icon={<Plus size={14} />}
             onClick={openCreate}
           >
             添加候选人
           </Button>
         }
       >
        <Table<Candidate>
          columns={columns}
          dataSource={candidates}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 20, showSizeChanger: false }}
          scroll={{ x: 1000 }}
          size="small"
        />
      </Card>

       {/* 新增/编辑弹窗 */}
       <Modal
         open={formOpen}
         onCancel={() => setFormOpen(false)}
         title={formMode === 'create' ? '添加候选人' : '编辑候选人'}
         width={480}
         confirmLoading={formLoading}
         onOk={handleFormSubmit}
         okText="保存"
       >
         <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
           <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
             <label style={{ fontSize: 13, fontWeight: 500 }}>姓名 <span style={{ color: '#ff4d4f' }}>*</span></label>
             <Input
               value={formData.name || ''}
               onChange={(e) => setFormData({ ...formData, name: e.target.value })}
               placeholder="请输入候选人姓名"
             />
           </div>
           <div style={{ display: 'flex', gap: 12 }}>
             <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
               <label style={{ fontSize: 13, fontWeight: 500 }}>性别</label>
               <Select
                 value={formData.gender || undefined}
                 onChange={(v) => setFormData({ ...formData, gender: v })}
                 options={[
                   { value: '男', label: '男' },
                   { value: '女', label: '女' },
                 ]}
               />
             </div>
             <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
               <label style={{ fontSize: 13, fontWeight: 500 }}>年龄</label>
               <Input
                 type="number"
                 value={formData.age || ''}
                 onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) || 0 })}
                 placeholder="年龄"
               />
             </div>
           </div>
           <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
             <label style={{ fontSize: 13, fontWeight: 500 }}>岗位</label>
             <Select
               value={formData.position || undefined}
               onChange={(v) => setFormData({ ...formData, position: v })}
               options={[
                 { value: '主任', label: '主任' },
                 { value: '副主任', label: '副主任' },
                 { value: '委员', label: '委员' },
               ]}
             />
           </div>
           <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
             <label style={{ fontSize: 13, fontWeight: 500 }}>来源</label>
             <Select
               value={formData.source || undefined}
               onChange={(v) => setFormData({ ...formData, source: v })}
               options={[
                 { value: '选民联名', label: '选民联名' },
                 { value: '组织推荐', label: '组织推荐' },
                 { value: '自我推荐', label: '自我推荐' },
                 { value: '材料审核通过', label: '材料审核通过' },
               ]}
             />
           </div>
         </div>
       </Modal>

       {/* 审核弹窗 */}
       <Modal
        open={dialogOpen}
        onCancel={() => setDialogOpen(false)}
        title="候选人审核"
        width={640}
        footer={[
          <Button key="cancel" onClick={() => setDialogOpen(false)}>取消</Button>,
          <Button
            key="submit"
            type="primary"
            onClick={handleSubmit}
            disabled={!result || submitting || isRoundLocked(round)}
            loading={submitting}
          >
            确认提交
          </Button>,
        ]}
      >
        {detail && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* 基本信息 */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <span style={{ fontSize: 16, fontWeight: 600 }}>{detail.name}</span>
                <Tag color={getOverallTagColor(detail.status)}>
                  {getOverallLabel(detail.status)}
                </Tag>
              </div>
              <Descriptions column={2} size="small" bordered>
                <Descriptions.Item label="性别">{detail.gender}</Descriptions.Item>
                <Descriptions.Item label="年龄">{detail.age}</Descriptions.Item>
                <Descriptions.Item label="身份证">
                  <span style={{ fontFamily: 'monospace' }}>{detail.idCard || '-'}</span>
                </Descriptions.Item>
                <Descriptions.Item label="电话">
                  <span style={{ fontFamily: 'monospace' }}>{detail.phone || '-'}</span>
                </Descriptions.Item>
                <Descriptions.Item label="岗位">{detail.position}</Descriptions.Item>
                <Descriptions.Item label="来源">{detail.source}</Descriptions.Item>
              </Descriptions>
            </div>

            {/* 前序轮次记录 */}
            {round > 1 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ fontSize: 14, fontWeight: 500 }}>前序轮次记录</div>
                {Array.from({ length: round - 1 }).map((_, i) => {
                  const rIdx = i + 1;
                  const s = [detail.r1Status, detail.r2Status, detail.r3Status, detail.r4Status][i];
                  const reviewer = [detail.r1Reviewer, detail.r2Reviewer, detail.r3Reviewer, detail.r4Reviewer][i];
                  const time = [detail.r1Time, detail.r2Time, detail.r3Time, detail.r4Time][i];
                  const cmt = [detail.r1Comment, detail.r2Comment, detail.r3Comment, detail.r4Comment][i];
                  return (
                    <Card key={rIdx} size="small">
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                        <span style={{ fontSize: 13, fontWeight: 500 }}>
                          第{rIdx}轮 · {ROUND_NAMES[rIdx - 1]}
                        </span>
                        <Tag color={getStatusTagColor(s)}>{getStatusLabel(s)}</Tag>
                      </div>
                      <div style={{ fontSize: 12, color: '#6B7280' }}>
                        审核人：{reviewer || '-'}<span style={{ margin: '0 8px' }}>|</span>时间：{time || '-'}
                      </div>
                      {cmt && (
                        <div style={{ fontSize: 12, color: '#6B7280', marginTop: 4 }}>
                          意见：{cmt}
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            )}

            {/* 当前轮审核 */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 500 }}>
                第{round}轮 · {ROUND_NAMES[round - 1]} 审核结论
              </div>
              <Select
                value={result || undefined}
                onChange={setResult}
                placeholder="请选择审核结果"
                options={[
                  { value: '通过', label: '通过' },
                  { value: '不通过', label: '不通过 / 驳回' },
                ]}
              />
              <Input.TextArea
                placeholder="请输入审核意见（选填）"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
              />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default CandidatePage;
