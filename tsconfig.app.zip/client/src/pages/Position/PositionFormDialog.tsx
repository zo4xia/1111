import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Button } from '@client/src/components/ui/button';
import type { Position } from '@shared/api.interface';

const TYPE_OPTIONS = ['主任', '副主任', '委员'];

interface PositionFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  position?: Position | null;
  loading?: boolean;
  onSubmit: (data: { type: string; quota: number; description: string }) => void;
}

export function PositionFormDialog({
  open,
  onOpenChange,
  mode,
  position,
  loading = false,
  onSubmit,
}: PositionFormDialogProps) {
  const [type, setType] = useState('');
  const [quota, setQuota] = useState<number>(1);
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (open) {
      if (mode === 'edit' && position) {
        setType(position.type);
        setQuota(position.quota);
        setDescription(position.description);
      } else {
        setType('');
        setQuota(1);
        setDescription('');
      }
    }
  }, [open, mode, position]);

  const handleSubmit = () => {
    if (!type.trim()) return;
    onSubmit({ type: type.trim(), quota, description });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? '新增岗位' : '编辑岗位'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              岗位类型
            </label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue placeholder="请选择岗位类型" />
              </SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              应选配额
            </label>
            <Input
              type="number"
              min={1}
              value={quota}
              onChange={(e) => setQuota(Number(e.target.value) || 0)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              岗位描述
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="请输入岗位描述"
              className="min-h-[80px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={loading || !type.trim()} onClick={handleSubmit}>
            {loading ? '保存中...' : mode === 'create' ? '创建' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default PositionFormDialog;
