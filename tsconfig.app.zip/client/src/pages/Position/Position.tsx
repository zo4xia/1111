import { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';
import { toast } from 'sonner';
import {
  Plus,
  Edit2,
  Trash2,
  Users,
  UserCheck,
  Power,
  PowerOff,
} from 'lucide-react';
import {
  Table,
  Button,
  Tag,
  Card,
  Select,
  Statistic,
  Space,
  Alert,
  Segmented,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { positionApi } from '@client/src/api/position';
import { resultApi } from '@client/src/api/result';
import type { Position, PositionStats, RosterItem } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import { PositionFormDialog } from './PositionFormDialog';

const STATUS_FILTERS = [
  { key: '', label: '全部' },
  { key: 'active', label: '启用中' },
  { key: 'inactive', label: '已停用' },
];

function StatusBadge({ status }: { status: string }) {
  const isActive = status === 'active';
  return (
    <Tag color={isActive ? 'success' : 'default'}>
      {isActive ? '启用中' : '已停用'}
    </Tag>
  );
}

const PositionPage = () => {
  const { currentOrg, currentElection } = useElection();
  const [positions, setPositions] = useState<Position[]>([]);
  const [stats, setStats] = useState<PositionStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('');

  const [createOpen, setCreateOpen] = useState<boolean>(false);
  const [createLoading, setCreateLoading] = useState<boolean>(false);

  const [editOpen, setEditOpen] = useState<boolean>(false);
  const [editingPos, setEditingPos] = useState<Position | null>(null);
  const [editLoading, setEditLoading] = useState<boolean>(false);

  const [yearFilter, setYearFilter] = useState<string>('');
  const [rosterList, setRosterList] = useState<RosterItem[]>([]);
  const [rosterLoading, setRosterLoading] = useState<boolean>(false);

  const loadData = useCallback(async () => {
    if (!currentOrg) return;
    setLoading(true);
    setError(null);
    try {
      const listParams = {
        orgId: currentOrg.id,
        electionId: currentElection?.id,
        status: statusFilter || undefined,
      };
      const [listData, statsData] = await Promise.all([
        positionApi.list(listParams),
        positionApi.stats({
          orgId: currentOrg.id,
          electionId: currentElection?.id,
        }),
      ]);
      setPositions(listData.items);
      setStats(statsData);
    } catch (err) {
      logger.error(`加载岗位数据失败: ${(err as Error).message}`);
      setError((err as Error).message || '加载失败');
    } finally {
      setLoading(false);
    }
  }, [currentOrg, currentElection, statusFilter]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const loadRoster = async () => {
    if (!currentOrg) return;
    setRosterLoading(true);
    try {
      const result = await resultApi.listRoster({ orgId: currentOrg.id });
      setRosterList(result.items || []);
    } catch (err) {
      logger.error(`加载花名册失败: ${(err as Error).message}`);
    } finally {
      setRosterLoading(false);
    }
  };

  useEffect(() => {
    loadRoster();
  }, [currentOrg]);

  const handleCreateSubmit = async (data: {
    type: string;
    quota: number;
    description: string;
  }) => {
    setCreateLoading(true);
    try {
      await positionApi.create({
        ...data,
        orgId: currentOrg?.id,
        electionId: currentElection?.id,
      });
      setCreateOpen(false);
      toast.success('岗位创建成功');
      await loadData();
    } catch (err) {
      logger.error(`创建岗位失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '创建失败');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleEditSubmit = async (data: {
    type: string;
    quota: number;
    description: string;
  }) => {
    if (!editingPos) return;
    setEditLoading(true);
    try {
      await positionApi.update(editingPos.id, data);
      setEditOpen(false);
      toast.success('岗位更新成功');
      await loadData();
    } catch (err) {
      logger.error(`更新岗位失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '更新失败');
    } finally {
      setEditLoading(false);
    }
  };

  const handleDelete = async (pos: Position) => {
    if (
      !(await showConfirm(`确定要删除岗位"${pos.type}"吗？此操作不可撤销。`))
    )
      return;
    try {
      await positionApi.remove(pos.id);
      toast.success('岗位删除成功');
      await loadData();
    } catch (err) {
      logger.error(`删除岗位失败: ${(err as Error).message}`);
      toast.error((err as Error).message || '删除失败');
    }
  };

  const handleToggleStatus = async (pos: Position) => {
    const nextStatus = pos.status === 'active' ? 'inactive' : 'active';
    const action = nextStatus === 'active' ? '启用' : '停用';
    try {
      await positionApi.update(pos.id, { status: nextStatus });
      toast.success(`岗位${action}成功`);
      await loadData();
    } catch (err) {
      logger.error(`岗位${action}失败: ${(err as Error).message}`);
      toast.error((err as Error).message || `${action}失败`);
    }
  };

  const columns: ColumnsType<Position> = [
    {
      title: '岗位类型',
      dataIndex: 'type',
      key: 'type',
      width: 160,
      render: (text: string) => <span className="font-medium">{text}</span>,
    },
    {
      title: '应选配额',
      dataIndex: 'quota',
      key: 'quota',
      width: 100,
      render: (val: number) => `${val} 名`,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: string) => <StatusBadge status={status} />,
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true,
      render: (text: string) => text || '-',
    },
    {
      title: '操作',
      key: 'action',
      width: 260,
      align: 'right',
      render: (_: unknown, record: Position) => (
        <Space size="small">
          <Button
            type="link"
            size="small"
            icon={<Edit2 size={14} />}
            onClick={() => {
              setEditingPos(record);
              setEditOpen(true);
            }}
          >
            编辑
          </Button>
          <Button
            type="link"
            size="small"
            danger={record.status === 'active'}
            icon={
              record.status === 'active' ? (
                <PowerOff size={14} />
              ) : (
                <Power size={14} />
              )
            }
            onClick={() => handleToggleStatus(record)}
          >
            {record.status === 'active' ? '停用' : '启用'}
          </Button>
          <Button
            type="link"
            size="small"
            danger
            icon={<Trash2 size={14} />}
            onClick={() => handleDelete(record)}
          >
            删除
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '岗位管理' }]} />
      {/* 顶部标题区 */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">岗位管理</h1>
          <p className="text-sm text-muted-foreground mt-1">
            选举岗位配置与应选名额管理
          </p>
        </div>
        <Button type="primary" icon={<Plus size={16} />} onClick={() => setCreateOpen(true)}>
          新增岗位
        </Button>
      </div>

      {error && (
        <Alert
          type="error"
          message={error}
          closable
          onClose={() => setError(null)}
          showIcon
        />
      )}

      {/* 统计卡片 */}
      <div
        data-ai-section-type="card-stat"
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3"
      >
        <Card size="small">
          <Statistic
            title={
              <span className="flex items-center gap-2">
                <Users size={16} style={{ color: '#8c1f28' }} />
                岗位总数
              </span>
            }
            value={stats?.total ?? 0}
            valueStyle={{ color: '#8c1f28' }}
          />
        </Card>
        <Card size="small">
          <Statistic
            title={
              <span className="flex items-center gap-2">
                <UserCheck size={16} style={{ color: '#8c1f28' }} />
                总配额
              </span>
            }
            value={stats?.totalQuota ?? 0}
            valueStyle={{ color: '#8c1f28' }}
          />
        </Card>
        <Card size="small">
          <Statistic
            title={
              <span className="flex items-center gap-2">
                <Users size={16} style={{ color: '#2D8B55' }} />
                主任岗
              </span>
            }
            value={stats?.directorCount ?? 0}
            valueStyle={{ color: '#2D8B55' }}
          />
        </Card>
        <Card size="small">
          <Statistic
            title={
              <span className="flex items-center gap-2">
                <Users size={16} style={{ color: '#c9a063' }} />
                副主任岗
              </span>
            }
            value={stats?.viceDirectorCount ?? 0}
            valueStyle={{ color: '#c9a063' }}
          />
        </Card>
        <Card size="small">
          <Statistic
            title={
              <span className="flex items-center gap-2">
                <Users size={16} style={{ color: '#6B7280' }} />
                委员岗
              </span>
            }
            value={stats?.memberCount ?? 0}
            valueStyle={{ color: '#6B7280' }}
          />
        </Card>
      </div>

      {/* 筛选条 */}
      <div className="bg-card border border-border rounded-sm p-3 flex items-center gap-3 flex-wrap">
        <span className="text-sm text-muted-foreground">届次/年份：</span>
        <Select
          value={yearFilter || 'all'}
          onChange={(val) => setYearFilter(val === 'all' ? '' : val)}
          style={{ width: 140 }}
          size="small"
          options={[
            { value: 'all', label: '全部' },
            { value: '2026', label: '2026年' },
            { value: '2021', label: '2021年' },
          ]}
        />
        <span className="text-sm text-muted-foreground ml-2">状态：</span>
        <Segmented
          value={statusFilter || 'all'}
          onChange={(val) => setStatusFilter(val === 'all' ? '' : String(val))}
          options={STATUS_FILTERS.map((f) => ({
            value: f.key || 'all',
            label: f.label,
          }))}
        />
        <div className="flex-1" />
        <Button size="small" icon={<UserCheck size={14} />}>
          编辑花名册
        </Button>
      </div>

      {/* 在任干部花名册 */}
      <Card
        size="small"
        title="当前在任干部"
        extra={<Button type="link" size="small">历史名录 →</Button>}
      >
        <Table<RosterItem>
          rowKey="id"
          size="small"
          loading={rosterLoading}
          dataSource={rosterList}
          pagination={false}
          columns={[
            { title: '岗位', dataIndex: 'position', key: 'position', width: 120 },
            { title: '姓名', dataIndex: 'name', key: 'name', width: 120 },
            { title: '联系方式', dataIndex: 'phone', key: 'phone' },
            { title: '届次', dataIndex: 'term', key: 'term', width: 120 },
            { title: '任期', dataIndex: 'termRange', key: 'termRange', width: 180 },
            {
              title: '操作',
              key: 'action',
              width: 120,
              align: 'right',
              render: () => (
                <Space size={4}>
                  <Button type="link" size="small">编辑</Button>
                  <Button type="link" size="small" danger>移除</Button>
                </Space>
              ),
            },
          ]}
          locale={{ emptyText: '暂无花名册数据' }}
        />
      </Card>

      {/* 岗位定义表 */}
      <Card size="small" className="!p-0" title="岗位定义">
        <Table<Position>
          rowKey="id"
          columns={columns}
          dataSource={positions}
          loading={loading}
          pagination={false}
          size="small"
          locale={{ emptyText: '暂无岗位数据' }}
          scroll={{ x: 800 }}
        />
      </Card>

      <PositionFormDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        mode="create"
        loading={createLoading}
        onSubmit={handleCreateSubmit}
      />

      <PositionFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        mode="edit"
        position={editingPos}
        loading={editLoading}
        onSubmit={handleEditSubmit}
      />
    </div>
  );
};

export default PositionPage;
