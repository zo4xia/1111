import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { resultApi } from '@client/src/api/result';
import type {
  RosterItem,
  RosterCreateDto,
  RosterUpdateDto,
} from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@client/src/components/ui/select';
import { Textarea } from '@client/src/components/ui/textarea';
import { toast } from 'sonner';

interface RosterEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  item: RosterItem | null;
  orgId: string;
  onSaved: () => void;
}

const POSITIONS = ['主任', '副主任', '委员'];
const STATUSES = ['confirmed', 'historical'];

export function RosterEditDialog({
  open,
  onOpenChange,
  mode,
  item,
  orgId,
  onSaved,
}: RosterEditDialogProps) {
  const [form, setForm] = useState<Partial<RosterCreateDto>>({
    position: '委员',
    name: '',
    phone: '',
    term: '',
    yearStart: '',
    yearEnd: '',
    status: 'confirmed',
    isActive: true,
    sessionNo: '',
    note: '',
  });
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!open) return;
    if (mode === 'edit' && item) {
      setForm({
        position: item.position,
        name: item.name,
        phone: item.phone,
        term: item.term,
        yearStart: item.yearStart,
        yearEnd: item.yearEnd,
        status: item.status || 'confirmed',
        isActive: item.isActive,
        sessionNo: item.sessionNo,
        note: item.note,
      });
    } else {
      setForm({
        position: '委员',
        name: '',
        phone: '',
        term: '',
        yearStart: '',
        yearEnd: '',
        status: 'confirmed',
        isActive: true,
        sessionNo: '',
        note: '',
      });
    }
  }, [open, mode, item]);

  const updateField = (field: keyof RosterCreateDto, value: unknown) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!form.name) {
      toast('请输入姓名');
      return;
    }
    if (!form.position) {
      toast('请选择岗位');
      return;
    }
    setSubmitting(true);
    try {
      if (mode === 'create') {
        const payload: RosterCreateDto = {
          orgId,
          position: form.position || '委员',
          name: form.name || '',
          phone: form.phone || '',
          term: form.term || '',
          yearStart: form.yearStart || '',
          yearEnd: form.yearEnd || '',
          status: form.status || 'confirmed',
          isActive: form.isActive ?? true,
          sessionNo: form.sessionNo || '',
          note: form.note || '',
        };
        await resultApi.createRoster(payload);
      } else if (mode === 'edit' && item) {
        const payload: RosterUpdateDto = {
          position: form.position,
          name: form.name,
          phone: form.phone,
          term: form.term,
          yearStart: form.yearStart,
          yearEnd: form.yearEnd,
          status: form.status,
          isActive: form.isActive,
          sessionNo: form.sessionNo,
          note: form.note,
        };
        await resultApi.updateRoster(item.id, payload);
      }
      onOpenChange(false);
      onSaved();
    } catch (err) {
      logger.error(`保存花名册失败: ${(err as Error).message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? '新增花名册' : '编辑花名册'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-[65vh] overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-sm">岗位</Label>
              <Select
                value={form.position || '委员'}
                onValueChange={(v) => updateField('position', v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  {POSITIONS.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm">姓名</Label>
              <Input
                value={form.name || ''}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="请输入姓名"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm">联系电话</Label>
            <Input
              value={form.phone || ''}
              onChange={(e) => updateField('phone', e.target.value)}
              placeholder="请输入联系电话"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label className="text-sm">届次（数字）</Label>
              <Input
                value={form.sessionNo || ''}
                onChange={(e) => updateField('sessionNo', e.target.value)}
                placeholder="如 11"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm">起始年</Label>
              <Input
                value={form.yearStart || ''}
                onChange={(e) => updateField('yearStart', e.target.value)}
                placeholder="如 2026"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm">结束年</Label>
              <Input
                value={form.yearEnd || ''}
                onChange={(e) => updateField('yearEnd', e.target.value)}
                placeholder="如 2031"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm">任期</Label>
            <Input
              value={form.term || ''}
              onChange={(e) => updateField('term', e.target.value)}
              placeholder="如 2026-2031（可留空，自动由起止年生成）"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-sm">状态</Label>
              <Select
                value={form.status || 'confirmed'}
                onValueChange={(v) => updateField('status', v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="confirmed">在任</SelectItem>
                  <SelectItem value="historical">历史</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm">是否现任</Label>
              <Select
                value={form.isActive ? 'active' : 'inactive'}
                onValueChange={(v) => updateField('isActive', v === 'active')}
              >
                <SelectTrigger>
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">是（现任）</SelectItem>
                  <SelectItem value="inactive">否</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm">备注</Label>
            <Textarea
              value={form.note || ''}
              onChange={(e) => updateField('note', e.target.value)}
              placeholder="补充说明"
              className="min-h-[60px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {mode === 'create' ? '新增' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
