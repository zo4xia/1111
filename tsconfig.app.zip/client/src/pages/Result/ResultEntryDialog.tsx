import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { resultApi } from '@client/src/api/result';
import { candidateApi } from '@client/src/api/candidate';
import type { Candidate, ElectionResultCreateDto, ElectionResult } from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';

interface ResultEntryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  position: string;
  orgSlug: string;
  electionId: string;
  onSubmitted: () => void;
}

export function ResultEntryDialog({
  open,
  onOpenChange,
  position,
  orgSlug,
  electionId,
  onSubmitted,
}: ResultEntryDialogProps) {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [voteInputs, setVoteInputs] = useState<Record<string, string>>({});
  const [validVotes, setValidVotes] = useState<string>('');
  const [invalidVotes, setInvalidVotes] = useState<string>('');
  const [actualVoters, setActualVoters] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (!open) return;
    let mounted = true;
    (async () => {
      setLoading(true);
      try {
        const data = await candidateApi.list({
          orgId: orgSlug,
          electionId,
          position,
          pageSize: 200,
        });
        if (!mounted) return;
        const passed = data.items.filter((c) => c.status === '已通过');
        setCandidates(passed);
        const initial: Record<string, string> = {};
        for (const c of passed) {
          initial[c.id] = String(c.votes || '');
        }
        setVoteInputs(initial);
        setValidVotes('');
        setInvalidVotes('');
        setActualVoters('');
      } catch (err) {
        logger.error(`加载候选人列表失败: ${(err as Error).message}`);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [open, position, orgSlug, electionId]);

  const handleVoteChange = (candidateId: string, value: string) => {
    setVoteInputs((prev) => ({ ...prev, [candidateId]: value }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const candidateVotes = candidates
        .map((c) => ({
          candidateId: c.id,
          votes: Number(voteInputs[c.id] || '0'),
        }))
        .filter((cv) => cv.votes >= 0);

      const totalValid = candidateVotes.reduce(
        (sum, cv) => sum + cv.votes,
        0,
      );

      const payload: ElectionResultCreateDto = {
        electionId,
        orgId: orgSlug,
        position,
        candidateVotes,
        validVotes: validVotes ? Number(validVotes) : totalValid,
        invalidVotes: invalidVotes ? Number(invalidVotes) : 0,
        actualVoters: actualVoters ? Number(actualVoters) : totalValid,
      };

      const resp = await resultApi.createResult(payload);
      // 同步录入备案状态初始值
      if (resp.id) {
        try {
          await resultApi.updateFiling(resp.id, { filingStatus: '未备案' });
          await resultApi.updateHandover(resp.id, { handoverStatus: '未交接' });
        } catch {
          // ignore initial status sync error
        }
      }
      onOpenChange(false);
      onSubmitted();
    } catch (err) {
      logger.error(`录入结果失败: ${(err as Error).message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>录入{position}选举结果</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
          {loading ? (
            <div className="text-sm text-muted-foreground py-4 text-center">
              加载中...
            </div>
          ) : candidates.length === 0 ? (
            <div className="text-sm text-muted-foreground py-4 text-center">
              暂无已通过审核的候选人
            </div>
          ) : (
            candidates.map((c) => (
              <div key={c.id} className="flex items-center gap-3">
                <Label className="w-20 text-sm text-foreground">{c.name}</Label>
                <Input
                  type="number"
                  min="0"
                  value={voteInputs[c.id] || ''}
                  onChange={(e) => handleVoteChange(c.id, e.target.value)}
                  placeholder="得票数"
                  className="flex-1"
                />
                <span className="text-xs text-muted-foreground w-8">票</span>
              </div>
            ))
          )}
          <div className="border-t border-border pt-3 space-y-2">
            <div className="flex items-center gap-3">
              <Label className="w-20 text-sm text-muted-foreground">
                有效票数
              </Label>
              <Input
                type="number"
                min="0"
                value={validVotes}
                onChange={(e) => setValidVotes(e.target.value)}
                placeholder="自动计算各候选人得票总和"
                className="flex-1"
              />
            </div>
            <div className="flex items-center gap-3">
              <Label className="w-20 text-sm text-muted-foreground">
                无效票数
              </Label>
              <Input
                type="number"
                min="0"
                value={invalidVotes}
                onChange={(e) => setInvalidVotes(e.target.value)}
                placeholder="0"
                className="flex-1"
              />
            </div>
            <div className="flex items-center gap-3">
              <Label className="w-20 text-sm text-muted-foreground">
                实投人数
              </Label>
              <Input
                type="number"
                min="0"
                value={actualVoters}
                onChange={(e) => setActualVoters(e.target.value)}
                placeholder="实际投票人数"
                className="flex-1"
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={submitting || loading}>
            提交结果
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
