import { useState, useEffect, useMemo } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { showConfirm } from '@lark-apaas/client-toolkit';
import {
  Trophy, Medal, Plus, Pencil, Trash2, Search,
  FileCheck, Handshake, Users,
} from 'lucide-react';
import {
  Table, Button, Input, Select, Tabs, Card, Statistic,
  Tag, Modal, Space, Row, Col, Alert, Skeleton,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useElection } from '@client/src/contexts/ElectionContext';
import { resultApi } from '@client/src/api/result';
import type { ElectionResult, RosterItem, RosterStats } from '@shared/api.interface';
import PageBreadcrumb from '@client/src/components/PageBreadcrumb';
import { ResultEntryDialog } from './ResultEntryDialog';
import { RosterEditDialog } from './RosterEditDialog';

const FILING_COLORS: Record<string, string> = { 未备案: 'default', 备案中: 'processing', 已备案: 'success', 备案失败: 'error' };
const HANDOVER_COLORS: Record<string, string> = { 未交接: 'default', 交接中: 'warning', 已完成: 'success' };
const FILING_OPTIONS = ['未备案', '备案中', '已备案', '备案失败'];
const HANDOVER_OPTIONS = ['未交接', '交接中', '已完成'];

function StatusTag({ status, colors }: { status: string; colors: Record<string, string> }) {
  return <Tag color={colors[status] || 'default'}>{status || '未知'}</Tag>;
}

function StatusUpdateModal({
  open, onOpenChange, title, currentStatus, options, onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  currentStatus: string;
  options: string[];
  onSubmit: (status: string) => Promise<void>;
}) {
  const [selected, setSelected] = useState(currentStatus);
  const [submitting, setSubmitting] = useState(false);
  useEffect(() => { if (open) setSelected(currentStatus); }, [currentStatus, open]);
  const handleOk = async () => {
    if (!selected) return;
    setSubmitting(true);
    try { await onSubmit(selected); onOpenChange(false); }
    catch (err) { logger.error(`更新状态失败: ${(err as Error).message}`); }
    finally { setSubmitting(false); }
  };
  return (
    <Modal open={open} title={title} onCancel={() => onOpenChange(false)}
      onOk={handleOk} confirmLoading={submitting} okText="确认" cancelText="取消"
      okButtonProps={{ disabled: !selected }} width={480}>
      <div className="py-3">
        <div className="text-sm mb-2">选择状态</div>
        <Select value={selected} onChange={setSelected} style={{ width: '100%' }}
          options={options.map((opt) => ({ value: opt, label: opt }))} placeholder="请选择状态" />
      </div>
    </Modal>
  );
}

const ResultPage = () => {
  const { currentOrg, currentElection, loading: ctxLoading } = useElection();
  const [activeTab, setActiveTab] = useState('result');

  // 选举结果 state
  const [results, setResults] = useState<ElectionResult[]>([]);
  const [resultLoading, setResultLoading] = useState(false);
  const [resultError, setResultError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activePosition, setActivePosition] = useState('主任');
  const [filingDialog, setFilingDialog] = useState({ open: false, result: null as ElectionResult | null });
  const [handoverDialog, setHandoverDialog] = useState({ open: false, result: null as ElectionResult | null });

  // 花名册 state
  const [roster, setRoster] = useState<RosterItem[]>([]);
  const [rosterStats, setRosterStats] = useState<RosterStats | null>(null);
  const [rosterLoading, setRosterLoading] = useState(false);
  const [rosterError, setRosterError] = useState<string | null>(null);
  const [termFilter, setTermFilter] = useState('');
  const [searchText, setSearchText] = useState('');
  const [rosterDialog, setRosterDialog] = useState({ open: false, mode: 'create' as 'create' | 'edit', item: null as RosterItem | null });

  // ===== 选举结果加载 =====
  const loadResults = async () => {
    if (!currentOrg) return;
    setResultLoading(true); setResultError(null);
    try {
      const resp = await resultApi.listResults({ orgId: currentOrg.slug, electionId: currentElection?.id, pageSize: 100 });
      setResults(resp.items || []);
    } catch (err) {
      logger.error(`加载选举结果失败: ${(err as Error).message}`);
      setResultError((err as Error).message || '数据加载失败');
    } finally { setResultLoading(false); }
  };

  useEffect(() => {
    if (!currentOrg) return;
    if (activeTab === 'result') loadResults();
  }, [currentOrg, currentElection, activeTab]);

  // ===== 花名册加载 =====
  const loadRoster = async () => {
    if (!currentOrg) return;
    setRosterLoading(true); setRosterError(null);
    try {
      const [statsResp, listResp] = await Promise.all([
        resultApi.getRosterTerms(currentOrg.slug),
        resultApi.listRoster({ orgId: currentOrg.slug, term: termFilter || undefined, search: searchText || undefined, pageSize: 200 }),
      ]);
      setRosterStats(statsResp);
      setRoster(listResp.items || []);
    } catch (err) {
      logger.error(`加载花名册失败: ${(err as Error).message}`);
      setRosterError((err as Error).message || '数据加载失败');
    } finally { setRosterLoading(false); }
  };

  useEffect(() => {
    if (!currentOrg) return;
    if (activeTab === 'roster') loadRoster();
  }, [currentOrg, activeTab, termFilter, searchText]);

  const resultStats = useMemo(() => ({
    totalWinners: results.length,
    filedCount: results.filter((r) => r.filingStatus === '已备案').length,
    handedOverCount: results.filter((r) => r.handoverStatus === '已完成').length,
  }), [results]);

  const openEntryDialog = (position: string) => { setActivePosition(position); setDialogOpen(true); };

  const handleFilingUpdate = async (status: string) => {
    if (!filingDialog.result) return;
    await resultApi.updateFiling(filingDialog.result.id, { filingStatus: status });
    await loadResults();
  };

  const handleHandoverUpdate = async (status: string) => {
    if (!handoverDialog.result) return;
    await resultApi.updateHandover(handoverDialog.result.id, { handoverStatus: status });
    await loadResults();
  };

  const handleDeleteResult = async (id: string) => {
    if (!await showConfirm('确认删除该选举结果记录？')) return;
    try { await resultApi.deleteResult(id); await loadResults(); }
    catch (err) { logger.error(`删除选举结果失败: ${(err as Error).message}`); }
  };

  const handleRosterSaved = () => { loadRoster(); };

  const handleDeleteRoster = async (id: string) => {
    if (!await showConfirm('确认删除该花名册记录？')) return;
    try { await resultApi.deleteRoster(id); await loadRoster(); }
    catch (err) { logger.error(`删除花名册失败: ${(err as Error).message}`); }
  };

  const openCreateRoster = () => setRosterDialog({ open: true, mode: 'create', item: null });
  const openEditRoster = (item: RosterItem) => setRosterDialog({ open: true, mode: 'edit', item });

  if (ctxLoading || !currentOrg)
    return <div className="space-y-4 text-sm text-muted-foreground">加载中...</div>;

  // 选举结果表格列
  const resultColumns: ColumnsType<ElectionResult> = [
    { title: '岗位', dataIndex: 'position', width: 120, render: (t: string) => <span className="font-medium">{t}</span> },
    {
      title: '当选人', dataIndex: 'winnerName', width: 180,
      render: (t: string) => (
        <Space size={8}>{t || '待选举'}
          {t && <Tag color="gold" icon={<Medal size={10} />}>当选</Tag>}
        </Space>
      ),
    },
    { title: '得票数', dataIndex: 'votes', width: 100, align: 'right', render: (v: number) => v?.toLocaleString() || '-' },
    { title: '参选率', dataIndex: 'turnout', width: 100, align: 'right', render: (v: string) => v || '-' },
    { title: '备案状态', dataIndex: 'filingStatus', width: 100, align: 'center', render: (s: string) => <StatusTag status={s || '未备案'} colors={FILING_COLORS} /> },
    { title: '交接状态', dataIndex: 'handoverStatus', width: 100, align: 'center', render: (s: string) => <StatusTag status={s || '未交接'} colors={HANDOVER_COLORS} /> },
    {
      title: '操作', key: 'action', width: 240, align: 'right', fixed: 'right',
      render: (_, record) => (
        <Space size={4} wrap>
          <Button type="link" size="small" onClick={() => setFilingDialog({ open: true, result: record })}>备案</Button>
          <Button type="link" size="small" onClick={() => setHandoverDialog({ open: true, result: record })}>交接</Button>
          <Button type="link" size="small" icon={<Pencil size={12} />} onClick={() => openEntryDialog(record.position)}>编辑</Button>
          <Button type="link" size="small" danger icon={<Trash2 size={12} />} onClick={() => handleDeleteResult(record.id)}>删除</Button>
        </Space>
      ),
    },
  ];

  // 花名册表格列
  const rosterColumns: ColumnsType<RosterItem> = [
    {
      title: '姓名', dataIndex: 'name', width: 140,
      render: (t: string, r) => (
        <Space size={8}>
          <span className={`font-medium ${r.isActive ? '' : 'text-muted-foreground'}`}>{t}</span>
          {r.isActive && <Tag color="success">现任</Tag>}
        </Space>
      ),
    },
    { title: '岗位', dataIndex: 'position', width: 120 },
    { title: '届次', dataIndex: 'sessionNo', width: 100, render: (v: number) => `第${v}届` },
    { title: '任期', key: 'term', width: 160, render: (_, r) => r.term || (r.yearStart && r.yearEnd ? `${r.yearStart}-${r.yearEnd}` : '-') },
    { title: '电话', dataIndex: 'phone', width: 140, render: (t: string) => t || '-' },
    {
      title: '状态', key: 'status', width: 80, align: 'center',
      render: (_, r) => (
        <Tag color={r.isActive ? 'success' : 'default'}>
          {r.status === 'confirmed' ? '在任' : r.status === 'historical' ? '历史' : r.status || '-'}
        </Tag>
      ),
    },
    {
      title: '操作', key: 'action', width: 140, align: 'right', fixed: 'right',
      render: (_, record) => (
        <Space size={4}>
          <Button type="link" size="small" icon={<Pencil size={12} />} onClick={() => openEditRoster(record)}>编辑</Button>
          <Button type="link" size="small" danger icon={<Trash2 size={12} />} onClick={() => handleDeleteRoster(record.id)}>删除</Button>
        </Space>
      ),
    },
  ];

  const tabItems = [
    {
      key: 'result', label: '选举结果',
      children: (
        <div className="space-y-4 pt-4">
          <Row gutter={[12, 12]}>
            <Col xs={12} md={6}><Card size="small"><Statistic title={<span className="flex items-center gap-2"><Trophy size={14} style={{ color: '#c9a063' }} />当选人数</span>} value={resultStats.totalWinners} suffix="人" valueStyle={{ color: '#c9a063' }} /></Card></Col>
            <Col xs={12} md={6}><Card size="small"><Statistic title={<span className="flex items-center gap-2"><FileCheck size={14} style={{ color: '#2D8B55' }} />已备案</span>} value={resultStats.filedCount} suffix={`/ ${resultStats.totalWinners}`} valueStyle={{ color: '#2D8B55' }} /></Card></Col>
            <Col xs={12} md={6}><Card size="small"><Statistic title={<span className="flex items-center gap-2"><Handshake size={14} style={{ color: '#2D8B55' }} />已交接</span>} value={resultStats.handedOverCount} suffix={`/ ${resultStats.totalWinners}`} valueStyle={{ color: '#2D8B55' }} /></Card></Col>
            <Col xs={12} md={6}><Card size="small"><Statistic title={<span className="flex items-center gap-2"><Users size={14} style={{ color: '#8c1f28' }} />参选组织</span>} value={currentOrg.name} valueStyle={{ color: '#8c1f28', fontSize: 16 }} /></Card></Col>
          </Row>

          {resultError && <Alert type="error" message={resultError} showIcon />}

          {resultLoading ? (
            <Space direction="vertical" size="middle" style={{ width: '100%' }}>
              {[1, 2, 3].map((i) => <Skeleton key={i} active paragraph={{ rows: 2 }} />)}
            </Space>
          ) : results.length === 0 ? (
            <Card size="small"><div className="py-12 text-center">
              <Trophy size={32} style={{ margin: '0 auto 12px', color: '#9ca3af', opacity: 0.4 }} />
              <div className="text-sm text-muted-foreground mb-3">暂无选举结果数据</div>
              <Button type="default" size="small" icon={<Plus size={14} />} onClick={() => openEntryDialog('主任')}>录入首条结果</Button>
            </div></Card>
          ) : (
            <Card size="small" className="!p-0">
              <Table<ElectionResult> rowKey="id" columns={resultColumns} dataSource={results} pagination={false} size="small" scroll={{ x: 900 }} />
            </Card>
          )}
        </div>
      ),
    },
    {
      key: 'roster', label: '历届花名册',
      children: (
        <div className="space-y-4 pt-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <Space size="middle" wrap>
              <Space size={8}>
                <span className="text-sm text-muted-foreground">届次</span>
                <Select value={termFilter || 'all'} onChange={(v) => setTermFilter(v === 'all' ? '' : v)} style={{ width: 160 }}
                  options={[{ value: 'all', label: '全部届次' }, ...(rosterStats?.terms.map((t) => ({ value: t, label: `第${t}届` })) || [])]} />
              </Space>
              <Input placeholder="搜索姓名" value={searchText} onChange={(e) => setSearchText(e.target.value)}
                prefix={<Search size={14} style={{ color: '#6B7280' }} />} style={{ width: 180 }} allowClear />
            </Space>
            <Space size="middle">
              {rosterStats && <span className="text-xs text-muted-foreground">在任 <b className="text-foreground font-semibold">{rosterStats.activeCount}</b> 人 · 共 {rosterStats.total} 条</span>}
              <Button type="primary" size="small" icon={<Plus size={14} />} onClick={openCreateRoster}>新增</Button>
            </Space>
          </div>

          {rosterError && <Alert type="error" message={rosterError} showIcon />}

          {rosterLoading ? (
            <Space direction="vertical" size="small" style={{ width: '100%' }}>
              {[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} active paragraph={{ rows: 1 }} />)}
            </Space>
          ) : roster.length === 0 ? (
            <Card size="small"><div className="py-12 text-center">
              <Users size={32} style={{ margin: '0 auto 12px', color: '#9ca3af', opacity: 0.4 }} />
              <div className="text-sm text-muted-foreground mb-3">暂无花名册数据</div>
              <Button type="default" size="small" icon={<Plus size={14} />} onClick={openCreateRoster}>新增花名册</Button>
            </div></Card>
          ) : (
            <Card size="small" className="!p-0">
              <Table<RosterItem> rowKey="id" columns={rosterColumns} dataSource={roster} pagination={false} size="small" scroll={{ x: 900 }}
                rowClassName={(r) => (r.isActive ? 'bg-[hsl(152_50%_98%)]' : '')} />
            </Card>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageBreadcrumb items={[{ label: '选举结果' }]} />
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">选举结果</h1>
          <p className="text-sm text-muted-foreground mt-1">当选结果公示 · 备案与交接状态追踪 · 历届花名册管理</p>
        </div>
      </div>

      <Card size="small" className="!p-0">
        <Tabs activeKey={activeTab} onChange={setActiveTab} items={tabItems} size="small" />
      </Card>

      {currentOrg && currentElection && (
        <ResultEntryDialog open={dialogOpen} onOpenChange={setDialogOpen} position={activePosition}
          orgSlug={currentOrg.slug} electionId={currentElection.id} onSubmitted={loadResults} />
      )}

      {filingDialog.result && (
        <StatusUpdateModal open={filingDialog.open}
          onOpenChange={(open) => setFilingDialog((p) => ({ ...p, open }))}
          title="更新备案状态" currentStatus={filingDialog.result.filingStatus || '未备案'}
          options={FILING_OPTIONS} onSubmit={handleFilingUpdate} />
      )}

      {handoverDialog.result && (
        <StatusUpdateModal open={handoverDialog.open}
          onOpenChange={(open) => setHandoverDialog((p) => ({ ...p, open }))}
          title="更新交接状态" currentStatus={handoverDialog.result.handoverStatus || '未交接'}
          options={HANDOVER_OPTIONS} onSubmit={handleHandoverUpdate} />
      )}

      <RosterEditDialog open={rosterDialog.open}
        onOpenChange={(open) => setRosterDialog((p) => ({ ...p, open }))}
        mode={rosterDialog.mode} item={rosterDialog.item} orgId={currentOrg?.slug || ''}
        onSaved={handleRosterSaved} />
    </div>
  );
};

export default ResultPage;
