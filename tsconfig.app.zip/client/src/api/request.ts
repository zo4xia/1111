import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { ApiResponse } from '@shared/api.interface';
import { getToken, clearToken } from './auth';

const LOGIN_PATH = '/login';

function gotoLogin(): void {
  if (typeof window !== 'undefined') {
    window.location.replace(LOGIN_PATH);
  }
}

const request = axiosForBackend;

request.interceptors.request.use((config) => {
  const token = getToken();
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

request.interceptors.response.use(
  (response) => {
    const data = response.data as ApiResponse<unknown>;
    if (data && typeof data === 'object' && 'code' in data) {
      if (data.code === 401) {
        clearToken();
        if (typeof window !== 'undefined' && window.location.pathname !== LOGIN_PATH) {
          gotoLogin();
        }
        return Promise.reject(new Error(data.message || '未登录'));
      }
      if (data.code !== 0) {
        logger.error(`API error: ${data.message} (code: ${data.code})`);
        return Promise.reject(new Error(data.message || '请求失败'));
      }
    }
    return response;
  },
  (error) => {
    if (error?.response?.status === 401) {
      clearToken();
      if (typeof window !== 'undefined' && window.location.pathname !== LOGIN_PATH) {
        gotoLogin();
      }
    }
    logger.error(`Request failed: ${error.message}`);
    return Promise.reject(error);
  },
);

export default request;

export async function get<T>(url: string, params?: Record<string, unknown>): Promise<T> {
  const response = await request.get<ApiResponse<T>>(url, { params });
  return response.data.data as T;
}

export async function post<T>(url: string, data?: unknown): Promise<T> {
  const response = await request.post<ApiResponse<T>>(url, data);
  return response.data.data as T;
}

export async function put<T>(url: string, data?: unknown): Promise<T> {
  const response = await request.put<ApiResponse<T>>(url, data);
  return response.data.data as T;
}

export async function patch<T>(url: string, data?: unknown): Promise<T> {
  const response = await request.patch<ApiResponse<T>>(url, data);
  return response.data.data as T;
}

export async function del<T>(url: string): Promise<T> {
  const response = await request.delete<ApiResponse<T>>(url);
  return response.data.data as T;
}
