import { get, post, put, patch, del } from './request';
import type {
  ElectionResultOverview,
  ElectionResult,
  ElectionResultCreateDto,
  ElectionResultUpdateDto,
  ElectionResultFilingDto,
  ElectionResultHandoverDto,
  RosterItem,
  RosterCreateDto,
  RosterUpdateDto,
  RosterStats,
  ListResponse,
} from '@shared/api.interface';

export const resultApi = {
  getOverview: (electionId: string, orgId?: string) =>
    get<ElectionResultOverview>('/api/election-results/overview', {
      electionId,
      orgId,
    }),

  listResults: (params: {
    orgId?: string;
    electionId?: string;
    page?: number;
    pageSize?: number;
  }) =>
    get<ListResponse<ElectionResult>>('/api/election-results', {
      ...params,
    }),

  getResult: (id: string) =>
    get<ElectionResult>(`/api/election-results/${id}`),

  createResult: (data: ElectionResultCreateDto) =>
    post<{ id: string }>('/api/election-results', data),

  updateResult: (id: string, data: ElectionResultUpdateDto) =>
    put<{ success: boolean }>(`/api/election-results/${id}`, data),

  deleteResult: (id: string) =>
    del<{ success: boolean }>(`/api/election-results/${id}`),

  updateFiling: (id: string, data: ElectionResultFilingDto) =>
    patch<{ success: boolean }>(`/api/election-results/${id}/filing`, data),

  updateHandover: (id: string, data: ElectionResultHandoverDto) =>
    patch<{ success: boolean }>(`/api/election-results/${id}/handover`, data),

  listRoster: (params: {
    orgId?: string;
    term?: string;
    search?: string;
    page?: number;
    pageSize?: number;
  }) =>
    get<ListResponse<RosterItem>>('/api/roster', {
      ...params,
    }),

  getRoster: (id: string) =>
    get<RosterItem>(`/api/roster/${id}`),

  createRoster: (data: RosterCreateDto) =>
    post<{ id: string }>('/api/roster', data),

  updateRoster: (id: string, data: RosterUpdateDto) =>
    patch<{ success: boolean }>(`/api/roster/${id}`, data),

  deleteRoster: (id: string) =>
    del<{ success: boolean }>(`/api/roster/${id}`),

  getRosterTerms: (orgId?: string) =>
    get<RosterStats>('/api/roster/terms', { orgId }),
};
