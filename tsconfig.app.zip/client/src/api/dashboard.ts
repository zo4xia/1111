import { get } from './request';
import type { WorkstationData } from '@shared/api.interface';

export interface DashboardOverview {
  currentTerm: string;
  electionDate: string;
  daysToElection: number;
  voterCount: number;
  candidateCount: number;
  publishedAnnouncementCount: number;
  currentStage: { stageKey: string; stageName: string; status: string } | null;
}

export interface ReviewRoundStat {
  round: number;
  name: string;
  pendingCount: number;
  passCount: number;
  rejectCount: number;
  status: 'completed' | 'active' | 'pending';
}

export const dashboardApi = {
  getWorkstation: (orgId: string) =>
    get<WorkstationData>('/api/dashboard/workstation', { orgId }),
  getOverview: (orgId: string, electionId?: string) =>
    get<DashboardOverview>('/api/dashboard/overview', { orgId, electionId }),
  getReviewRounds: (electionId: string) =>
    get<ReviewRoundStat[]>('/api/dashboard/review-rounds', { electionId }),
};
