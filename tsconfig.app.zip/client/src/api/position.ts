import { get, post, put, del } from './request';
import type {
  Position,
  PositionCreateDto,
  PositionUpdateDto,
  PositionStats,
  ListResponse,
} from '@shared/api.interface';

export const positionApi = {
  stats: (params?: { orgId?: string; electionId?: string }) =>
    get<PositionStats>('/api/positions/stats', params),

  list: (params?: {
    orgId?: string;
    electionId?: string;
    status?: string;
    type?: string;
  }) => get<ListResponse<Position>>('/api/positions', params),

  detail: (id: string) =>
    get<Position>(`/api/positions/${id}`),

  create: (data: PositionCreateDto) =>
    post<{ id: string }>('/api/positions', data),

  update: (id: string, data: PositionUpdateDto) =>
    put<{ id: string }>(`/api/positions/${id}`, data),

  remove: (id: string) =>
    del<void>(`/api/positions/${id}`),
};
