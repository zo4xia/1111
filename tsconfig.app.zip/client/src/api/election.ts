import { get, put } from './request';
import type { Election, ListResponse } from '@shared/api.interface';

export const electionApi = {
  list: (orgId: string) => get<ListResponse<Election>>('/api/elections', { orgId }),
  getCurrent: (orgId: string) => get<Election | null>('/api/elections/current', { orgId }),
  updateElectionDate: (id: string, electionDate: string) =>
    put<{ id: string; electionDate: string }>(`/api/elections/${id}/election-date`, { electionDate }),
};
