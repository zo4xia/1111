import { get, patch } from './request';
import type { ElectionStage, StageStatus, ListResponse } from '@shared/api.interface';

export const electionStageApi = {
  list: (electionId: string) =>
    get<ListResponse<ElectionStage>>('/api/election-stages', { electionId }),
  updateStatus: (id: string, status: StageStatus) =>
    patch<ElectionStage>(`/api/election-stages/${id}/status`, { status }),
};
