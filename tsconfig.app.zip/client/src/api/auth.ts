import { post, get } from './request';
import type { LoginRequest, LoginResponse } from '@shared/api.interface';

const TOKEN_KEY = 'election_auth_token';

export function getToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || '';
  } catch {
    return '';
  }
}

export function setToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // ignore
  }
}

export function clearToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    // ignore
  }
}

export const authApi = {
  login: (body: LoginRequest) => post<LoginResponse>('/api/auth/login', body),

  getMe: () => get<LoginResponse>('/api/auth/me'),
};
