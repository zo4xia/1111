import { get, post, patch } from './request';
import type { PaginatedResponse } from '@shared/api.interface';

export interface AccountItem {
  id: string;
  name: string;
  phone: string;
  orgId: string;
  orgName: string;
  roles: string[];
  status: 'active' | 'disabled';
  lastLogin: string;
}

export interface RoleDef {
  key: string;
  label: string;
}

export interface RoleMetaResponse {
  roles: RoleDef[];
  quotas: Record<string, number>;
}

export const accountsApi = {
  list: (params?: {
    orgId?: string;
    role?: string;
    page?: number;
    pageSize?: number;
  }) => get<PaginatedResponse<AccountItem>>('/api/accounts', params),

  getRoleMeta: () => get<RoleMetaResponse>('/api/accounts/roles/meta'),

  create: (data: {
    phone: string;
    name: string;
    orgId: string;
    roles: string[];
    createdBy: string;
  }) => post<{ id: string }>('/api/accounts', data),

  assignRoles: (id: string, roles: string[], assignedBy: string) =>
    post<{ id: string; roles: string[] }>(`/api/accounts/${id}/roles`, {
      roles,
      assignedBy,
    }),

  toggleStatus: (id: string, status: 'active' | 'disabled') =>
    patch<{ id: string; status: string }>(`/api/accounts/${id}/status`, {
      status,
    }),
};
