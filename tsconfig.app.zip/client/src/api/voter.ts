import { get, post, put, patch, del } from './request';
import type { ListResponse, Voter, VoterStats } from '@shared/api.interface';

export const voterApi = {
  list: (params: Record<string, unknown>) =>
    get<ListResponse<Voter>>('/api/voters', params),
  get: (id: string) => get<Voter>(`/api/voters/${id}`),
  create: (data: Partial<Voter>) =>
    post<{ id: string }>('/api/voters', data),
  update: (id: string, data: Partial<Voter>) =>
    put<{ id: string }>(`/api/voters/${id}`, data),
  patch: (id: string, data: Partial<Voter>) =>
    patch<{ id: string }>(`/api/voters/${id}`, data),
  updateStatus: (id: string, status: string) =>
    patch<{ id: string; status: string }>(`/api/voters/${id}/status`, {
      status,
    }),
  remove: (id: string) => del<{ id: string }>(`/api/voters/${id}`),
  statistics: (electionId: string, orgId?: string) =>
    get<VoterStats>('/api/voters/statistics', { electionId, orgId }),
  stats: (electionId: string, orgId?: string) =>
    get<VoterStats>('/api/voters/stats', { electionId, orgId }),
  batchCreate: (items: Partial<Voter>[]) =>
    post<{ inserted: number; ids: string[] }>('/api/voters/batch', { items }),
};
