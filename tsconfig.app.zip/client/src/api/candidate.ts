import { get, post, put, del } from './request';
import type { Candidate, CandidateDetail, CandidateCreateDto, CandidateUpdateDto, ListResponse } from '@shared/api.interface';

export const candidateApi = {
  list: (params: {
    electionId?: string;
    orgId?: string;
    position?: string;
    status?: string;
    round?: number;
    page?: number;
    pageSize?: number;
  }) => get<ListResponse<Candidate>>('/api/candidates', params),

  getById: (id: string) =>
    get<CandidateDetail>(`/api/candidates/${id}`),

  review: (
    id: string,
    round: number,
    result: string,
    comment: string,
    reviewer: string,
  ) =>
    post<{ id: string; round: number; status: string; overallStatus: string }>(
      `/api/candidates/${id}/review`,
      { round, result, comment, reviewer },
    ),

  create: (data: CandidateCreateDto) =>
    post<{ id: string }>('/api/candidates', data),

  update: (id: string, data: CandidateUpdateDto) =>
    put<{ id: string }>(`/api/candidates/${id}`, data),

  remove: (id: string) =>
    del<void>(`/api/candidates/${id}`),
};
