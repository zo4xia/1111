import { get } from './request';
import type { Organization, ListResponse } from '@shared/api.interface';

export const organizationApi = {
  list: () => get<ListResponse<Organization>>('/api/organizations'),
};
