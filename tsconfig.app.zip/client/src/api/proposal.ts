import { get, post, patch, del } from './request';
import type {
  Proposal,
  ProposalDetail,
  ProposalCreateDto,
  ProposalUpdateDto,
  ProposalStats,
  ListResponse,
} from '@shared/api.interface';

export const proposalApi = {
  stats: (params?: { orgId?: string; electionId?: string }) =>
    get<ProposalStats>('/api/proposals/stats', params),

  list: (params?: {
    orgId?: string;
    electionId?: string;
    status?: string;
    method?: string;
  }) => get<ListResponse<Proposal>>('/api/proposals', params),

  detail: (id: string) =>
    get<ProposalDetail>(`/api/proposals/${id}`),

  create: (data: ProposalCreateDto) =>
    post<{ id: string }>('/api/proposals', data),

  update: (id: string, data: ProposalUpdateDto) =>
    patch<{ id: string }>(`/api/proposals/${id}`, data),

  remove: (id: string) =>
    del<void>(`/api/proposals/${id}`),

  submit: (id: string) =>
    patch<{ id: string; status: string }>(`/api/proposals/${id}/submit`),

  approve: (id: string) =>
    patch<{ id: string; status: string }>(`/api/proposals/${id}/approve`),

  reject: (id: string, comment: string) =>
    patch<{ id: string; status: string }>(`/api/proposals/${id}/reject`, {
      comment,
    }),
};
