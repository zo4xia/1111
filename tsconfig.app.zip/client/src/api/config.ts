import { get, put, post } from './request';
import type { SystemConfig, SystemInfo } from '@shared/api.interface';

export const configApi = {
  getSystemConfig: () => get<SystemConfig>('/api/config/system'),
  saveSystemConfig: (data: Partial<SystemConfig>) =>
    put<SystemConfig>('/api/config/system', data),
  getSystemInfo: () => get<SystemInfo>('/api/config/info'),
  testConnection: (type: 'sms' | 'postgres') =>
    post<{ ok: boolean; message: string; details?: string }>('/api/config/system/test-connection', { type }),
};
