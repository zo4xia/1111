import { get, post, patch, del } from './request';
import type {
  Archive,
  ArchiveDetail,
  ArchiveCreateDto,
  ArchiveUpdateDto,
  ArchiveStats,
  ListResponse,
} from '@shared/api.interface';

export const archiveApi = {
  stats: (params?: { orgId?: string; electionId?: string }) =>
    get<ArchiveStats>('/api/archives/stats', params),

  list: (params?: {
    orgId?: string;
    electionId?: string;
    sourceType?: string;
    visibility?: string;
  }) => get<ListResponse<Archive>>('/api/archives', params),

  detail: (id: string) =>
    get<ArchiveDetail>(`/api/archives/${id}`),

  create: (data: ArchiveCreateDto) =>
    post<{ id: string }>('/api/archives', data),

  update: (id: string, data: ArchiveUpdateDto) =>
    patch<{ id: string }>(`/api/archives/${id}`, data),

  remove: (id: string) =>
    del<void>(`/api/archives/${id}`),

  restore: (id: string) =>
    post<{ id: string }>(`/api/archives/${id}/restore`),
};
