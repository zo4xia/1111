import { get } from './request';
import type { PaginatedResponse } from '@shared/api.interface';

export interface OperationLog {
  id: string;
  operationTime: string;
  operator: string;
  type: string;
  target: string;
  summary: string;
  ip: string;
}

export interface LogListParams extends Record<string, unknown> {
  operator?: string;
  type?: string;
  startDate?: string;
  endDate?: string;
  page?: number;
  pageSize?: number;
}

export const logApi = {
  list: (params?: LogListParams) =>
    get<PaginatedResponse<OperationLog>>('/api/logs', params),
  getById: (id: string) => get<OperationLog>(`/api/logs/${id}`),
};

export const LOG_TYPE_OPTIONS = [
  { value: 'login', label: '登录' },
  { value: 'create', label: '新增' },
  { value: 'update', label: '修改' },
  { value: 'delete', label: '删除' },
  { value: 'approve', label: '审核' },
  { value: 'export', label: '导出' },
];

export const LOG_TYPE_LABELS: Record<string, string> = LOG_TYPE_OPTIONS.reduce(
  (acc, item) => {
    acc[item.value] = item.label;
    return acc;
  },
  {} as Record<string, string>,
);
