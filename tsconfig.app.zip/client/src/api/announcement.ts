import { get, post, put, patch, del } from './request';
import type { ListResponse } from '@shared/api.interface';
import type {
  Announcement,
  AnnouncementDetail,
  AnnouncementStatus,
  AnnouncementTemplate,
} from '@shared/api.interface';

export const announcementApi = {
  // 公告列表/详情
  list: (params: Record<string, unknown>) =>
    get<ListResponse<Announcement>>('/api/announcements', params),
  getById: (id: string) =>
    get<AnnouncementDetail>(`/api/announcements/${id}`),
  update: (id: string, data: Record<string, unknown>) =>
    put<{ id: string; status: string }>(`/api/announcements/${id}`, data),
  remove: (id: string) =>
    del<void>(`/api/announcements/${id}`),

  // 公告模板
  listTemplates: (params: Record<string, unknown>) =>
    get<ListResponse<AnnouncementTemplate>>(
      '/api/announcements/templates/list',
      params,
    ),
  getTemplateById: (id: string) =>
    get<AnnouncementTemplate>(`/api/announcements/templates/${id}`),
  useTemplate: (
    templateId: string,
    electionId: string,
    orgId: string,
  ) =>
    post<AnnouncementDetail>(
      `/api/announcements/templates/${templateId}/use`,
      { electionId, orgId },
    ),

  // 状态流转
  submitReview: (id: string, editor?: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/submit`,
      { editor },
    ),
  approve: (id: string, reviewer?: string, comment?: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/approve`,
      { reviewer, comment },
    ),
  reject: (id: string, comment: string, reviewer?: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/reject`,
      { reviewer, comment },
    ),
  publish: (id: string, reviewer?: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/publish`,
      { reviewer },
    ),
  freeze: (id: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/freeze`,
      {},
    ),
  unfreeze: (id: string) =>
    patch<{ id: string; status: AnnouncementStatus }>(
      `/api/announcements/${id}/unfreeze`,
      {},
    ),
};
