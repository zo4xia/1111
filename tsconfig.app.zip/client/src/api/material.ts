import { get, post, put, del } from './request';
import type {
  Material,
  MaterialDetail,
  MaterialStats,
  ListResponse,
} from '@shared/api.interface';

export const materialApi = {
  list: (params: {
    orgId?: string;
    positionId?: string;
    type?: string;
    status?: string;
    electionId?: string;
    stage?: string;
    page?: number;
    pageSize?: number;
  }) => get<ListResponse<Material>>('/api/materials', params),

  stats: (params: { orgId?: string; electionId?: string }) =>
    get<MaterialStats>('/api/materials/stats', params),

  getById: (id: string) =>
    get<MaterialDetail>(`/api/materials/${id}`),

  create: (data: Partial<MaterialDetail>) =>
    post<{ id: string }>('/api/materials', data),

  update: (id: string, data: Partial<MaterialDetail>) =>
    put<{ id: string }>(`/api/materials/${id}`, data),

  remove: (id: string) =>
    del<{ success: boolean }>(`/api/materials/${id}`),

  review: (id: string, action: string, comment?: string) =>
    post<{ id: string; status: string; candidateId?: string }>(
      `/api/materials/${id}/review`,
      { action, comment },
    ),

  resubmit: (id: string, submitter?: string) =>
    post<{ id: string; status: string }>(
      `/api/materials/${id}/resubmit`,
      { submitter },
    ),
};
