export * from '@shared/api.interface';

export interface Organization {
  id: string;
  slug: string;
  name: string;
  town: string;
  type: 'platform' | 'community_committee' | 'village_committee';
  status: string;
  phone: string;
  person: string;
}

export interface Election {
  id: string;
  orgId: string;
  term: string;
  name: string;
  status: string;
  electionDate: string;
  method: string;
  proposalId?: string;
}

export interface ElectionStage {
  id: string;
  electionId: string;
  stageKey: string;
  stageName: string;
  offsetStart: number;
  offsetEnd: number;
  planStart: string;
  planEnd: string;
  status: string;
  bizModule: string;
  note?: string;
}

export interface DashboardOverview {
  currentTerm: string;
  electionDate: string;
  daysToElection: number;
  voterCount: number;
  candidateCount: number;
  publishedAnnouncementCount: number;
  currentStage: { stageKey: string; stageName: string; status: string };
}

export interface ReviewRoundStat {
  round: number;
  name: string;
  pendingCount: number;
  passCount: number;
  rejectCount: number;
  status: 'completed' | 'active' | 'pending';
}

export interface Candidate {
  id: string;
  name: string;
  gender: string;
  age: number;
  position: string;
  source: string;
  r1Status: string;
  r2Status: string;
  r3Status: string;
  r4Status: string;
  status: string;
  votes?: number;
}

export interface Voter {
  id: string;
  name: string;
  gender: string;
  age: number;
  idCard: string;
  phone: string;
  group: string;
  status: string;
  registerTime: string;
}

export interface VoterStats {
  total: number;
  maleCount: number;
  femaleCount: number;
  groupDistribution: Array<{ group: string; count: number }>;
  awayCount: number;
}

export interface Announcement {
  id: string;
  code: string;
  title: string;
  stageKey: string;
  status: string;
  version: number;
  editor: string;
  publishTime?: string;
}

export interface Material {
  id: string;
  applicant: string;
  position: string;
  type: string;
  submitter: string;
  submitTime: string;
  status: string;
  reviewer?: string;
}

export interface Proposal {
  id: string;
  title: string;
  method: string;
  status: string;
  version: number;
  creatorId: string;
  submitTime?: string;
}

export interface Position {
  id: string;
  type: string;
  quota: number;
  status: string;
  description: string;
  requirement?: string;
  isLocked: boolean;
}

export interface ElectionResultItem {
  id: string;
  position: string;
  winnerName: string;
  votes: number;
  turnout: string;
  candidates: Array<{
    id: string;
    name: string;
    votes: number;
    voteRate: string;
    isElected: boolean;
  }>;
}

export interface ElectionResultOverview {
  electionDate: string;
  eligibleVoters: number;
  actualVoters: number;
  validVotes: number;
  invalidVotes: number;
  turnout: string;
}

export interface ArchiveItem {
  id: string;
  sourceType: string;
  sourceId: string;
  displayName: string;
  fileVersion: string;
  visibility: string;
  archivedAt: string;
}

export interface Account {
  id: string;
  phone: string;
  name: string;
  orgId: string;
  orgName: string;
  roles: string[];
  status: string;
  lastLogin?: string;
}

export interface OperationLog {
  id: string;
  operationTime: string;
  operator: string;
  type: string;
  target: string;
  summary: string;
  ip: string;
}
