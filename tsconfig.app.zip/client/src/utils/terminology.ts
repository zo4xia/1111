const VILLAGE_TERMS = {
  villager: '村民',
  villageCommittee: '村委会',
  village: '村',
};

const COMMUNITY_TERMS = {
  villager: '居民',
  villageCommittee: '居委会',
  village: '社区',
};

type OrgType = 'village_committee' | 'community_committee' | 'platform';

export function getTerminologyMap(orgType: OrgType) {
  if (orgType === 'community_committee') {
    return COMMUNITY_TERMS;
  }
  return VILLAGE_TERMS;
}

export function replaceTerminology(text: string, orgType: OrgType): string {
  const terms = getTerminologyMap(orgType);
  let result = text;
  result = result.replace(/村民/g, terms.villager);
  result = result.replace(/村委会/g, terms.villageCommittee);
  return result;
}

export function isVillageType(orgType: OrgType): boolean {
  return orgType === 'village_committee';
}

export function isCommunityType(orgType: OrgType): boolean {
  return orgType === 'community_committee';
}

export function shouldShowAnnouncement17_1(orgType: OrgType): boolean {
  return orgType === 'village_committee';
}
