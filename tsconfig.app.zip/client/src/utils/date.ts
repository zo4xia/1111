import dayjs from 'dayjs';

export function formatDate(date: string | Date, format = 'YYYY-MM-DD'): string {
  return dayjs(date).format(format);
}

export function formatDateTime(date: string | Date, format = 'YYYY-MM-DD HH:mm'): string {
  return dayjs(date).format(format);
}

export function daysBetween(from: string | Date, to: string | Date): number {
  return dayjs(to).startOf('day').diff(dayjs(from).startOf('day'), 'day');
}

export function daysUntil(date: string | Date): number {
  return dayjs(date).startOf('day').diff(dayjs().startOf('day'), 'day');
}

export function addDays(date: string | Date, days: number): string {
  return dayjs(date).add(days, 'day').format('YYYY-MM-DD');
}
