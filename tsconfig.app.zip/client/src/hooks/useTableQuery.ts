import { useState, useCallback, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';

interface UseTableQueryOptions<TParams extends Record<string, unknown>> {
  fetchFn: (params: TParams & { page: number; pageSize: number }) => Promise<{
    items: unknown[];
    total: number;
  }>;
  defaultPageSize?: number;
  defaultParams?: TParams;
  autoFetch?: boolean;
}

export function useTableQuery<TItem, TParams extends Record<string, unknown>>(
  options: UseTableQueryOptions<TParams>,
) {
  const { fetchFn, defaultPageSize = 20, defaultParams = {} as TParams, autoFetch = true } = options;

  const [items, setItems] = useState<TItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(defaultPageSize);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [params, setParams] = useState<TParams>(defaultParams);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchFn({ ...params, page, pageSize });
      setItems(result.items as TItem[]);
      setTotal(result.total);
    } catch (err) {
      const message = err instanceof Error ? err.message : '加载失败';
      setError(message);
      logger.error(`useTableQuery error: ${message}`);
    } finally {
      setLoading(false);
    }
  }, [fetchFn, params, page, pageSize]);

  useEffect(() => {
    if (autoFetch) {
      loadData();
    }
  }, [loadData, autoFetch]);

  const handlePageChange = useCallback((newPage: number) => {
    setPage(newPage);
  }, []);

  const handlePageSizeChange = useCallback((newPageSize: number) => {
    setPageSize(newPageSize);
    setPage(1);
  }, []);

  const handleSearch = useCallback((newParams: TParams) => {
    setParams(newParams);
    setPage(1);
  }, []);

  const refresh = useCallback(() => {
    loadData();
  }, [loadData]);

  return {
    items,
    total,
    page,
    pageSize,
    loading,
    error,
    params,
    handlePageChange,
    handlePageSizeChange,
    handleSearch,
    refresh,
  };
}
