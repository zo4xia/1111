import type { ThemeConfig } from 'antd';

const themeToken: ThemeConfig = {
  token: {
    colorPrimary: '#8c1f28',
    colorInfo: '#8c1f28',
    colorSuccess: '#2D8B55',
    colorWarning: '#c9a063',
    colorError: '#8c1f28',
    colorLink: '#8c1f28',
    colorTextBase: '#2b2626',
    colorBgBase: '#FAF8F5',
    colorBgContainer: '#ffffff',
    colorBgElevated: '#ffffff',
    colorBorder: '#E5E1DB',
    colorBorderSecondary: '#F0EDE7',
    borderRadius: 4,
    fontFamily:
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'Noto Sans CJK SC', sans-serif",
    fontSize: 14,
    controlHeight: 32,
    controlHeightSM: 24,
    controlHeightLG: 40,
  },
  components: {
    Table: {
      headerBg: '#FAF8F5',
      headerColor: '#8c1f28',
      borderColor: '#E5E1DB',
      rowHoverBg: '#FDF6E3',
      fontSize: 13,
      paddingXS: 4,
      paddingSM: 8,
    },
    Button: {
      colorPrimary: '#8c1f28',
      colorPrimaryHover: '#a02932',
      colorPrimaryActive: '#6d141c',
      borderRadius: 4,
      controlHeight: 32,
      controlHeightSM: 24,
    },
    Card: {
      borderRadius: 8,
      colorBorderSecondary: '#E5E1DB',
      headerBg: '#FFFDF9',
    },
    Tag: {
      borderRadius: 4,
    },
    Tabs: {
      itemColor: '#6B7280',
      itemSelectedColor: '#8c1f28',
      itemHoverColor: '#a02932',
      inkBarColor: '#8c1f28',
    },
    Select: {
      colorPrimary: '#8c1f28',
      colorPrimaryHover: '#a02932',
      optionSelectedBg: '#FDF6E3',
      borderRadius: 4,
    },
    DatePicker: {
      colorPrimary: '#8c1f28',
      colorPrimaryHover: '#a02932',
      borderRadius: 4,
    },
    Drawer: {
      colorBorderSecondary: '#E5E1DB',
    },
    Progress: {
      colorInfo: '#8c1f28',
    },
    Pagination: {
      colorPrimary: '#8c1f28',
      itemActiveBg: '#8c1f28',
      itemLinkBg: '#ffffff',
    },
    Input: {
      colorPrimary: '#8c1f28',
      colorPrimaryHover: '#a02932',
      borderRadius: 4,
    },
    InputNumber: {
      colorPrimary: '#8c1f28',
      colorPrimaryHover: '#a02932',
      borderRadius: 4,
    },
    Modal: {
      headerBg: '#FFFDF9',
      colorBorderSecondary: '#E5E1DB',
    },
    Descriptions: {
      colorBorderSecondary: '#E5E1DB',
      labelBg: '#FAF8F5',
    },
    Alert: {
      borderRadius: 4,
    },
    Badge: {
      colorPrimary: '#8c1f28',
      colorSuccess: '#2D8B55',
      colorWarning: '#c9a063',
      colorError: '#8c1f28',
    },
    Statistic: {
      colorText: '#8c1f28',
      fontSize: 26,
    },
    Timeline: {
      colorPrimary: '#8c1f28',
    },
  },
};

export default themeToken;
