import React from 'react';
import { Route, Routes, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import themeToken from './theme/antd-theme';

import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ElectionProvider } from './contexts/ElectionContext';
import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';
import LoginPage from './pages/Login/Login';
import DashboardPage from './pages/Dashboard/Dashboard';
import ProposalPage from './pages/Proposal/Proposal';
import ElectionPage from './pages/Election/Election';
import ElectionsListPage from './pages/Election/ElectionsListPage';
import CandidateManagerPage from './pages/Voter/CandidateManagerPage';
import PositionPage from './pages/Position/Position';
import MaterialPage from './pages/Material/Material';
import CandidatePage from './pages/Candidate/Candidate';
import NoticePage from './pages/Notice/Notice';
import ResultPage from './pages/Result/Result';
import ArchivePage from './pages/Archive/Archive';
import UserPage from './pages/User/User';
import LogPage from './pages/Log/Log';
import ConfigPage from './pages/Config/Config';

function RequireAuth({ children }: { children: React.ReactElement }) {
  const { authenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">加载中...</div>;
  }
  if (!authenticated) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }
  return children;
}

function AuthAwareLayout() {
  const { account, roleKey, canEditDate, canReview, visibleOrgs, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  return (
    <ElectionProvider
      authAccount={account}
      authRoleKey={roleKey}
      canEditDate={canEditDate}
      canReview={canReview}
      visibleOrgs={visibleOrgs}
      onLogout={handleLogout}
    >
      <Layout />
    </ElectionProvider>
  );
}

const RoutesComponent = () => {
  return (
    <ConfigProvider locale={zhCN} theme={themeToken}>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            element={
              <RequireAuth>
                <AuthAwareLayout />
              </RequireAuth>
            }
          >
            <Route index element={<DashboardPage />} />
            <Route path="proposal" element={<ProposalPage />} />
            <Route path="elections" element={<ElectionsListPage />} />
            <Route path="election" element={<ElectionPage />} />
            <Route path="voter" element={<CandidateManagerPage />} />
            <Route path="position" element={<PositionPage />} />
            <Route path="material" element={<MaterialPage />} />
            <Route path="candidate" element={<CandidatePage />} />
            <Route path="notice" element={<NoticePage />} />
            <Route path="result" element={<ResultPage />} />
            <Route path="archive" element={<ArchivePage />} />
            <Route path="user" element={<UserPage />} />
            <Route path="log" element={<LogPage />} />
            <Route path="config" element={<ConfigPage />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AuthProvider>
    </ConfigProvider>
  );
};

export default RoutesComponent;
