@echo off
cd /d E:\w\0\election-v2-2.0\0716\g5
set NODE_ENV=development
"E:\w\0\election-v2-2.0\0716\node22\node-v22.21.0-win-x64\node.exe" node_modules\vite\bin\vite.js --config vite.config.ts
