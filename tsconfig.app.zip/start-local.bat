@echo off
chcp 65001 >nul
title 城厢区村居换届选举系统 - 一键启动
echo ============================================
echo   城厢区村居换届选举系统 - 一键启动
echo ============================================
set G5=E:\w\0\election-v2-2.0\0716\g5
set PG_BIN=E:\w\0\election-v2-2.0\0716\pg\pgsql\bin
set PG_DATA=E:\w\0\election-v2-2.0\0716\pg\data

REM ===== 1/3 本地数据库 (PostgreSQL 17) =====
tasklist | findstr /i "postgres.exe" >nul 2>&1
if %errorlevel%==0 (
  echo [1/3] 数据库已运行
) else (
  echo [1/3] 启动本地数据库...
  start "PG-Database" /min "%PG_BIN%\postgres.exe" -D "%PG_DATA%" -p 5432 -h 127.0.0.1
  timeout /t 3 /nobreak >nul
)

REM ===== 2/3 后端 (端口 3000) =====
netstat -ano | findstr ":3000 " | findstr "LISTENING" >nul 2>&1
if %errorlevel%==0 (
  echo [2/3] 后端已运行
) else (
  echo [2/3] 启动后端...
  start "G5-Backend" /min "%G5%\start-backend.cmd"
  timeout /t 10 /nobreak >nul
)

REM ===== 3/3 前端 (端口 8080) =====
netstat -ano | findstr ":8080 " | findstr "LISTENING" >nul 2>&1
if %errorlevel%==0 (
  echo [3/3] 前端已运行
) else (
  echo [3/3] 启动前端...
  start "G5-Frontend" /min "%G5%\start-frontend.cmd"
  timeout /t 5 /nobreak >nul
)

echo.
echo ============================================
echo   系统已就绪
echo   访问地址:  http://localhost:8080/client/
echo   演示账号:  13800000001
echo   演示密码:  123456
echo ============================================
echo.
pause
