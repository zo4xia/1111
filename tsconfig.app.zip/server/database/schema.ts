/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { boolean, date, index, integer, pgTable, text, timestamp, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const systemConfigs = pgTable("system_configs", {
  id: uuid("id").primaryKey().defaultRandom(),
  configKey: varchar("config_key", { length: 100 }).notNull().unique(),
  configValue: text("config_value"),
  configType: varchar("config_type", { length: 20 }).default('string'),
  configGroup: varchar("config_group", { length: 50 }),
  configDesc: text("config_desc"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("system_configs_config_key_key").on(table.configKey),
]);

export const stageTemplates = pgTable("stage_templates", {
  id: uuid("id").primaryKey().defaultRandom(),
  stKey: varchar("st_key", { length: 50 }).notNull().unique(),
  stName: varchar("st_name", { length: 100 }),
  stDayOffset: integer("st_day_offset"),
  stDurationDays: integer("st_duration_days"),
  stOrder: integer("st_order"),
  stDescription: text("st_description"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("stage_templates_st_key_key").on(table.stKey),
]);

export const electionResults = pgTable("election_results", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  orgName: varchar("org_name", { length: 255 }),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  erElectionDate: date("er_election_date"),
  erPosition: varchar("er_position", { length: 50 }),
  erWinnerName: varchar("er_winner_name", { length: 100 }),
  erVotes: integer("er_votes"),
  erEligibleVoters: integer("er_eligible_voters"),
  erActualVoters: integer("er_actual_voters"),
  erValidVotes: integer("er_valid_votes"),
  erInvalidVotes: integer("er_invalid_votes"),
  erTurnout: varchar("er_turnout", { length: 20 }),
  erResultAnnCode: varchar("er_result_ann_code", { length: 50 }),
  erFilingStatus: varchar("er_filing_status", { length: 20 }),
  erFilingTime: date("er_filing_time"),
  erHandoverStatus: varchar("er_handover_status", { length: 20 }),
  erNote: text("er_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const roster = pgTable("roster", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  rosPosition: varchar("ros_position", { length: 50 }),
  rosName: varchar("ros_name", { length: 100 }),
  rosPhone: varchar("ros_phone", { length: 50 }),
  rosTerm: varchar("ros_term", { length: 50 }),
  rosYearStart: integer("ros_year_start"),
  rosYearEnd: integer("ros_year_end"),
  rosStatus: varchar("ros_status", { length: 20 }),
  rosIsActive: boolean("ros_is_active").default(true),
  rosSessionNo: varchar("ros_session_no", { length: 50 }),
  rosNote: text("ros_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const archives = pgTable("archives", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  archSourceType: varchar("arch_source_type", { length: 50 }),
  archSourceId: varchar("arch_source_id", { length: 100 }),
  archFileVersion: varchar("arch_file_version", { length: 50 }),
  archDisplayName: varchar("arch_display_name", { length: 255 }),
  archVisibility: varchar("arch_visibility", { length: 20 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  notifId: varchar("notif_id", { length: 50 }),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }),
  notifType: varchar("notif_type", { length: 50 }),
  notifContent: text("notif_content"),
  notifToRoleFilter: varchar("notif_to_role_filter", { length: 255 }),
  notifToPhones: text("notif_to_phones"),
  notifStatus: varchar("notif_status", { length: 20 }),
  notifScheduledAt: timestamp("notif_scheduled_at", { mode: 'string' }),
  notifSourceType: varchar("notif_source_type", { length: 50 }),
  notifSourceKey: varchar("notif_source_key", { length: 100 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const proposals = pgTable("proposals", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  propTitle: varchar("prop_title", { length: 255 }),
  propMethod: varchar("prop_method", { length: 50 }),
  propCreatorId: varchar("prop_creator_id", { length: 50 }),
  propStatus: varchar("prop_status", { length: 20 }),
  propVersion: integer("prop_version").default(1),
  propSubmitTime: timestamp("prop_submit_time", { mode: 'string' }),
  propReviewerId: varchar("prop_reviewer_id", { length: 50 }),
  propReviewTime: timestamp("prop_review_time", { mode: 'string' }),
  propReviewComment: text("prop_review_comment"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const positions = pgTable("positions", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  posType: varchar("pos_type", { length: 50 }),
  posQuota: integer("pos_quota").default(1),
  posStatus: varchar("pos_status", { length: 20 }),
  posDesc: text("pos_desc"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const accountRoles = pgTable("account_roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  roleKey: varchar("role_key", { length: 50 }).notNull(),
  arStatus: varchar("ar_status", { length: 20 }),
  arAssignedBy: varchar("ar_assigned_by", { length: 100 }),
  arNote: text("ar_note"),
  accId: uuid("acc_id").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const roles = pgTable("roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  roleKey: varchar("role_key", { length: 50 }).notNull().unique(),
  roleName: varchar("role_name", { length: 100 }),
  roleScope: varchar("role_scope", { length: 50 }),
  roleDesc: text("role_desc"),
  rolePermissions: text("role_permissions"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("roles_role_key_key").on(table.roleKey),
]);

export const accounts = pgTable("accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  accName: varchar("acc_name", { length: 100 }),
  accPhone: varchar("acc_phone", { length: 50 }),
  accPasswordHint: varchar("acc_password_hint", { length: 100 }),
  org: varchar("org", { length: 100 }),
  roles: varchar("roles", { length: 100 }),
  accStatus: varchar("acc_status", { length: 20 }),
  accCreatedBy: varchar("acc_created_by", { length: 100 }),
  accNote: text("acc_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const announcementTemplates = pgTable("announcement_templates", {
  id: uuid("id").primaryKey().defaultRandom(),
  atCode: varchar("at_code", { length: 50 }).notNull(),
  atName: varchar("at_name", { length: 255 }),
  atVersion: varchar("at_version", { length: 50 }),
  atContent: text("at_content"),
  atNeedRemind: boolean("at_need_remind").default(false),
  atNote: text("at_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const materials = pgTable("materials", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  matPositionId: varchar("mat_position_id", { length: 50 }),
  matApplicantId: varchar("mat_applicant_id", { length: 50 }),
  matType: varchar("mat_type", { length: 50 }),
  matStatus: varchar("mat_status", { length: 20 }),
  matSubmitter: varchar("mat_submitter", { length: 100 }),
  matSubmitterPhone: varchar("mat_submitter_phone", { length: 50 }),
  matSubmitTime: timestamp("mat_submit_time", { mode: 'string' }),
  matReviewTime: timestamp("mat_review_time", { mode: 'string' }),
  matReviewer: varchar("mat_reviewer", { length: 100 }),
  matReviewComment: text("mat_review_comment"),
  matCandidateId: varchar("mat_candidate_id", { length: 100 }),
  matNote: text("mat_note"),
  matStage: varchar("mat_stage", { length: 50 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const announcements = pgTable("announcements", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }),
  annCode: varchar("ann_code", { length: 50 }),
  annTitle: varchar("ann_title", { length: 255 }),
  annStageKey: varchar("ann_stage_key", { length: 50 }),
  annStatus: varchar("ann_status", { length: 20 }),
  annVersion: integer("ann_version").default(1),
  annEditor: varchar("ann_editor", { length: 100 }),
  annEditTime: timestamp("ann_edit_time", { mode: 'string' }),
  annReviewer: varchar("ann_reviewer", { length: 100 }),
  annReviewTime: timestamp("ann_review_time", { mode: 'string' }),
  annPublishTime: timestamp("ann_publish_time", { mode: 'string' }),
  annPublicityDeadline: timestamp("ann_publicity_deadline", { mode: 'string' }),
  annContent: text("ann_content"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const voters = pgTable("voters", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  votName: varchar("vot_name", { length: 100 }).notNull(),
  votGender: varchar("vot_gender", { length: 10 }),
  votAge: integer("vot_age"),
  votIdCard: varchar("vot_id_card", { length: 50 }),
  votPhone: varchar("vot_phone", { length: 50 }),
  votHouseholdAddr: varchar("vot_household_addr", { length: 500 }),
  votResidenceAddr: varchar("vot_residence_addr", { length: 500 }),
  votRegisterTime: date("vot_register_time"),
  votStatus: varchar("vot_status", { length: 20 }),
  votNote: text("vot_note"),
  votSource: varchar("vot_source", { length: 50 }).default('registered'),
  votPositionId: varchar("vot_position_id", { length: 50 }),
  votMaterialStatus: varchar("vot_material_status", { length: 20 }).default('none'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const candidates = pgTable("candidates", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  candName: varchar("cand_name", { length: 100 }).notNull(),
  candPositionId: varchar("cand_position_id", { length: 50 }),
  candAccId: varchar("cand_acc_id", { length: 50 }),
  candSource: varchar("cand_source", { length: 50 }),
  candGender: varchar("cand_gender", { length: 10 }),
  candAge: integer("cand_age"),
  candIdCard: varchar("cand_id_card", { length: 50 }),
  candPhone: varchar("cand_phone", { length: 50 }),
  candR1: varchar("cand_r1", { length: 20 }),
  candR1Reviewer: varchar("cand_r1_reviewer", { length: 100 }),
  candR1Time: timestamp("cand_r1_time", { mode: 'string' }),
  candR1Comment: text("cand_r1_comment"),
  candR2: varchar("cand_r2", { length: 20 }),
  candR2Reviewer: varchar("cand_r2_reviewer", { length: 100 }),
  candR2Time: timestamp("cand_r2_time", { mode: 'string' }),
  candR2Comment: text("cand_r2_comment"),
  candR3: varchar("cand_r3", { length: 20 }),
  candR3Reviewer: varchar("cand_r3_reviewer", { length: 100 }),
  candR3Time: timestamp("cand_r3_time", { mode: 'string' }),
  candR3Comment: text("cand_r3_comment"),
  candR4: varchar("cand_r4", { length: 20 }),
  candR4Reviewer: varchar("cand_r4_reviewer", { length: 100 }),
  candR4Time: timestamp("cand_r4_time", { mode: 'string' }),
  candR4Comment: text("cand_r4_comment"),
  candStatus: varchar("cand_status", { length: 20 }),
  candVotes: integer("cand_votes").default(0),
  candNote: text("cand_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const electionStages = pgTable("election_stages", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  electionId: varchar("election_id", { length: 50 }).notNull(),
  stageKey: varchar("stage_key", { length: 50 }).notNull(),
  stageName: varchar("stage_name", { length: 100 }),
  stageStatus: varchar("stage_status", { length: 20 }),
  stageStartDate: date("stage_start_date"),
  stageEndDate: date("stage_end_date"),
  stageOrder: integer("stage_order"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const elections = pgTable("elections", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: varchar("org_id", { length: 100 }).notNull(),
  elId: varchar("el_id", { length: 50 }).notNull(),
  elTerm: varchar("el_term", { length: 50 }),
  elName: varchar("el_name", { length: 255 }),
  elStatus: varchar("el_status", { length: 20 }),
  elElectionDate: date("el_election_date"),
  elMethod: varchar("el_method", { length: 50 }),
  elProposalId: varchar("el_proposal_id", { length: 100 }),
  elNote: text("el_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("elections_org_id_el_id_key").on(table.orgId, table.elId),
]);

export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  town: varchar("town", { length: 100 }),
  type: varchar("type", { length: 50 }),
  status: varchar("status", { length: 20 }),
  orgPhone: varchar("org_phone", { length: 50 }),
  orgPerson: varchar("org_person", { length: 100 }),
  orgNote: text("org_note"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("organizations_slug_key").on(table.slug),
]);

// table aliases
export const accountRolesTable = accountRoles;
export const accountsTable = accounts;
export const announcementTemplatesTable = announcementTemplates;
export const announcementsTable = announcements;
export const archivesTable = archives;
export const candidatesTable = candidates;
export const electionResultsTable = electionResults;
export const electionStagesTable = electionStages;
export const electionsTable = elections;
export const materialsTable = materials;
export const notificationsTable = notifications;
export const organizationsTable = organizations;
export const positionsTable = positions;
export const proposalsTable = proposals;
export const rolesTable = roles;
export const rosterTable = roster;
export const stageTemplatesTable = stageTemplates;
export const systemConfigsTable = systemConfigs;
export const votersTable = voters;
