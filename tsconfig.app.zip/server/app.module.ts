import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';
import { DataPaasModule } from '@lark-apaas/nestjs-datapaas';
import * as schema from './database/schema';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { OrganizationModule } from './modules/organization/organization.module';
import { ElectionModule } from './modules/election/election.module';
import { VoterModule } from './modules/voter/voter.module';
import { CandidateModule } from './modules/candidate/candidate.module';
import { MaterialModule } from './modules/material/material.module';
import { ProposalModule } from './modules/proposal/proposal.module';
import { PositionModule } from './modules/position/position.module';
import { AnnouncementModule } from './modules/announcement/announcement.module';
import { ResultModule } from './modules/result/result.module';
import { ArchiveModule } from './modules/archive/archive.module';
import { UserModule } from './modules/user/user.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { LogModule } from './modules/log/log.module';
import { AuthModule } from './modules/auth/auth.module';
import { ConfigModule } from './modules/config/config.module';
import { NotificationModule } from './modules/notification/notification.module';

@Module({
  imports: [
    PlatformModule.forRoot(),
    DataPaasModule.forRoot({
      connectionString: process.env.SUDA_DATABASE_URL ?? '',
      schema,
      ssl: false,
      maxConnections: 7,
    }),
    // ====== @route-section: business-modules START ======
    OrganizationModule,
    ElectionModule,
    VoterModule,
    CandidateModule,
    MaterialModule,
    ProposalModule,
    PositionModule,
    AnnouncementModule,
    ResultModule,
    ArchiveModule,
    UserModule,
    DashboardModule,
    LogModule,
    AuthModule,
    ConfigModule,
    NotificationModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
