import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Query,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { ArchiveService } from './archive.service';
import type {
  Archive,
  ArchiveDetail,
  ArchiveCreateDto,
  ArchiveUpdateDto,
  ArchiveStats,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/archives')
export class ArchiveController {
  constructor(private readonly archiveService: ArchiveService) {}

  @Get('stats')
  async stats(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
  ): Promise<ApiResponse<ArchiveStats>> {
    const data = await this.archiveService.getStats({ orgId, electionId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
    @Query('sourceType') sourceType?: string,
    @Query('visibility') visibility?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Archive>>> {
    const data = await this.archiveService.list({
      orgId,
      electionId,
      sourceType,
      visibility,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async detail(@Param('id') id: string): Promise<ApiResponse<ArchiveDetail>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.archiveService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: ArchiveCreateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.displayName) {
      throw new BadRequestException('归档名称不能为空');
    }
    const data = await this.archiveService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: ArchiveUpdateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.archiveService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    await this.archiveService.remove(id);
    return { code: 0, data: undefined, message: 'success' };
  }
}
