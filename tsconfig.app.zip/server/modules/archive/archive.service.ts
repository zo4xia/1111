import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count, sql } from 'drizzle-orm';
import { archives } from '@server/database/schema';
import type {
  Archive,
  ArchiveDetail,
  ArchiveCreateDto,
  ArchiveUpdateDto,
  ArchiveStats,
  ListResponse,
} from '@shared/api.interface';

@Injectable()
export class ArchiveService {
  private readonly logger = new Logger(ArchiveService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    electionId?: string;
    sourceType?: string;
    visibility?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Archive>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const conditions = this.buildConditions(params);

    const query = conditions.length > 0
      ? this.db.select().from(archives).where(and(...conditions))
      : this.db.select().from(archives);

    const rows = await query
      .orderBy(desc(archives.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(archives).where(and(...conditions))
      : await this.db.select({ count: count() }).from(archives);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Archive[] = rows.map((r) => this.mapArchive(r));

    return { items, total };
  }

  async getById(id: string): Promise<ArchiveDetail> {
    const rows = await this.db.select().from(archives).where(eq(archives.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('归档记录不存在');
    }
    const base = this.mapArchive(rows[0]);
    return { ...base, sourceData: rows[0] as unknown as Record<string, unknown> };
  }

  async create(data: ArchiveCreateDto): Promise<{ id: string }> {
    if (!data.displayName) {
      throw new BadRequestException('归档名称不能为空');
    }
    if (!data.sourceType) {
      throw new BadRequestException('来源类型不能为空');
    }

    const result = await this.db.insert(archives).values({
      orgId: data.orgId || '',
      electionId: data.electionId || '',
      archSourceType: data.sourceType,
      archSourceId: data.sourceId || '',
      archFileVersion: data.fileVersion || 'v1.0',
      archDisplayName: data.displayName,
      archVisibility: data.visibility || 'internal',
    }).returning({ id: archives.id });

    if (result.length === 0) {
      throw new BadRequestException('创建归档失败');
    }

    this.logger.log(`创建归档: ${data.displayName}`);
    return { id: result[0].id };
  }

  async update(
    id: string,
    data: ArchiveUpdateDto,
  ): Promise<{ id: string }> {
    const existing = await this.db.select().from(archives).where(eq(archives.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('归档记录不存在');
    }

    const patch: Partial<typeof archives.$inferInsert> = {};
    if (data.displayName !== undefined) patch.archDisplayName = data.displayName;
    if (data.sourceType !== undefined) patch.archSourceType = data.sourceType;
    if (data.sourceId !== undefined) patch.archSourceId = data.sourceId;
    if (data.fileVersion !== undefined) patch.archFileVersion = data.fileVersion;
    if (data.visibility !== undefined) patch.archVisibility = data.visibility;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db.update(archives)
      .set(patch)
      .where(eq(archives.id, id))
      .returning({ id: archives.id });

    if (result.length === 0) {
      throw new BadRequestException('更新归档失败');
    }

    this.logger.log(`更新归档: ${id}`);
    return { id };
  }

  async remove(id: string): Promise<void> {
    const existing = await this.db.select().from(archives).where(eq(archives.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('归档记录不存在');
    }

    const result = await this.db.delete(archives)
      .where(eq(archives.id, id))
      .returning({ id: archives.id });

    if (result.length === 0) {
      throw new BadRequestException('删除归档失败');
    }

    this.logger.log(`删除归档: ${id}`);
  }

  async getStats(params: {
    orgId?: string;
    electionId?: string;
  }): Promise<ArchiveStats> {
    const conditions = this.buildConditions(params);

    const result = conditions.length > 0
      ? await this.db
          .select({
            total: count(),
            publicCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'public')`,
            internalCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'internal')`,
            privateCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'private')`,
          })
          .from(archives)
          .where(and(...conditions))
      : await this.db
          .select({
            total: count(),
            publicCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'public')`,
            internalCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'internal')`,
            privateCount: sql<number>`count(*) filter (where ${archives.archVisibility} = 'private')`,
          })
          .from(archives);

    const row = result[0];
    return {
      total: Number(row?.total ?? 0),
      publicCount: Number(row?.publicCount ?? 0),
      internalCount: Number(row?.internalCount ?? 0),
      privateCount: Number(row?.privateCount ?? 0),
    };
  }

  private buildConditions(params: {
    orgId?: string;
    electionId?: string;
    sourceType?: string;
    visibility?: string;
  }) {
    const conditions = [];
    if (params.orgId) conditions.push(eq(archives.orgId, params.orgId));
    if (params.electionId) conditions.push(eq(archives.electionId, params.electionId));
    if (params.sourceType) conditions.push(eq(archives.archSourceType, params.sourceType));
    if (params.visibility) conditions.push(eq(archives.archVisibility, params.visibility));
    return conditions;
  }

  private mapArchive(row: typeof archives.$inferSelect): Archive {
    return {
      id: row.id,
      orgId: row.orgId || '',
      electionId: row.electionId || '',
      sourceType: row.archSourceType || '',
      sourceId: row.archSourceId || '',
      displayName: row.archDisplayName || '',
      fileVersion: row.archFileVersion || '',
      visibility: row.archVisibility || 'internal',
    };
  }
}
