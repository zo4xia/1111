import {
  Controller,
  Get,
  Query,
  Param,
  Post,
  Put,
  Delete,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { CandidateService } from './candidate.service';
import type {
  Candidate,
  CandidateDetail,
  CandidateCreateDto,
  CandidateUpdateDto,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/candidates')
export class CandidateController {
  constructor(private readonly candidateService: CandidateService) {}

  @Get()
  async list(
    @Query('electionId') electionId?: string,
    @Query('orgId') orgId?: string,
    @Query('position') position?: string,
    @Query('status') status?: string,
    @Query('round') round?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Candidate>>> {
    const data = await this.candidateService.list({
      electionId,
      orgId,
      position,
      status,
      round: round ? Number(round) : undefined,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(@Body() body: CandidateCreateDto): Promise<ApiResponse<{ id: string }>> {
    if (!body.name) {
      throw new BadRequestException('姓名不能为空');
    }
    if (!body.orgId) {
      throw new BadRequestException('orgId 不能为空');
    }
    if (!body.electionId) {
      throw new BadRequestException('electionId 不能为空');
    }
    const data = await this.candidateService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async getById(@Param('id') id: string): Promise<ApiResponse<CandidateDetail>> {
    const data = await this.candidateService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: CandidateUpdateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.candidateService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    await this.candidateService.remove(id);
    return { code: 0, data: undefined as unknown as void, message: 'success' };
  }

  @Post(':id/review')
  async review(
    @Param('id') id: string,
    @Body() body: { round: number; result: string; comment: string; reviewer: string },
  ): Promise<ApiResponse<{ id: string; round: number; status: string; overallStatus: string }>> {
    if (!body.round || !body.result) {
      throw new BadRequestException('round 和 result 不能为空');
    }
    const data = await this.candidateService.review(
      id,
      body.round,
      body.result,
      body.comment || '',
      body.reviewer || '',
    );
    return { code: 0, data, message: 'success' };
  }
}
