import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, desc, ilike, sql, inArray, asc, or } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { candidates } from '@server/database/schema';
import type {
  Candidate,
  CandidateDetail,
  ListResponse,
} from '@shared/api.interface';

const APPROVED_VALUES = ['approved', '通过', '已通过'];
const REJECTED_VALUES = ['rejected', '不通过', '驳回', '未通过'];
const PENDING_VALUES = ['pending', '待审核', ''];

function isApproved(status: string | null | undefined): boolean {
  if (!status) return false;
  return APPROVED_VALUES.includes(status.toLowerCase());
}

function isRejected(status: string | null | undefined): boolean {
  if (!status) return false;
  return REJECTED_VALUES.includes(status.toLowerCase());
}

function normalizeRoundStatus(status: string | null | undefined): string {
  if (!status) return 'pending';
  const s = status.toLowerCase();
  if (APPROVED_VALUES.includes(s)) return 'approved';
  if (REJECTED_VALUES.includes(s)) return 'rejected';
  if (PENDING_VALUES.includes(s)) return 'pending';
  return status;
}

function calcOverallStatus(
  r1: string | null | undefined,
  r2: string | null | undefined,
  r3: string | null | undefined,
  r4: string | null | undefined,
): string {
  const rounds = [r1, r2, r3, r4];
  if (rounds.some((s) => isRejected(s))) return 'eliminated';
  if (rounds.every((s) => isApproved(s))) return 'passed';
  return 'reviewing';
}

const ROUND_COLUMNS = [
  { status: candidates.candR1, reviewer: candidates.candR1Reviewer, time: candidates.candR1Time, comment: candidates.candR1Comment },
  { status: candidates.candR2, reviewer: candidates.candR2Reviewer, time: candidates.candR2Time, comment: candidates.candR2Comment },
  { status: candidates.candR3, reviewer: candidates.candR3Reviewer, time: candidates.candR3Time, comment: candidates.candR3Comment },
  { status: candidates.candR4, reviewer: candidates.candR4Reviewer, time: candidates.candR4Time, comment: candidates.candR4Comment },
];

type CandidateRow = typeof candidates.$inferSelect;

export interface CandidateStats {
  total: number;
  reviewing: number;
  passed: number;
  eliminated: number;
  byRound: Array<{ round: number; pending: number; approved: number; rejected: number }>;
}

@Injectable()
export class CandidateService {
  private readonly logger = new Logger(CandidateService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    electionId?: string;
    orgId?: string;
    position?: string;
    status?: string;
    round?: number;
    search?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Candidate>> {
    const conditions = this.buildWhereConditions(params);
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const page = params.page && params.page > 0 ? params.page : 1;
    const pageSize =
      params.pageSize && params.pageSize > 0 ? params.pageSize : 50;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: sql<number>`count(*)` })
        .from(candidates)
        .where(where),
      this.db
        .select()
        .from(candidates)
        .where(where)
        .orderBy(asc(candidates.candName), desc(candidates.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Candidate[] = rows.map((row) => this.mapRow(row));

    return { items, total };
  }

  async getById(id: string): Promise<CandidateDetail> {
    const rows = await this.db
      .select()
      .from(candidates)
      .where(eq(candidates.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('候选人记录不存在');
    }

    return this.mapDetailRow(rows[0]);
  }

  async create(
    data: Partial<CandidateDetail> & { orgId: string; electionId: string },
  ): Promise<{ id: string }> {
    if (!data.orgId || !data.electionId) {
      throw new BadRequestException('orgId 和 electionId 不能为空');
    }
    if (!data.name) {
      throw new BadRequestException('姓名不能为空');
    }

    const inserted = await this.db
      .insert(candidates)
      .values({
        orgId: data.orgId,
        electionId: data.electionId,
        candName: data.name,
        candGender: data.gender || '',
        candAge: data.age ?? 0,
        candIdCard: data.idCard || '',
        candPhone: data.phone || '',
        candPositionId: data.position || '',
        candSource: data.source || '',
        candR1: 'pending',
        candR1Reviewer: '',
        candR1Comment: '',
        candR2: 'pending',
        candR2Reviewer: '',
        candR2Comment: '',
        candR3: 'pending',
        candR3Reviewer: '',
        candR3Comment: '',
        candR4: 'pending',
        candR4Reviewer: '',
        candR4Comment: '',
        candStatus: '',
        candVotes: 0,
      })
      .returning({ id: candidates.id });

    if (inserted.length === 0) {
      throw new BadRequestException('创建候选人记录失败');
    }

    return { id: inserted[0].id };
  }

  async update(
    id: string,
    data: Partial<CandidateDetail>,
  ): Promise<{ id: string }> {
    const patch: Partial<typeof candidates.$inferInsert> = {};

    if (data.name !== undefined) patch.candName = data.name;
    if (data.gender !== undefined) patch.candGender = data.gender;
    if (data.age !== undefined) patch.candAge = data.age;
    if (data.idCard !== undefined) patch.candIdCard = data.idCard;
    if (data.phone !== undefined) patch.candPhone = data.phone;
    if (data.position !== undefined) patch.candPositionId = data.position;
    if (data.source !== undefined) patch.candSource = data.source;
    if (data.votes !== undefined) patch.candVotes = data.votes;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(candidates)
      .set(patch)
      .where(eq(candidates.id, id))
      .returning({ id: candidates.id });

    if (updated.length === 0) {
      throw new NotFoundException('候选人记录不存在');
    }

    return { id };
  }

  async review(
    id: string,
    round: number,
    result: string,
    comment: string,
    reviewer: string,
  ): Promise<{ id: string; round: number; status: string; overallStatus: string }> {
    if (round < 1 || round > 4) {
      throw new BadRequestException('轮次必须在 1-4 之间');
    }
    if (!result) {
      throw new BadRequestException('审核结果不能为空');
    }

    const existing = await this.getById(id);
    const roundCols = ROUND_COLUMNS[round - 1];

    // 前置轮次校验
    for (let i = 0; i < round - 1; i += 1) {
      const prevCol = ROUND_COLUMNS[i];
      const prevStatus = (existing as unknown as Record<string, string>)[`r${i + 1}Status`];
      if (!isApproved(prevStatus)) {
        throw new BadRequestException(
          `第${i + 1}轮审核未通过，无法进行第${round}轮审核`,
        );
      }
    }

    const nowStr = new Date().toISOString();
    const normalizedResult = normalizeRoundStatus(result);

    // 计算新的总体状态
    const roundStatuses: Array<string | null | undefined> = [
      existing.r1Status,
      existing.r2Status,
      existing.r3Status,
      existing.r4Status,
    ];
    roundStatuses[round - 1] = normalizedResult;
    const overallStatus = calcOverallStatus(
      roundStatuses[0],
      roundStatuses[1],
      roundStatuses[2],
      roundStatuses[3],
    );

    await this.db
      .update(candidates)
      .set({
        [roundCols.status.name]: normalizedResult,
        [roundCols.reviewer.name]: reviewer,
        [roundCols.time.name]: nowStr,
        [roundCols.comment.name]: comment,
        candStatus: overallStatus,
      })
      .where(eq(candidates.id, id));

    this.logger.log(
      `候选人审核: id=${id}, round=${round}, result=${normalizedResult}, reviewer=${reviewer}`,
    );

    return {
      id,
      round,
      status: normalizedResult,
      overallStatus,
    };
  }

  async updateReviewRound(
    id: string,
    round: number,
    status: string,
    reviewer: string,
    comment: string,
  ): Promise<{ id: string; round: number; status: string; overallStatus: string }> {
    return this.review(id, round, status, comment, reviewer);
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(candidates)
      .where(eq(candidates.id, id))
      .returning({ id: candidates.id });

    if (deleted.length === 0) {
      throw new NotFoundException('候选人记录不存在');
    }

    return { success: true };
  }

  async batchUpdateStatus(
    ids: string[],
    status: string,
  ): Promise<{ updated: number }> {
    if (!ids || ids.length === 0) {
      throw new BadRequestException('ids 不能为空');
    }
    if (!status) {
      throw new BadRequestException('status 不能为空');
    }

    const result = await this.db
      .update(candidates)
      .set({ candStatus: status })
      .where(inArray(candidates.id, ids))
      .returning({ id: candidates.id });

    return { updated: result.length };
  }

  async getStats(params: {
    electionId: string;
    orgId?: string;
  }): Promise<CandidateStats> {
    const conditions = [];
    if (params.electionId) {
      conditions.push(eq(candidates.electionId, params.electionId));
    }
    if (params.orgId) {
      conditions.push(eq(candidates.orgId, params.orgId));
    }
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [aggResult, roundRows] = await Promise.all([
      this.db
        .select({
          total: sql<number>`count(*)`,
          reviewing: sql<number>`count(*) filter (where ${candidates.candStatus} = 'reviewing')`,
          passed: sql<number>`count(*) filter (where ${candidates.candStatus} = 'passed')`,
          eliminated: sql<number>`count(*) filter (where ${candidates.candStatus} = 'eliminated')`,
        })
        .from(candidates)
        .where(where),
      this.db
        .select({
          r1Approved: sql<number>`count(*) filter (where ${candidates.candR1} = 'approved')`,
          r1Rejected: sql<number>`count(*) filter (where ${candidates.candR1} = 'rejected')`,
          r1Pending: sql<number>`count(*) filter (where ${candidates.candR1} is null or ${candidates.candR1} = '' or ${candidates.candR1} = 'pending')`,
          r2Approved: sql<number>`count(*) filter (where ${candidates.candR2} = 'approved')`,
          r2Rejected: sql<number>`count(*) filter (where ${candidates.candR2} = 'rejected')`,
          r2Pending: sql<number>`count(*) filter (where ${candidates.candR2} is null or ${candidates.candR2} = '' or ${candidates.candR2} = 'pending')`,
          r3Approved: sql<number>`count(*) filter (where ${candidates.candR3} = 'approved')`,
          r3Rejected: sql<number>`count(*) filter (where ${candidates.candR3} = 'rejected')`,
          r3Pending: sql<number>`count(*) filter (where ${candidates.candR3} is null or ${candidates.candR3} = '' or ${candidates.candR3} = 'pending')`,
          r4Approved: sql<number>`count(*) filter (where ${candidates.candR4} = 'approved')`,
          r4Rejected: sql<number>`count(*) filter (where ${candidates.candR4} = 'rejected')`,
          r4Pending: sql<number>`count(*) filter (where ${candidates.candR4} is null or ${candidates.candR4} = '' or ${candidates.candR4} = 'pending')`,
        })
        .from(candidates)
        .where(where),
    ]);

    const agg = aggResult[0] ?? {
      total: 0,
      reviewing: 0,
      passed: 0,
      eliminated: 0,
    };

    const r = roundRows[0];
    const byRound = r
      ? [
          { round: 1, pending: Number(r.r1Pending), approved: Number(r.r1Approved), rejected: Number(r.r1Rejected) },
          { round: 2, pending: Number(r.r2Pending), approved: Number(r.r2Approved), rejected: Number(r.r2Rejected) },
          { round: 3, pending: Number(r.r3Pending), approved: Number(r.r3Approved), rejected: Number(r.r3Rejected) },
          { round: 4, pending: Number(r.r4Pending), approved: Number(r.r4Approved), rejected: Number(r.r4Rejected) },
        ]
      : [
          { round: 1, pending: 0, approved: 0, rejected: 0 },
          { round: 2, pending: 0, approved: 0, rejected: 0 },
          { round: 3, pending: 0, approved: 0, rejected: 0 },
          { round: 4, pending: 0, approved: 0, rejected: 0 },
        ];

    return {
      total: Number(agg.total),
      reviewing: Number(agg.reviewing),
      passed: Number(agg.passed),
      eliminated: Number(agg.eliminated),
      byRound,
    };
  }

  private buildWhereConditions(params: {
    electionId?: string;
    orgId?: string;
    position?: string;
    status?: string;
    round?: number;
    search?: string;
  }): Array<ReturnType<typeof eq> | ReturnType<typeof and> | ReturnType<typeof ilike>> {
    const conditions: Array<ReturnType<typeof eq> | ReturnType<typeof and> | ReturnType<typeof ilike>> = [];

    if (params.orgId) {
      conditions.push(eq(candidates.orgId, params.orgId));
    }
    if (params.electionId) {
      conditions.push(eq(candidates.electionId, params.electionId));
    }
    if (params.position) {
      conditions.push(eq(candidates.candPositionId, params.position));
    }
    if (params.search) {
      conditions.push(
        or(
          ilike(candidates.candName, `%${params.search}%`),
          ilike(candidates.candIdCard, `%${params.search}%`),
          ilike(candidates.candPhone, `%${params.search}%`),
        ),
      );
    }
    if (params.status) {
      conditions.push(eq(candidates.candStatus, params.status));
    }
    if (params.round && params.round >= 1 && params.round <= 4) {
      const roundCol = ROUND_COLUMNS[params.round - 1].status;
      conditions.push(
        and(
          sql`${roundCol} is not null`,
          sql`${roundCol} <> ''`,
          sql`${roundCol} <> 'approved'`,
        ),
      );
    }

    return conditions;
  }

  private mapRow(row: CandidateRow): Candidate {
    const r1Status = normalizeRoundStatus(row.candR1);
    const r2Status = normalizeRoundStatus(row.candR2);
    const r3Status = normalizeRoundStatus(row.candR3);
    const r4Status = normalizeRoundStatus(row.candR4);

    return {
      id: row.id,
      orgId: row.orgId,
      electionId: row.electionId,
      name: row.candName || '',
      gender: row.candGender || '',
      age: row.candAge ?? 0,
      position: row.candPositionId || '',
      source: row.candSource || '',
      r1Status,
      r2Status,
      r3Status,
      r4Status,
      status: row.candStatus || calcOverallStatus(r1Status, r2Status, r3Status, r4Status),
      votes: row.candVotes ?? 0,
    };
  }

  private mapDetailRow(row: CandidateRow): CandidateDetail {
    const base = this.mapRow(row);
    return {
      ...base,
      idCard: row.candIdCard || '',
      phone: row.candPhone || '',
      r1Reviewer: row.candR1Reviewer || undefined,
      r1Time: row.candR1Time || undefined,
      r1Comment: row.candR1Comment || undefined,
      r2Reviewer: row.candR2Reviewer || undefined,
      r2Time: row.candR2Time || undefined,
      r2Comment: row.candR2Comment || undefined,
      r3Reviewer: row.candR3Reviewer || undefined,
      r3Time: row.candR3Time || undefined,
      r3Comment: row.candR3Comment || undefined,
      r4Reviewer: row.candR4Reviewer || undefined,
      r4Time: row.candR4Time || undefined,
      r4Comment: row.candR4Comment || undefined,
    };
  }
}
