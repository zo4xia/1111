import {
  BadRequestException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { eq, and, asc, count, or } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { organizations } from '@server/database/schema';
import type { Organization, ListResponse } from '@shared/api.interface';

interface ListParams {
  type?: string;
  town?: string;
  parentId?: string;
  page?: number;
  pageSize?: number;
}

@Injectable()
export class OrganizationService {
  private readonly logger = new Logger(OrganizationService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: ListParams = {}): Promise<ListResponse<Organization>> {
    const conditions = this.buildConditions(params);
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 100;

    const [totalResult, rows] = await Promise.all([
      this.db.select({ count: count() }).from(organizations).where(where),
      this.db
        .select()
        .from(organizations)
        .where(where)
        .orderBy(asc(organizations.slug))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Organization[] = rows.map((row) => this.mapRow(row));

    return { items, total };
  }

  async getById(id: string): Promise<Organization> {
    // 兼容 slug 和 uuid 两种查询方式
    const rows = await this.db
      .select()
      .from(organizations)
      .where(or(eq(organizations.id, id), eq(organizations.slug, id)))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('组织不存在');
    }

    return this.mapRow(rows[0]);
  }

  async create(
    data: Omit<Organization, 'id'> & {
      orgPhone?: string;
      orgPerson?: string;
      orgNote?: string;
    },
  ): Promise<{ id: string }> {
    if (!data.slug) {
      throw new BadRequestException('slug 不能为空');
    }
    if (!data.name) {
      throw new BadRequestException('名称不能为空');
    }

    const result = await this.db
      .insert(organizations)
      .values({
        slug: data.slug,
        name: data.name,
        town: data.town || '',
        type: data.type || '',
        status: data.status || 'active',
        orgPhone: data.orgPhone || '',
        orgPerson: data.orgPerson || '',
        orgNote: data.orgNote || '',
      })
      .returning({ id: organizations.id });

    if (result.length === 0) {
      throw new BadRequestException('创建组织失败');
    }

    this.logger.log(`创建组织: ${data.slug} - ${data.name}`);
    return { id: result[0].id };
  }

  async update(
    id: string,
    data: Partial<Organization> & {
      orgPhone?: string;
      orgPerson?: string;
      orgNote?: string;
    },
  ): Promise<{ id: string }> {
    const patch: Partial<typeof organizations.$inferInsert> = {};

    if (data.slug !== undefined) patch.slug = data.slug;
    if (data.name !== undefined) patch.name = data.name;
    if (data.town !== undefined) patch.town = data.town;
    if (data.type !== undefined) patch.type = data.type;
    if (data.status !== undefined) patch.status = data.status;
    if (data.orgPhone !== undefined) patch.orgPhone = data.orgPhone;
    if (data.orgPerson !== undefined) patch.orgPerson = data.orgPerson;
    if (data.orgNote !== undefined) patch.orgNote = data.orgNote;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db
      .update(organizations)
      .set(patch)
      .where(eq(organizations.id, id))
      .returning({ id: organizations.id });

    if (result.length === 0) {
      throw new NotFoundException('组织不存在');
    }

    this.logger.log(`更新组织: ${id}`);
    return { id };
  }

  async remove(id: string): Promise<{ id: string }> {
    const result = await this.db
      .delete(organizations)
      .where(eq(organizations.id, id))
      .returning({ id: organizations.id });

    if (result.length === 0) {
      throw new NotFoundException('组织不存在或删除失败');
    }

    this.logger.log(`删除组织: ${id}`);
    return { id };
  }

  private buildConditions(params: ListParams) {
    const conditions = [];
    if (params.type) conditions.push(eq(organizations.type, params.type));
    if (params.town) conditions.push(eq(organizations.town, params.town));
    return conditions;
  }

  private mapRow(row: typeof organizations.$inferSelect): Organization {
    return {
      id: row.id,
      slug: row.slug,
      name: row.name,
      town: row.town || '',
      type: (row.type as Organization['type']) || 'community_committee',
      status: row.status || 'active',
    };
  }
}
