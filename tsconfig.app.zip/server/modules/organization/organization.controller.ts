import { Controller, Get } from '@nestjs/common';
import { OrganizationService } from './organization.service';
import type { Organization, ListResponse, ApiResponse } from '@shared/api.interface';

@Controller('api/organizations')
export class OrganizationController {
  constructor(private readonly organizationService: OrganizationService) {}

  @Get()
  async list(): Promise<ApiResponse<ListResponse<Organization>>> {
     const data = await this.organizationService.list();
     return { code: 0, data, message: 'success' };
   }
}
