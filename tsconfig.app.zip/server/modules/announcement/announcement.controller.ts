import {
  Controller,
  Get,
  Query,
  Param,
  Post,
  Put,
  Patch,
  Delete,
  Body,
  NotFoundException,
} from '@nestjs/common';
import { AnnouncementService } from './announcement.service';
import type { ApiResponse } from '@shared/api.interface';
import type {
  Announcement,
  AnnouncementDetail,
  AnnouncementStatus,
  AnnouncementTemplate,
  ListResponse,
} from '@shared/api.interface';

@Controller('api/announcements')
export class AnnouncementController {
  constructor(private readonly announcementService: AnnouncementService) {}

  // ========================= 公告 CRUD =========================

  @Get()
  async list(
    @Query('electionId') electionId?: string,
    @Query('orgId') orgId?: string,
    @Query('code') code?: string,
    @Query('status') status?: string,
    @Query('stageKey') stageKey?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Announcement>>> {
    const data = await this.announcementService.list({
      electionId,
      orgId,
      code,
      status,
      stageKey,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  // ========================= 公告模板 =========================

  // 静态路由必须在动态 :id 路由之前声明
  @Get('templates/list')
  async listTemplates(
    @Query('name') name?: string,
    @Query('code') code?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<AnnouncementTemplate>>> {
    const data = await this.announcementService.listTemplates({
      name,
      code,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get('templates/:id')
  async getTemplateById(
    @Param('id') id: string,
  ): Promise<ApiResponse<AnnouncementTemplate>> {
    const data = await this.announcementService.getTemplateById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post('templates/:id/use')
  async useTemplate(
    @Param('id') id: string,
    @Body()
    body: {
      electionId: string;
      orgId: string;
    },
  ): Promise<ApiResponse<AnnouncementDetail>> {
    const base = await this.announcementService.createFromTemplate(
      id,
      body.electionId,
      body.orgId,
    );
    const data = await this.announcementService.getById(base.id);
    return { code: 0, data, message: 'success' };
  }

  // ========================= 公告详情/更新 =========================

  @Get(':id')
  async getById(
    @Param('id') id: string,
  ): Promise<ApiResponse<AnnouncementDetail>> {
    const data = await this.announcementService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body()
    body: {
      title?: string;
      content?: string;
      publicityDeadline?: string;
    },
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    const data = await this.announcementService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    if (!id) {
      throw new NotFoundException('id 不能为空');
    }
    await this.announcementService.remove(id);
    return { code: 0, data: undefined, message: 'success' };
  }

  // ========================= 状态流转 =========================

  @Patch(':id/submit')
  async submitReview(
    @Param('id') id: string,
    @Body() body: { editor?: string },
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.submitReview(id, body.editor);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/approve')
  async approve(
    @Param('id') id: string,
    @Body() body: { reviewer?: string; comment?: string },
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.approve(
      id,
      body.reviewer,
      body.comment,
    );
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/reject')
  async reject(
    @Param('id') id: string,
    @Body() body: { reviewer?: string; comment: string },
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.reject(
      id,
      body.reviewer,
      body.comment,
    );
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/publish')
  async publish(
    @Param('id') id: string,
    @Body() body: { reviewer?: string },
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.publish(id, body.reviewer);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/freeze')
  async freeze(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.freeze(id);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/unfreeze')
  async unfreeze(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ id: string; status: AnnouncementStatus }>> {
    const data = await this.announcementService.unfreeze(id);
    return { code: 0, data, message: 'success' };
  }
}
