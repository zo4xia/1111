import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, desc, asc, like, count } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import {
  announcements,
  announcementTemplates,
} from '@server/database/schema';
import type {
  Announcement,
  AnnouncementDetail,
  AnnouncementStatus,
  AnnouncementTemplate,
  ListResponse,
} from '@shared/api.interface';

const VALID_STATUSES: AnnouncementStatus[] = [
  'draft',
  'pending_publish',
  'published',
  'correction',
  'frozen',
];

interface ListParams {
  electionId?: string;
  orgId?: string;
  code?: string;
  status?: string;
  stageKey?: string;
  page?: number;
  pageSize?: number;
}

@Injectable()
export class AnnouncementService {
  private readonly logger = new Logger(AnnouncementService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: ListParams): Promise<ListResponse<Announcement>> {
    const conditions = [];
    if (params.orgId) conditions.push(eq(announcements.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(announcements.electionId, params.electionId));
    if (params.code)
      conditions.push(like(announcements.annCode, `%${params.code}%`));
    if (params.stageKey)
      conditions.push(eq(announcements.annStageKey, params.stageKey));
    if (params.status)
      conditions.push(eq(announcements.annStatus, params.status));

    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const page = params.page && params.page > 0 ? params.page : 1;
    const pageSize =
      params.pageSize && params.pageSize > 0 ? params.pageSize : 20;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(announcements)
        .where(where),
      this.db
        .select()
        .from(announcements)
        .where(where)
        .orderBy(desc(announcements.annCode))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Announcement[] = rows.map((r) => ({
      id: r.id,
      orgId: r.orgId,
      electionId: r.electionId || '',
      code: r.annCode || '',
      title: r.annTitle || '',
      stageKey: r.annStageKey || '',
      status: (r.annStatus as AnnouncementStatus) || 'draft',
      version: r.annVersion || 1,
      editor: r.annEditor || '',
      publishTime: r.annPublishTime || '',
    }));

    return { items, total };
  }

  async getById(id: string): Promise<AnnouncementDetail> {
    const rows = await this.db
      .select()
      .from(announcements)
      .where(eq(announcements.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('公告不存在');
    }
    const r = rows[0];
    return {
      id: r.id,
      orgId: r.orgId,
      electionId: r.electionId || '',
      code: r.annCode || '',
      title: r.annTitle || '',
      stageKey: r.annStageKey || '',
      status: (r.annStatus as AnnouncementStatus) || 'draft',
      version: r.annVersion || 1,
      editor: r.annEditor || '',
      publishTime: r.annPublishTime || '',
      content: r.annContent || '',
      reviewer: r.annReviewer || '',
      editTime: r.annEditTime || '',
      reviewTime: r.annReviewTime || '',
      reviewComment: '',
      publicityDeadline: r.annPublicityDeadline || '',
    };
  }

  async listTemplates(params: {
    name?: string;
    code?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<AnnouncementTemplate>> {
    const conditions = [];
    if (params.name)
      conditions.push(like(announcementTemplates.atName, `%${params.name}%`));
    if (params.code)
      conditions.push(like(announcementTemplates.atCode, `%${params.code}%`));

    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const page = params.page && params.page > 0 ? params.page : 1;
    const pageSize =
      params.pageSize && params.pageSize > 0 ? params.pageSize : 50;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(announcementTemplates)
        .where(where),
      this.db
        .select()
        .from(announcementTemplates)
        .where(where)
        .orderBy(asc(announcementTemplates.atCode))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: AnnouncementTemplate[] = rows.map((r) => ({
      id: r.id,
      code: r.atCode || '',
      name: r.atName || '',
      version: r.atVersion || '',
      content: r.atContent || '',
      needRemind: !!r.atNeedRemind,
      note: r.atNote || '',
    }));

    return { items, total };
  }

  async getTemplateById(id: string): Promise<AnnouncementTemplate> {
    const rows = await this.db
      .select()
      .from(announcementTemplates)
      .where(eq(announcementTemplates.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('公告模板不存在');
    }
    const r = rows[0];
    return {
      id: r.id,
      code: r.atCode || '',
      name: r.atName || '',
      version: r.atVersion || '',
      content: r.atContent || '',
      needRemind: !!r.atNeedRemind,
      note: r.atNote || '',
    };
  }

  async createFromTemplate(
    templateId: string,
    electionId: string,
    orgId: string,
  ): Promise<AnnouncementDetail> {
    if (!electionId || !orgId) {
      throw new BadRequestException('electionId 和 orgId 不能为空');
    }

    const tpl = await this.getTemplateById(templateId);

    const countResult = await this.db
      .select({ count: count() })
      .from(announcements)
      .where(
        and(
          eq(announcements.orgId, orgId),
          eq(announcements.electionId, electionId),
        ),
      );
    const nextNum = Number(countResult[0]?.count ?? 0) + 1;
    const code = `第${nextNum}号`;
    const now = new Date().toISOString();

    const inserted = await this.db
      .insert(announcements)
      .values({
        orgId,
        electionId,
        annCode: code,
        annTitle: tpl.name || `${code} 公告`,
        annContent: tpl.content || '',
        annStageKey: '',
        annStatus: 'draft',
        annVersion: 1,
        annEditor: '',
        annEditTime: now,
        annReviewer: '',
        annReviewTime: null,
        annPublishTime: null,
        annPublicityDeadline: null,
      })
      .returning({ id: announcements.id });

    const newId = inserted[0]?.id;
    if (!newId) throw new BadRequestException('创建公告失败');
    return this.getById(newId);
  }

  async update(
    id: string,
    data: {
      title?: string;
      content?: string;
      publicityDeadline?: string;
    },
  ): Promise<{ id: string; status: string }> {
    if (
      data.title === undefined &&
      data.content === undefined &&
      data.publicityDeadline === undefined
    ) {
      throw new BadRequestException('未提供可更新字段');
    }

    const patch: Partial<typeof announcements.$inferInsert> = {};
    if (data.title !== undefined) patch.annTitle = data.title;
    if (data.content !== undefined) patch.annContent = data.content;
    if (data.publicityDeadline !== undefined)
      patch.annPublicityDeadline = data.publicityDeadline || null;
    patch.annEditTime = new Date().toISOString();

    const updated = await this.db
      .update(announcements)
      .set(patch)
      .where(eq(announcements.id, id))
      .returning({ id: announcements.id, status: announcements.annStatus });

    if (updated.length === 0) {
      throw new NotFoundException('公告不存在');
    }
    return { id: updated[0].id, status: updated[0].status || 'draft' };
  }

  private async setStatus(
    id: string,
    targetStatus: AnnouncementStatus,
    patch: Partial<typeof announcements.$inferInsert> = {},
  ): Promise<{ id: string; status: AnnouncementStatus }> {
    if (!VALID_STATUSES.includes(targetStatus)) {
      throw new BadRequestException(`无效的状态值: ${targetStatus}`);
    }
    const updated = await this.db
      .update(announcements)
      .set({ annStatus: targetStatus, ...patch })
      .where(eq(announcements.id, id))
      .returning({ id: announcements.id });
    if (updated.length === 0) {
      throw new NotFoundException('公告不存在');
    }
    return { id, status: targetStatus };
  }

  async submitReview(
    id: string,
    editor?: string,
  ): Promise<{ id: string; status: AnnouncementStatus }> {
    const current = await this.getById(id);
    if (current.status !== 'draft') {
      throw new BadRequestException('只有草稿状态的公告才能提交审核');
    }
    const now = new Date().toISOString();
    return this.setStatus(id, 'pending_publish', {
      annVersion: (current.version || 1) + 1,
      annEditor: editor || current.editor,
      annEditTime: now,
    });
  }

  async approve(
    id: string,
    reviewer?: string,
    comment?: string,
  ): Promise<{ id: string; status: AnnouncementStatus }> {
    const current = await this.getById(id);
    if (current.status !== 'pending_publish') {
      throw new BadRequestException('只有待审核状态的公告才能审批通过');
    }
    return this.setStatus(id, 'published', {
      annReviewer: reviewer || '',
      annReviewTime: new Date().toISOString(),
      annPublishTime: new Date().toISOString(),
    });
  }

  async reject(
    id: string,
    reviewer?: string,
    comment?: string,
  ): Promise<{ id: string; status: AnnouncementStatus }> {
    const current = await this.getById(id);
    if (current.status !== 'pending_publish') {
      throw new BadRequestException('只有待审核状态的公告才能驳回');
    }
    return this.setStatus(id, 'draft', {
      annReviewer: reviewer || '',
      annReviewTime: new Date().toISOString(),
    });
  }

  async publish(
    id: string,
    reviewer?: string,
  ): Promise<{ id: string; status: AnnouncementStatus }> {
    return this.setStatus(id, 'published', {
      annReviewer: reviewer || '',
      annPublishTime: new Date().toISOString(),
    });
  }

  async freeze(id: string): Promise<{ id: string; status: AnnouncementStatus }> {
    return this.setStatus(id, 'frozen');
  }

  async unfreeze(id: string): Promise<{ id: string; status: AnnouncementStatus }> {
    const current = await this.getById(id);
    if (current.status !== 'frozen') {
      throw new BadRequestException('只有已冻结的公告才能解冻');
    }
    return this.setStatus(id, 'published');
  }

  async remove(id: string): Promise<void> {
    const deleted = await this.db
      .delete(announcements)
      .where(eq(announcements.id, id))
      .returning({ id: announcements.id });
    if (deleted.length === 0) {
      throw new NotFoundException('公告不存在');
    }
  }

  async getStats(params: {
    orgId?: string;
    electionId?: string;
  }): Promise<Record<string, number>> {
    const conditions = [];
    if (params.orgId) conditions.push(eq(announcements.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(announcements.electionId, params.electionId));
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const rows = await this.db
      .select({ status: announcements.annStatus, count: count() })
      .from(announcements)
      .where(where)
      .groupBy(announcements.annStatus);

    const stats: Record<string, number> = {
      total: 0,
      draft: 0,
      pending_publish: 0,
      published: 0,
      correction: 0,
      frozen: 0,
    };
    for (const r of rows) {
      const s = r.status || 'draft';
      const c = Number(r.count);
      stats[s] = c;
      stats.total += c;
    }
    return stats;
  }
}
