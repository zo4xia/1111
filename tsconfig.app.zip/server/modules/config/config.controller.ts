import {
  Controller,
  Get,
  Put,
  Patch,
  Param,
  Body,
  Req,
  BadRequestException,
  Post,
  HttpCode,
  HttpStatus,
  Inject,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { sql } from 'drizzle-orm';
import { ConfigService } from './config.service';
import type { Request } from 'express';
import type {
  SystemConfig,
  SystemInfo,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/config')
export class ConfigController {
  constructor(
    private readonly configService: ConfigService,
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ===== System Config =====

  @NeedLogin()
  @Get('system')
  async getSystemConfig(): Promise<ApiResponse<SystemConfig>> {
    const data = await this.configService.getSystemConfigMasked();
    return { code: 0, data, message: 'success' };
  }

  @NeedLogin()
  @Put('system')
  async saveSystemConfig(
    @Body() body: Partial<SystemConfig>,
  ): Promise<ApiResponse<SystemConfig>> {
    const updates: Record<string, string> = {};
    if (body.smsAppId !== undefined) updates.smsAppId = body.smsAppId;
    if (body.smsAppKey !== undefined) updates.smsAppKey = body.smsAppKey;
    if (body.appName !== undefined) updates.appName = body.appName;
    if (body.mcpServerUrl !== undefined) updates.mcpServerUrl = body.mcpServerUrl;
    if (body.mcpServerKey !== undefined) updates.mcpServerKey = body.mcpServerKey;

    await this.configService.updateBatch(updates);
    const data = await this.configService.getSystemConfigMasked();
    return { code: 0, data, message: '保存成功' };
  }

  @NeedLogin()
  @Get('info')
  async getSystemInfo(@Req() req: Request & { userContext: {
    userId: string;
    userName: string;
    env: 'preview' | 'runtime';
  } }): Promise<ApiResponse<SystemInfo>> {
    const { userContext } = req;
    const data: SystemInfo = {
      appName: process.env.APP_NAME ?? '选举管理系统',
      appVersion: process.env.APP_VERSION ?? '1.0.0',
      environment: userContext.env === 'runtime' ? 'production' : 'preview',
      currentUser: userContext.userName ?? userContext.userId,
    };
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async getAll(): Promise<ApiResponse<Record<string, string>>> {
    const data = await this.configService.getAll();
    return { code: 0, data, message: 'success' };
  }

  @Get(':key')
  async getByKey(@Param('key') key: string): Promise<ApiResponse<string | null>> {
    if (!key) {
      throw new BadRequestException('key 不能为空');
    }
    const data = await this.configService.getByKey(key);
    return { code: 0, data, message: 'success' };
  }

  @Put(':key')
  async updateByKey(
    @Param('key') key: string,
    @Body() body: { value: string },
  ): Promise<ApiResponse<{ key: string }>> {
    if (!key) {
      throw new BadRequestException('key 不能为空');
    }
    const data = await this.configService.updateByKey(key, body.value ?? '');
    return { code: 0, data, message: 'success' };
  }

  @Patch('batch')
  async updateBatch(
    @Body() body: Record<string, string>,
  ): Promise<ApiResponse<{ updated: number }>> {
    const data = await this.configService.updateBatch(body || {});
    return { code: 0, data, message: 'success' };
  }

  @NeedLogin()
  @Post('system/test-connection')
  @HttpCode(HttpStatus.OK)
  async testConnection(
    @Body() body: { type: 'sms' | 'postgres' },
  ): Promise<ApiResponse<{ ok: boolean; message: string; details?: string }>> {
    const { type } = body;
    if (!type) {
      throw new BadRequestException('连接类型不能为空');
    }

    if (type === 'postgres') {
      try {
        const result = await this.db.execute(sql`SELECT 1 as ping`);
        const row = (result as unknown as { rows?: Array<{ ping: number }> })?.rows?.[0];
        const ok = row?.ping === 1;
        return {
          code: 0,
          data: {
            ok,
            message: ok ? 'PostgreSQL 连接正常' : 'PostgreSQL 连接异常',
          },
          message: 'success',
        };
      } catch (err) {
        return {
          code: 0,
          data: {
            ok: false,
            message: 'PostgreSQL 连接失败',
            details: (err as Error).message,
          },
          message: 'success',
        };
      }
    }

    if (type === 'sms') {
      const config = await this.configService.getSystemConfig();
      const hasAppId = !!config.smsAppId;
      const hasKey = !!config.smsAppKey;
      if (!hasAppId || !hasKey) {
        return {
          code: 0,
          data: {
            ok: false,
            message: '短信配置不完整：请先填写短信 App ID 和 App Key',
          },
          message: 'success',
        };
      }
      return {
        code: 0,
        data: {
          ok: true,
          message: '短信服务配置已填写（待真实服务商接口验证）',
        },
        message: 'success',
      };
    }

    throw new BadRequestException('不支持的连接类型');
  }
}
