import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count } from 'drizzle-orm';
import { systemConfigs, accounts, roles, organizations, accountRoles } from '@server/database/schema';
import type {
  SystemConfig,
  Account,
  Role,
  RoleKey,
  ListResponse,
} from '@shared/api.interface';

const SECRET_MASK = '********';

@Injectable()
export class ConfigService {
  private readonly logger = new Logger(ConfigService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ===== System Configs =====

  async getAll(): Promise<Record<string, string>> {
    const rows = await this.db.select().from(systemConfigs);
    const result: Record<string, string> = {};
    for (const row of rows) {
      if (row.configKey && row.configValue !== undefined) {
        result[row.configKey] = row.configValue || '';
      }
    }
    return result;
  }

  async getSystemConfig(): Promise<SystemConfig> {
    const config = await this.getAll();
    return {
      smsAppId: config.smsAppId || '',
      smsAppKey: config.smsAppKey || '',
      appName: config.appName || '选举管理系统',
      mcpServerUrl: config.mcpServerUrl || '',
      mcpServerKey: config.mcpServerKey || '',
    };
  }

  async getSystemConfigMasked(): Promise<SystemConfig> {
    const config = await this.getSystemConfig();
    return {
      ...config,
      smsAppKey: config.smsAppKey ? SECRET_MASK : '',
      mcpServerKey: config.mcpServerKey ? SECRET_MASK : '',
    };
  }

  async getByKey(key: string): Promise<string | null> {
    const rows = await this.db.select().from(systemConfigs).where(eq(systemConfigs.configKey, key));
    return rows.length > 0 ? (rows[0].configValue ?? null) : null;
  }

  async updateByKey(key: string, value: string): Promise<{ key: string }> {
    if (!key) {
      throw new BadRequestException('配置键不能为空');
    }

    const existing = await this.db.select().from(systemConfigs).where(eq(systemConfigs.configKey, key));

    if (existing.length > 0) {
      const result = await this.db.update(systemConfigs)
        .set({ configValue: value })
        .where(eq(systemConfigs.configKey, key))
        .returning({ configKey: systemConfigs.configKey });
      if (result.length === 0) {
        throw new BadRequestException('更新配置失败');
      }
    } else {
      const result = await this.db.insert(systemConfigs).values({
        configKey: key,
        configValue: value,
      }).returning({ configKey: systemConfigs.configKey });
      if (result.length === 0) {
        throw new BadRequestException('创建配置失败');
      }
    }

    this.logger.log(`更新配置: ${key}`);
    return { key };
  }

  async updateBatch(updates: Record<string, string>): Promise<{ updated: number }> {
    if (!updates || Object.keys(updates).length === 0) {
      throw new BadRequestException('未提供可更新配置');
    }

    const realUpdates: Record<string, string> = {};
    const current = await this.getAll();

    for (const [key, value] of Object.entries(updates)) {
      // 跳过掩码值
      if (value === SECRET_MASK) continue;
      realUpdates[key] = value;
    }

    if (Object.keys(realUpdates).length === 0) {
      return { updated: 0 };
    }

    for (const [key, value] of Object.entries(realUpdates)) {
      if (current[key] !== undefined) {
        await this.db.update(systemConfigs)
          .set({ configValue: value })
          .where(eq(systemConfigs.configKey, key));
      } else {
        await this.db.insert(systemConfigs).values({
          configKey: key,
          configValue: value,
        });
      }
    }

    this.logger.log(`批量更新配置: ${Object.keys(realUpdates).length} 项`);
    return { updated: Object.keys(realUpdates).length };
  }

  // ===== Accounts =====

  async listAccounts(params: {
    orgId?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Account>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const conditions = [];
    if (params.orgId) conditions.push(eq(accounts.orgId, params.orgId));
    if (params.status) conditions.push(eq(accounts.accStatus, params.status));

    const baseQuery = conditions.length > 0
      ? this.db
          .select({
            account: accounts,
            orgName: organizations.name,
            roleKey: accountRoles.roleKey,
          })
          .from(accounts)
          .leftJoin(organizations, eq(accounts.orgId, organizations.slug))
          .leftJoin(accountRoles, eq(accounts.id, accountRoles.accId))
          .where(and(...conditions))
      : this.db
          .select({
            account: accounts,
            orgName: organizations.name,
            roleKey: accountRoles.roleKey,
          })
          .from(accounts)
          .leftJoin(organizations, eq(accounts.orgId, organizations.slug))
          .leftJoin(accountRoles, eq(accounts.id, accountRoles.accId));

    const rows = await baseQuery
      .orderBy(desc(accounts.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(accounts).where(and(...conditions))
      : await this.db.select({ count: count() }).from(accounts);

    const total = Number(totalResult[0]?.count ?? 0);

    // 合并同一账号的多个角色
    const accountMap = new Map<string, Account & { roles: Set<string> }>();
    for (const row of rows) {
      const acc = row.account;
      if (!accountMap.has(acc.id)) {
        accountMap.set(acc.id, {
          id: acc.id,
          orgId: acc.orgId || '',
          name: acc.accName || '',
          phone: acc.accPhone || '',
          passwordHint: acc.accPasswordHint || '',
          orgName: row.orgName || '',
          roleKey: (row.roleKey || '') as RoleKey,
          status: acc.accStatus || 'active',
          createdBy: acc.accCreatedBy || '',
          note: acc.accNote || '',
          roles: new Set<string>(),
        });
      }
      if (row.roleKey) {
        accountMap.get(acc.id)!.roles.add(row.roleKey);
      }
    }

    const items: Account[] = Array.from(accountMap.values()).map((acc) => {
      const roleKeys = Array.from(acc.roles);
      return {
        ...acc,
        roleKey: (roleKeys[0] || '') as RoleKey,
      };
    });

    return { items, total };
  }

  async getAccountById(id: string): Promise<Account> {
    const rows = await this.db
      .select({
        account: accounts,
        orgName: organizations.name,
        roleKey: accountRoles.roleKey,
      })
      .from(accounts)
      .leftJoin(organizations, eq(accounts.orgId, organizations.slug))
      .leftJoin(accountRoles, eq(accounts.id, accountRoles.accId))
      .where(eq(accounts.id, id));

    if (rows.length === 0) {
      throw new NotFoundException('账号不存在');
    }

    const roleKeys = rows
      .filter((r) => r.roleKey)
      .map((r) => r.roleKey as string);

    const acc = rows[0].account;
    return {
      id: acc.id,
      orgId: acc.orgId || '',
      name: acc.accName || '',
      phone: acc.accPhone || '',
      passwordHint: acc.accPasswordHint || '',
      orgName: rows[0].orgName || '',
      roleKey: (roleKeys[0] || '') as RoleKey,
      status: acc.accStatus || 'active',
      createdBy: acc.accCreatedBy || '',
      note: acc.accNote || '',
    };
  }

  async createAccount(data: Partial<Account> & {
    orgId: string;
    name: string;
    phone: string;
  }): Promise<{ id: string }> {
    if (!data.orgId) {
      throw new BadRequestException('组织ID不能为空');
    }
    if (!data.name) {
      throw new BadRequestException('账号名称不能为空');
    }
    if (!data.phone) {
      throw new BadRequestException('手机号不能为空');
    }

    const result = await this.db.insert(accounts).values({
      orgId: data.orgId,
      accName: data.name,
      accPhone: data.phone,
      accPasswordHint: data.passwordHint || '',
      org: '',
      roles: data.roleKey || '',
      accStatus: data.status || 'active',
      accCreatedBy: data.createdBy || '',
      accNote: data.note || '',
    }).returning({ id: accounts.id });

    if (result.length === 0) {
      throw new BadRequestException('创建账号失败');
    }

    // 如果有角色，也写入 account_roles
    if (data.roleKey) {
      await this.db.insert(accountRoles).values({
        orgId: data.orgId,
        accId: result[0].id,
        roleKey: data.roleKey,
        arStatus: 'active',
        arAssignedBy: data.createdBy || '',
        arNote: '',
      });
    }

    this.logger.log(`创建账号: ${data.name}`);
    return { id: result[0].id };
  }

  async updateAccount(
    id: string,
    data: Partial<Account>,
  ): Promise<{ id: string }> {
    const existing = await this.db.select().from(accounts).where(eq(accounts.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('账号不存在');
    }

    const patch: Partial<typeof accounts.$inferInsert> = {};
    if (data.name !== undefined) patch.accName = data.name;
    if (data.phone !== undefined) patch.accPhone = data.phone;
    if (data.passwordHint !== undefined) patch.accPasswordHint = data.passwordHint;
    if (data.status !== undefined) patch.accStatus = data.status;
    if (data.note !== undefined) patch.accNote = data.note;
    if (data.roleKey !== undefined) patch.roles = data.roleKey;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db.update(accounts)
      .set(patch)
      .where(eq(accounts.id, id))
      .returning({ id: accounts.id });

    if (result.length === 0) {
      throw new BadRequestException('更新账号失败');
    }

    // 同步更新角色关联（简单替换策略）
    if (data.roleKey !== undefined) {
      await this.db.delete(accountRoles).where(eq(accountRoles.accId, id));
      if (data.roleKey) {
        await this.db.insert(accountRoles).values({
          orgId: existing[0].orgId,
          accId: id,
          roleKey: data.roleKey,
          arStatus: 'active',
          arAssignedBy: '',
          arNote: '',
        });
      }
    }

    this.logger.log(`更新账号: ${id}`);
    return { id };
  }

  async removeAccount(id: string): Promise<void> {
    const existing = await this.db.select().from(accounts).where(eq(accounts.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('账号不存在');
    }

    // 先删除角色关联
    await this.db.delete(accountRoles).where(eq(accountRoles.accId, id));

    const result = await this.db.delete(accounts)
      .where(eq(accounts.id, id))
      .returning({ id: accounts.id });

    if (result.length === 0) {
      throw new BadRequestException('删除账号失败');
    }

    this.logger.log(`删除账号: ${id}`);
  }

  // ===== Roles =====

  async listRoles(): Promise<ListResponse<Role>> {
    const rows = await this.db.select().from(roles).orderBy(roles.roleKey);
    const items: Role[] = rows.map((r) => this.mapRole(r));
    return { items, total: items.length };
  }

  async getRoleById(id: string): Promise<Role> {
    const rows = await this.db.select().from(roles).where(eq(roles.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('角色不存在');
    }
    return this.mapRole(rows[0]);
  }

  private mapRole(row: typeof roles.$inferSelect): Role {
    const perms = row.rolePermissions
      ? row.rolePermissions.split(',').map((p: string) => p.trim()).filter(Boolean)
      : [];
    return {
      id: row.id,
      key: (row.roleKey || '') as RoleKey,
      name: row.roleName || '',
      scope: (row.roleScope || 'organization') as 'platform' | 'organization',
      description: row.roleDesc || '',
      permissions: perms,
    };
  }
}
