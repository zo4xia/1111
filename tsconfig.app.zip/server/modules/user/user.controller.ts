import {
  Controller,
  Get,
  Post,
  Patch,
  Query,
  Param,
  Body,
} from '@nestjs/common';
import { UserService, ROLE_DEFS, ROLE_QUOTA } from './user.service';

@Controller('api/accounts')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('role') role?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    const result = await this.userService.list({
      orgId,
      role,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }

  @Get('roles/meta')
  async getRoleMeta() {
    return {
      code: 0,
      data: { roles: ROLE_DEFS, quotas: ROLE_QUOTA },
      message: 'success',
    };
  }

  @Post()
  async create(
    @Body()
    body: {
      phone: string;
      name: string;
      orgId: string;
      roles: string[];
      createdBy: string;
    },
  ) {
    const result = await this.userService.create(body);
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }

  @Post(':id/roles')
  async assignRoles(
    @Param('id') id: string,
    @Body() body: { roles: string[]; assignedBy: string },
  ) {
    const result = await this.userService.assignRoles(
      id,
      body.roles,
      body.assignedBy,
    );
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }

  @Patch(':id/status')
  async toggleStatus(
    @Param('id') id: string,
    @Body() body: { status: 'active' | 'disabled' },
  ) {
    const result = await this.userService.toggleStatus(id, body.status);
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }
}
