import { Injectable, Logger, ConflictException, NotFoundException, Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count, inArray } from 'drizzle-orm';
import { accounts, accountRoles, organizations } from '@server/database/schema';
import type { PaginatedResponse } from '@shared/api.interface';

export interface AccountItem {
  id: string;
  name: string;
  phone: string;
  orgId: string;
  orgName: string;
  roles: string[];
  status: 'active' | 'disabled';
  lastLogin: string;
  createdBy: string;
  createdAt: string;
}

export const ROLE_DEFS: Array<{ key: string; label: string }> = [
  { key: 'platform_admin', label: '平台管理员' },
  { key: 'sub_admin', label: '子管理员' },
  { key: 'operator', label: '操作员' },
  { key: 'editor', label: '编辑' },
  { key: 'reviewer', label: '审核员' },
  { key: 'voter', label: '选民' },
];

export const ROLE_QUOTA: Record<string, number> = {
  platform_admin: 1,
  sub_admin: 2,
  reviewer: 3,
  operator: 5,
  editor: 5,
  voter: 9999,
};

@Injectable()
export class UserService {
  private readonly logger = new Logger(UserService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    role?: string;
    page?: number;
    pageSize?: number;
  }): Promise<PaginatedResponse<AccountItem>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 20;

    const conditions = [];
    if (params.orgId) conditions.push(eq(accounts.orgId, params.orgId));


    const baseQuery = conditions.length > 0
      ? this.db
          .select({
            account: accounts,
            orgName: organizations.name,
            roleKey: accountRoles.roleKey,
          })
          .from(accounts)
          .leftJoin(organizations, eq(accounts.orgId, organizations.slug))
          .leftJoin(accountRoles, eq(accounts.id, accountRoles.accId))
          .where(and(...conditions))
      : this.db
          .select({
            account: accounts,
            orgName: organizations.name,
            roleKey: accountRoles.roleKey,
          })
          .from(accounts)
          .leftJoin(organizations, eq(accounts.orgId, organizations.slug))
          .leftJoin(accountRoles, eq(accounts.id, accountRoles.accId));

    const rows = await baseQuery
      .orderBy(desc(accounts.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(accounts).where(and(...conditions))
      : await this.db.select({ count: count() }).from(accounts);

    const total = Number(totalResult[0]?.count ?? 0);

    const accountMap = new Map<string, AccountItem>();
    for (const row of rows) {
      const acc = row.account;
      if (!accountMap.has(acc.id)) {
        accountMap.set(acc.id, {
          id: acc.id,
          name: acc.accName || '',
          phone: acc.accPhone || '',
          orgId: acc.orgId || '',
          orgName: row.orgName || acc.orgId || '',
          roles: [],
          status: (acc.accStatus === 'disabled' ? 'disabled' : 'active') as 'active' | 'disabled',
          lastLogin: '',
          createdBy: acc.accCreatedBy || '',
          createdAt: acc.createdAt ? new Date(acc.createdAt).toISOString().replace('T', ' ').slice(0, 19) : '',
        });
      }
      if (row.roleKey) {
        accountMap.get(acc.id)!.roles.push(row.roleKey);
      }
    }

    let items = Array.from(accountMap.values());

    if (params.role) {
      items = items.filter((a: AccountItem) => a.roles.includes(params.role!));
    }

    return { items, total, page, pageSize };
  }

  async create(data: {
    phone: string;
    name: string;
    orgId: string;
    roles: string[];
    createdBy: string;
  }): Promise<{ id: string }> {
    const result = await this.db.insert(accounts).values({
      orgId: data.orgId,
      accName: data.name,
      accPhone: data.phone,
      accStatus: 'active',
      accCreatedBy: data.createdBy,
    }).returning({ id: accounts.id });

    if (result.length === 0) {
      throw new ConflictException('创建账号失败');
    }

    const accId = result[0].id;

    if (data.roles && data.roles.length > 0) {
      const roleRows = data.roles.map((role: string) => ({
        orgId: data.orgId,
        accId,
        roleKey: role,
        arStatus: 'active',
        arAssignedBy: data.createdBy,
        arNote: '',
      }));
      await this.db.insert(accountRoles).values(roleRows);
    }

    this.logger.log(`账号创建成功: ${accId} / ${data.name}`);
    return { id: accId };
  }

  async assignRoles(
    id: string,
    roles: string[],
    assignedBy: string,
  ): Promise<{ id: string; roles: string[] }> {
    const existing = await this.db.select().from(accounts).where(eq(accounts.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('账号不存在');
    }

    const orgId = existing[0].orgId || '';

    if (orgId) {
      const allOrgAccounts = await this.db
        .select({ accId: accountRoles.accId, roleKey: accountRoles.roleKey })
        .from(accountRoles)
        .innerJoin(accounts, eq(accountRoles.accId, accounts.id))
        .where(and(eq(accounts.orgId, orgId), eq(accountRoles.arStatus, 'active')));

      const roleCounts = new Map<string, Set<string>>();
      for (const row of allOrgAccounts) {
        if (!roleCounts.has(row.roleKey)) {
          roleCounts.set(row.roleKey, new Set());
        }
        if (row.accId !== id) {
          roleCounts.get(row.roleKey)!.add(row.accId);
        }
      }

      for (const role of roles) {
        const quota = ROLE_QUOTA[role];
        if (quota === undefined) continue;
        const currentCount = roleCounts.get(role)?.size ?? 0;
        if (currentCount + 1 > quota) {
          throw new ConflictException(
            `角色"${this.getRoleLabel(role)}"配额不足，当前组织最多 ${quota} 人`,
          );
        }
      }
    }

    await this.db.delete(accountRoles).where(eq(accountRoles.accId, id));

    if (roles.length > 0) {
      const roleRows = roles.map((role: string) => ({
        orgId,
        accId: id,
        roleKey: role,
        arStatus: 'active',
        arAssignedBy: assignedBy,
        arNote: '',
      }));
      await this.db.insert(accountRoles).values(roleRows);
    }

    this.logger.log(`角色分配更新: id=${id}, roles=${roles.join(',')}, by=${assignedBy}`);
    return { id, roles };
  }

  async toggleStatus(
    id: string,
    status: 'active' | 'disabled',
  ): Promise<{ id: string; status: string }> {
    const result = await this.db.update(accounts)
      .set({ accStatus: status })
      .where(eq(accounts.id, id))
      .returning({ id: accounts.id });

    if (result.length === 0) {
      throw new NotFoundException('账号不存在');
    }

    this.logger.log(`账号状态变更: id=${id}, status=${status}`);
    return { id, status };
  }

  private getRoleLabel(roleKey: string): string {
    const found = ROLE_DEFS.find((r: { key: string; label: string }) => r.key === roleKey);
    return found ? found.label : roleKey;
  }
}
