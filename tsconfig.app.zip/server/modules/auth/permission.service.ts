import { Injectable, Logger, Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq } from 'drizzle-orm';
import { organizations } from '@server/database/schema';
import type { Organization, RoleKey, AuthUser } from '@shared/api.interface';

@Injectable()
export class PermissionService {
  private readonly logger = new Logger(PermissionService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  canEditDate(roleKey: RoleKey): boolean {
    return roleKey === 'platform_admin' || roleKey === 'sub_admin';
  }

  canReview(roleKey: RoleKey): boolean {
    return (
      roleKey === 'platform_admin' ||
      roleKey === 'sub_admin' ||
      roleKey === 'reviewer'
    );
  }

  isPlatformAdmin(roleKey: RoleKey): boolean {
    return roleKey === 'platform_admin';
  }

  async getVisibleOrgs(user: AuthUser): Promise<Organization[]> {
    if (this.isPlatformAdmin(user.roleKey)) {
      return this.getAllOrganizations();
    }
    if (user.orgId) {
      const org = await this.getOrganizationById(user.orgId);
      return org ? [org] : [];
    }
    return [];
  }

  async getAllOrganizations(): Promise<Organization[]> {
    const rows = await this.db.select().from(organizations).limit(100);
    return rows.map((r) => this.mapOrg(r));
  }

  async getOrganizationById(orgId: string): Promise<Organization | null> {
    const rows = await this.db
      .select()
      .from(organizations)
      .where(eq(organizations.slug, orgId))
      .limit(1);
    if (!rows.length) return null;
    return this.mapOrg(rows[0]);
  }

  async filterOrgIdsByPermission(
    user: AuthUser,
    requestedOrgIds?: string[],
  ): Promise<string[]> {
    const visibleOrgs = await this.getVisibleOrgs(user);
    const visibleIds = visibleOrgs.map((o) => o.id);
    if (!requestedOrgIds || requestedOrgIds.length === 0) {
      return visibleIds;
    }
    return requestedOrgIds.filter((id) => visibleIds.includes(id));
  }

  private mapOrg(row: typeof organizations.$inferSelect): Organization {
    return {
      id: row.id,
      name: row.name,
      slug: row.slug,
      town: row.town ?? '',
      type: (row.type as Organization['type']) || 'village_committee',
      status: row.status ?? 'active',
    };
  }
}
