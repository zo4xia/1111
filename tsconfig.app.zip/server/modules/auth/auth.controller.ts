import { Controller, Post, Body, Get, Req, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { PermissionService } from './permission.service';
import { AuthGuard, type AuthRequest } from './auth.guard';
import { signJwt } from './jwt.util';
import type {
  LoginRequest,
  LoginResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly permissionService: PermissionService,
  ) {}

  @Post('login')
  async login(
    @Body() body: LoginRequest,
  ): Promise<ApiResponse<LoginResponse>> {
    const account = await this.authService.validateCredentials(
      body.phone,
      body.password,
    );

    const primaryRole = await this.authService.getAccountPrimaryRole(
      account.phone,
    );
    const accountWithRole = { ...account, roleKey: primaryRole };

    const token = signJwt({
      sub: account.id,
      phone: account.phone,
      roleKey: primaryRole,
      orgId: account.orgId,
    });

    const user = {
      accountId: account.id,
      phone: account.phone,
      roleKey: account.roleKey,
      orgId: account.orgId,
    };

    const visibleOrgs = await this.permissionService.getVisibleOrgs(user);

    return {
      code: 0,
      data: {
        token,
        account: accountWithRole,
        roleKey: primaryRole,
        visibleOrgs,
        canEditDate: this.permissionService.canEditDate(primaryRole),
        canReview: this.permissionService.canReview(primaryRole),
      },
      message: 'success',
    };
  }

  @UseGuards(AuthGuard)
  @Get('me')
  async getMe(@Req() req: AuthRequest): Promise<ApiResponse<LoginResponse>> {
    const user = req.user!;
    const account = await this.authService.findAccountByPhone(user.phone);
    if (!account) {
      return { code: 401, data: null as unknown as LoginResponse, message: '账号不存在' };
    }
    const primaryRole = await this.authService.getAccountPrimaryRole(
      user.phone,
    );
    const accountWithRole = { ...account, roleKey: primaryRole };
    const visibleOrgs = await this.permissionService.getVisibleOrgs(user);
    return {
      code: 0,
      data: {
        token: '',
        account: accountWithRole,
        roleKey: primaryRole,
        visibleOrgs,
        canEditDate: this.permissionService.canEditDate(primaryRole),
        canReview: this.permissionService.canReview(primaryRole),
      },
      message: 'success',
    };
  }
}
