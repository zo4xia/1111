import { Injectable, UnauthorizedException, Logger, Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and } from 'drizzle-orm';
import { accounts, accountRoles } from '@server/database/schema';
import type { Account, RoleKey } from '@shared/api.interface';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async findAccountByPhone(phone: string): Promise<Account | null> {
    const rows = await this.db
      .select()
      .from(accounts)
      .where(eq(accounts.accPhone, phone))
      .limit(1);
    if (!rows.length) return null;
    return this.mapAccount(rows[0]);
  }

  async validateCredentials(phone: string, password: string): Promise<Account> {
    const account = await this.findAccountByPhone(phone);
    if (!account) {
      this.logger.warn(`登录失败：账号不存在 ${phone}`);
      throw new UnauthorizedException('手机号或密码错误');
    }
    if (account.passwordHint !== password) {
      this.logger.warn(`登录失败：密码错误 ${phone}`);
      throw new UnauthorizedException('手机号或密码错误');
    }
    return account;
  }

  async getAccountRoles(phone: string): Promise<RoleKey[]> {
    const accRows = await this.db
      .select({ id: accounts.id })
      .from(accounts)
      .where(eq(accounts.accPhone, phone))
      .limit(1);
    if (!accRows.length) return [];

    const roleRows = await this.db
      .select({ roleKey: accountRoles.roleKey })
      .from(accountRoles)
      .where(
        and(
          eq(accountRoles.accId, accRows[0].id),
          eq(accountRoles.arStatus, 'active'),
        ),
      );

    const roleKeys = roleRows
      .map((r) => r.roleKey as RoleKey)
      .filter(Boolean);

    return [...new Set(roleKeys)];
  }

  async getAccountPrimaryRole(phone: string): Promise<RoleKey> {
    const roles = await this.getAccountRoles(phone);
    const priority: RoleKey[] = [
      'platform_admin',
      'sub_admin',
      'reviewer',
      'operator',
      'editor',
      'voters',
    ];
    for (const role of priority) {
      if (roles.includes(role)) return role;
    }
    return roles[0] || 'voters';
  }

  private mapAccount(row: typeof accounts.$inferSelect): Account {
    return {
      id: row.id,
      orgId: row.orgId,
      name: row.accName ?? '',
      phone: row.accPhone ?? '',
      passwordHint: row.accPasswordHint ?? '',
      orgName: row.org ?? '',
      roleKey: (row.roles as RoleKey) || 'voters',
      status: row.accStatus || 'active',
      createdBy: row.accCreatedBy ?? '',
      note: row.accNote ?? '',
    };
  }
}
