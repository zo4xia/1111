import { HmacSHA256 } from 'crypto-js';
import Base64 from 'crypto-js/enc-base64';
import Utf8 from 'crypto-js/enc-utf8';

const JWT_SECRET = process.env.ELECTION_JWT_SECRET || 'chengxiang-election-demo-secret';
const JWT_EXPIRES_IN_MS = 12 * 60 * 60 * 1000;

export interface JwtPayload {
  sub: string;
  phone: string;
  roleKey: string;
  orgId: string;
  iat: number;
  exp: number;
}

function base64UrlEncode(str: string): string {
  return Base64.stringify(Utf8.parse(str))
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str: string): string {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (padded.length % 4)) % 4;
  return Utf8.stringify(Base64.parse(padded + '='.repeat(padLen)));
}

export function signJwt(payload: Omit<JwtPayload, 'iat' | 'exp'>): string {
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Date.now();
  const fullPayload: JwtPayload = {
    ...payload,
    iat: now,
    exp: now + JWT_EXPIRES_IN_MS,
  };
  const headerStr = base64UrlEncode(JSON.stringify(header));
  const payloadStr = base64UrlEncode(JSON.stringify(fullPayload));
  const signature = HmacSHA256(`${headerStr}.${payloadStr}`, JWT_SECRET).toString(Base64)
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
  return `${headerStr}.${payloadStr}.${signature}`;
}

export function verifyJwt(token: string): JwtPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [headerStr, payloadStr, signature] = parts;
    const expected = HmacSHA256(`${headerStr}.${payloadStr}`, JWT_SECRET).toString(Base64)
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');
    if (expected !== signature) return null;
    const payload = JSON.parse(base64UrlDecode(payloadStr)) as JwtPayload;
    if (payload.exp && payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}
