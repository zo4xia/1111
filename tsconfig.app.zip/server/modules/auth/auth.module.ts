import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { PermissionService } from './permission.service';
import { AuthGuard } from './auth.guard';

@Module({
  imports: [],
  controllers: [AuthController],
  providers: [AuthService, PermissionService, AuthGuard],
  exports: [AuthService, PermissionService, AuthGuard],
})
export class AuthModule {}
