import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  ForbiddenException,
} from '@nestjs/common';
import { verifyJwt } from './jwt.util';
import type { AuthUser, RoleKey } from '@shared/api.interface';
import { Reflector } from '@nestjs/core';

export const ROLES_KEY = 'roles';

export const CAN_EDIT_DATE_ROLES: RoleKey[] = ['platform_admin', 'sub_admin'];
export const CAN_REVIEW_ROLES: RoleKey[] = ['platform_admin', 'sub_admin', 'reviewer'];
export const WRITE_ROLES: RoleKey[] = [
  'platform_admin',
  'sub_admin',
  'operator',
  'editor',
];

export interface AuthRequest extends Express.Request {
  user?: AuthUser;
  headers: Record<string, string | string[] | undefined>;
}

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest<AuthRequest>();
    const authHeader = (req.headers.authorization as string) || '';
    const token = authHeader.startsWith('Bearer ')
      ? authHeader.slice(7)
      : '';
    const payload = token ? verifyJwt(token) : null;
    if (!payload) {
      throw new UnauthorizedException('未登录或登录已过期');
    }
    req.user = {
      accountId: payload.sub,
      phone: payload.phone,
      roleKey: payload.roleKey as RoleKey,
      orgId: payload.orgId,
    };

    const requiredRoles = this.reflector.getAllAndOverride<RoleKey[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (requiredRoles && requiredRoles.length > 0) {
      if (!requiredRoles.includes(payload.roleKey as RoleKey)) {
        throw new ForbiddenException('权限不足');
      }
    }

    return true;
  }
}
