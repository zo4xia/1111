import { Controller, Get, Query, Param } from '@nestjs/common';
import { LogService } from './log.service';

@Controller('api/logs')
export class LogController {
  constructor(private readonly logService: LogService) {}

  @Get()
  async list(
    @Query('operator') operator?: string,
    @Query('type') type?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    const result = await this.logService.list({
      operator,
      type,
      startDate,
      endDate,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    const result = await this.logService.getById(id);
    return {
      code: 0,
      data: result,
      message: 'success',
    };
  }
}
