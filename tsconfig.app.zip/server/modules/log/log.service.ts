import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import type { PaginatedResponse } from '@shared/api.interface';

export interface OperationLog {
  id: string;
  operationTime: string;
  operator: string;
  type: string;
  target: string;
  summary: string;
  ip: string;
}

function genId(): string {
  return 'log_' + Math.random().toString(36).slice(2, 12);
}

function pad2(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}

@Injectable()
export class LogService {
  private readonly logger = new Logger(LogService.name);
  private logs: OperationLog[] = [];

  constructor() {
    this.initSampleLogs();
  }

  private initSampleLogs(): void {
    const baseDate = new Date('2026-08-24T10:00:00');
    const samples: Array<Omit<OperationLog, 'id' | 'operationTime'> & { hourOffset: number }> = [
      { hourOffset: 0, operator: '系统管理员', type: 'login', target: '系统', summary: '用户登录系统', ip: '192.168.1.101' },
      { hourOffset: -1, operator: '张审核', type: 'approve', target: '候选人材料', summary: '审核通过候选人[张三]的资格材料', ip: '192.168.1.102' },
      { hourOffset: -2, operator: '李编辑', type: 'create', target: '公告', summary: '创建公告[换届选举工作通知]', ip: '192.168.1.103' },
      { hourOffset: -3, operator: '王操作员', type: 'update', target: '选民信息', summary: '更新选民[赵六]的联系电话', ip: '192.168.1.104' },
      { hourOffset: -4, operator: '张审核', type: 'approve', target: '候选人材料', summary: '驳回候选人[李四]的资格材料，原因：材料不全', ip: '192.168.1.102' },
      { hourOffset: -5, operator: '系统管理员', type: 'update', target: '角色分配', summary: '为账号[李编辑]分配角色：编辑', ip: '192.168.1.101' },
      { hourOffset: -6, operator: '李编辑', type: 'update', target: '公告', summary: '发布公告[选民登记通知]', ip: '192.168.1.103' },
      { hourOffset: -7, operator: '王操作员', type: 'create', target: '选民登记', summary: '批量导入选民数据 128 条', ip: '192.168.1.104' },
      { hourOffset: -8, operator: '系统管理员', type: 'delete', target: '账号管理', summary: '禁用账号[test_user]', ip: '192.168.1.101' },
      { hourOffset: -10, operator: '李编辑', type: 'login', target: '系统', summary: '用户登录系统', ip: '192.168.1.103' },
      { hourOffset: -12, operator: '张审核', type: 'export', target: '候选人报表', summary: '导出候选人资格审核报表', ip: '192.168.1.102' },
      { hourOffset: -15, operator: '系统管理员', type: 'create', target: '选举配置', summary: '创建选举[城厢区第十四届居委会换届选举]', ip: '192.168.1.101' },
      { hourOffset: -20, operator: '王操作员', type: 'login', target: '系统', summary: '用户登录系统', ip: '192.168.1.104' },
      { hourOffset: -24, operator: '系统管理员', type: 'update', target: '系统配置', summary: '修改系统参数：默认选举方式为差额选举', ip: '192.168.1.101' },
    ];

    this.logs = samples.map((s) => {
      const d = new Date(baseDate.getTime() + s.hourOffset * 3600 * 1000);
      const timeStr = `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
      const { hourOffset: _ho, ...rest } = s;
      void _ho;
      return {
        id: genId(),
        operationTime: timeStr,
        ...rest,
      } as OperationLog;
    });
  }

  async list(params: {
    operator?: string;
    type?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    pageSize?: number;
  }): Promise<PaginatedResponse<OperationLog>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 20;

    let items = [...this.logs];

    if (params.operator) {
      items = items.filter((l) => l.operator.includes(params.operator!));
    }
    if (params.type) {
      items = items.filter((l) => l.type === params.type);
    }
    if (params.startDate) {
      items = items.filter((l) => l.operationTime >= `${params.startDate} 00:00:00`);
    }
    if (params.endDate) {
      items = items.filter((l) => l.operationTime <= `${params.endDate} 23:59:59`);
    }

    // 时间倒序
    items.sort((a, b) => (a.operationTime < b.operationTime ? 1 : -1));

    const total = items.length;
    const start = (page - 1) * pageSize;
    const paged = items.slice(start, start + pageSize);

    return { items: paged, total, page, pageSize };
  }

  async getById(id: string): Promise<OperationLog> {
    const log = this.logs.find((l) => l.id === id);
    if (!log) {
      throw new NotFoundException('日志不存在');
    }
    return log;
  }
}
