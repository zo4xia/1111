import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, asc, count } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { electionStages } from '@server/database/schema';
import type { ElectionStage, ListResponse, StageStatus } from '@shared/api.interface';

/**
 * 从 stage_key（如 "D-35"、"D-33~-29"、"D0"、"D+1~+10"）解析数值 offset
 * 解析失败时返回 { start: 0, end: 0 }
 */
function parseOffsetFromStageKey(stageKey: string): { start: number; end: number } {
  if (!stageKey || !stageKey.startsWith('D')) {
    return { start: 0, end: 0 };
  }
  const body = stageKey.slice(1); // 去掉前缀 "D"
  try {
    if (body.includes('~')) {
      const [startStr, endStr] = body.split('~', 2);
      const start = Number(startStr);
      const end = Number(endStr);
      if (Number.isNaN(start) || Number.isNaN(end)) {
        return { start: 0, end: 0 };
      }
      return { start, end };
    }
    const val = Number(body);
    if (Number.isNaN(val)) {
      return { start: 0, end: 0 };
    }
    return { start: val, end: val };
  } catch {
    return { start: 0, end: 0 };
  }
}

@Injectable()
export class ElectionStageService {
  private readonly logger = new Logger(ElectionStageService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * 按选举ID（elId 业务编码）查阶段列表，按 stageOrder 升序
   */
  async listByElection(
    electionId?: string,
    orgId?: string,
  ): Promise<ListResponse<ElectionStage>> {
    const conditions = [];
    if (electionId) conditions.push(eq(electionStages.electionId, electionId));
    if (orgId) conditions.push(eq(electionStages.orgId, orgId));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, rows] = await Promise.all([
      this.db.select({ count: count() }).from(electionStages).where(where),
      this.db
        .select()
        .from(electionStages)
        .where(where)
        .orderBy(asc(electionStages.stageOrder)),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: ElectionStage[] = rows.map((r) => this.mapRecord(r));

    return { items, total };
  }

  async getById(id: string): Promise<ElectionStage> {
    if (!id) {
      throw new BadRequestException('阶段ID不能为空');
    }
    const rows = await this.db
      .select()
      .from(electionStages)
      .where(eq(electionStages.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('阶段记录不存在');
    }
    return this.mapRecord(rows[0]);
  }

  async updateStatus(
    id: string,
    status: string,
  ): Promise<{ id: string; status: string }> {
    if (!status) {
      throw new BadRequestException('状态不能为空');
    }
    const updated = await this.db
      .update(electionStages)
      .set({ stageStatus: status })
      .where(eq(electionStages.id, id))
      .returning({ id: electionStages.id });
    if (updated.length === 0) {
      throw new NotFoundException('阶段记录不存在');
    }
    return { id: updated[0].id, status };
  }

  async updateStageDates(
    id: string,
    startDate?: string,
    endDate?: string,
  ): Promise<{ id: string; startDate: string; endDate: string }> {
    const patch: Partial<typeof electionStages.$inferInsert> = {};
    if (startDate !== undefined) patch.stageStartDate = startDate || null;
    if (endDate !== undefined) patch.stageEndDate = endDate || null;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新的日期字段');
    }

    const updated = await this.db
      .update(electionStages)
      .set(patch)
      .where(eq(electionStages.id, id))
      .returning({
        id: electionStages.id,
        startDate: electionStages.stageStartDate,
        endDate: electionStages.stageEndDate,
      });
    if (updated.length === 0) {
      throw new NotFoundException('阶段记录不存在');
    }
    return {
      id: updated[0].id,
      startDate: updated[0].startDate || '',
      endDate: updated[0].endDate || '',
    };
  }

  /**
   * 重置选举下所有阶段为未开始
   */
  async resetStages(electionId: string): Promise<{ resetCount: number }> {
    if (!electionId) {
      throw new BadRequestException('选举ID不能为空');
    }
    const result = await this.db
      .update(electionStages)
      .set({ stageStatus: '未开始' })
      .where(eq(electionStages.electionId, electionId))
      .returning({ id: electionStages.id });
    return { resetCount: result.length };
  }

  private mapRecord(r: typeof electionStages.$inferSelect): ElectionStage {
    const offset = parseOffsetFromStageKey(r.stageKey || '');
    return {
      id: r.id,
      stageKey: r.stageKey || '',
      stageName: r.stageName || '',
      offsetStart: offset.start,
      offsetEnd: offset.end,
      planStart: r.stageStartDate || '',
      planEnd: r.stageEndDate || '',
      status: (r.stageStatus as StageStatus) || '未开始',
      bizModule: '',
      note: '',
    };
  }
}
