import { Module } from '@nestjs/common';
import { ElectionService } from './election.service';
import { ElectionController } from './election.controller';
import { ElectionStageService } from './election-stage.service';
import { ElectionStagesController } from './election-stages.controller';

@Module({
  imports: [],
  controllers: [ElectionController, ElectionStagesController],
  providers: [ElectionService, ElectionStageService],
  exports: [ElectionService, ElectionStageService],
})
export class ElectionModule {}
