import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, desc, count, or, ilike } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { elections } from '@server/database/schema';
import type {
  Election,
  ElectionListItem,
  ListResponse,
} from '@shared/api.interface';

@Injectable()
export class ElectionService {
  private readonly logger = new Logger(ElectionService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<ElectionListItem>> {
    const conditions = [];
    if (params.orgId) conditions.push(eq(elections.orgId, params.orgId));
    if (params.status) conditions.push(eq(elections.elStatus, params.status));

    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const [totalResult, rows] = await Promise.all([
      this.db.select({ count: count() }).from(elections).where(where),
      this.db
        .select()
        .from(elections)
        .where(where)
        .orderBy(desc(elections.elTerm))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: ElectionListItem[] = rows.map((r) => this.mapListItem(r));

    return { items, total };
  }

  async getCurrent(orgId?: string): Promise<Election | null> {
    const conditions = [];
    if (orgId) conditions.push(eq(elections.orgId, orgId));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    // 优先找进行中的选举
    const inProgressWhere = where
      ? and(where, eq(elections.elStatus, 'in_progress'))
      : eq(elections.elStatus, 'in_progress');

    const inProgressRows = await this.db
      .select()
      .from(elections)
      .where(inProgressWhere)
      .limit(1);

    if (inProgressRows.length > 0) {
      return this.mapRecord(inProgressRows[0]);
    }

    // 没有进行中的，按届期降序取最新
    const latestRows = await this.db
      .select()
      .from(elections)
      .where(where)
      .orderBy(desc(elections.elTerm))
      .limit(1);

    return latestRows.length > 0 ? this.mapRecord(latestRows[0]) : null;
  }

  /**
   * 通过 elId（业务编码）或 id（UUID）查询选举详情
   * 优先尝试 elId 查询，再尝试 id 查询
   */
  async getById(id: string): Promise<Election> {
    if (!id) {
      throw new BadRequestException('选举ID不能为空');
    }
    const rows = await this.db
      .select()
      .from(elections)
      .where(or(eq(elections.elId, id), eq(elections.id, id)))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return this.mapRecord(rows[0]);
  }

  async create(data: Partial<Election> & { orgId: string }): Promise<{ id: string }> {
    if (!data.orgId) {
      throw new BadRequestException('orgId 不能为空');
    }
    if (!data.term) {
      throw new BadRequestException('届期不能为空');
    }
    // 自动生成 elId，格式：el-{序号}
    const elId = data.id || `el-${Date.now().toString().slice(-6)}`;

    const inserted = await this.db
      .insert(elections)
      .values({
        orgId: data.orgId,
        elId,
        elTerm: data.term || '',
        elName: data.name || '',
        elStatus: data.status || 'in_progress',
        elElectionDate: data.electionDate || null,
        elMethod: data.method || '',
        elProposalId: data.proposalId || '',
        elNote: '',
      })
      .returning({ id: elections.elId });
    if (inserted.length === 0) {
      throw new BadRequestException('创建选举失败');
    }
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    data: Partial<Election>,
  ): Promise<{ id: string }> {
    const existing = await this.findByIdOrElId(id);
    const patch: Partial<typeof elections.$inferInsert> = {};
    if (data.term !== undefined) patch.elTerm = data.term;
    if (data.name !== undefined) patch.elName = data.name;
    if (data.status !== undefined) patch.elStatus = data.status;
    if (data.electionDate !== undefined) patch.elElectionDate = data.electionDate || null;
    if (data.method !== undefined) patch.elMethod = data.method;
    if (data.proposalId !== undefined) patch.elProposalId = data.proposalId;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(elections)
      .set(patch)
      .where(eq(elections.id, existing.id))
      .returning({ id: elections.elId });
    if (updated.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return { id: updated[0].id };
  }

  async updateStatus(id: string, status: string): Promise<{ id: string; status: string }> {
    if (!status) {
      throw new BadRequestException('状态不能为空');
    }
    const existing = await this.findByIdOrElId(id);
    const updated = await this.db
      .update(elections)
      .set({ elStatus: status })
      .where(eq(elections.id, existing.id))
      .returning({ id: elections.elId });
    if (updated.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return { id: updated[0].id, status };
  }

  async updateElectionDate(
    id: string,
    electionDate: string,
  ): Promise<{ id: string; electionDate: string }> {
    if (!electionDate) {
      throw new BadRequestException('electionDate 不能为空');
    }
    const existing = await this.findByIdOrElId(id);
    const updated = await this.db
      .update(elections)
      .set({ elElectionDate: electionDate })
      .where(eq(elections.id, existing.id))
      .returning({ id: elections.elId });
    if (updated.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return { id: updated[0].id, electionDate };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const existing = await this.findByIdOrElId(id);
    const deleted = await this.db
      .delete(elections)
      .where(eq(elections.id, existing.id))
      .returning({ id: elections.id });
    if (deleted.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return { success: true };
  }

  /**
   * 通过 elId 或 id 查找，返回完整行数据（内部使用）
   */
  private async findByIdOrElId(id: string): Promise<typeof elections.$inferSelect> {
    const rows = await this.db
      .select()
      .from(elections)
      .where(or(eq(elections.elId, id), eq(elections.id, id)))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('选举记录不存在');
    }
    return rows[0];
  }

  private mapListItem(r: typeof elections.$inferSelect): ElectionListItem {
    return {
      id: r.elId,
      term: r.elTerm || '',
      name: r.elName || '',
      status: r.elStatus || '',
      electionDate: r.elElectionDate || '',
      method: r.elMethod || '',
    };
  }

  private mapRecord(r: typeof elections.$inferSelect): Election {
    return {
      id: r.elId,
      orgId: r.orgId,
      term: r.elTerm || '',
      name: r.elName || '',
      status: r.elStatus || '',
      electionDate: r.elElectionDate || '',
      method: r.elMethod || '',
      proposalId: r.elProposalId || '',
    };
  }
}
