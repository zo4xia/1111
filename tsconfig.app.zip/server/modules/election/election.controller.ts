import {
  Controller,
  Get,
  Query,
  Put,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { ElectionService } from './election.service';
import type {
   Election,
   ElectionListItem,
   ListResponse,
   ApiResponse,
 } from '@shared/api.interface';

@Controller('api/elections')
export class ElectionController {
  constructor(private readonly electionService: ElectionService) {}

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<ElectionListItem>>> {
     const data = await this.electionService.list({
       orgId,
       status,
       page: page ? parseInt(page, 10) : undefined,
       pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
     });
     return { code: 0, data, message: 'success' };
   }

  @Get('current')
  async getCurrent(@Query('orgId') orgId: string): Promise<ApiResponse<Election | null>> {
     const data = await this.electionService.getCurrent(orgId);
     return { code: 0, data, message: 'success' };
   }

  @Put(':id/election-date')
  async updateElectionDate(
    @Param('id') id: string,
    @Body() body: { electionDate: string },
  ): Promise<ApiResponse<{ id: string; electionDate: string }>> {
     if (!body.electionDate) {
       throw new BadRequestException('electionDate 不能为空');
     }
     const data = await this.electionService.updateElectionDate(id, body.electionDate);
     return { code: 0, data, message: 'success' };
   }
 }
