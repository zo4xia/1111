import {
  Controller,
  Get,
  Query,
  Patch,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { ElectionStageService } from './election-stage.service';
import type { ElectionStage, ListResponse, ApiResponse } from '@shared/api.interface';

@Controller('api/election-stages')
export class ElectionStagesController {
  constructor(private readonly electionStageService: ElectionStageService) {}

  @Get()
  async list(
    @Query('electionId') electionId?: string,
    @Query('orgId') orgId?: string,
  ): Promise<ApiResponse<ListResponse<ElectionStage>>> {
     const data = await this.electionStageService.listByElection(electionId, orgId);
     return { code: 0, data, message: 'success' };
   }

  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() body: { status: string },
  ): Promise<ApiResponse<{ id: string; status: string }>> {
     if (!body.status) {
       throw new BadRequestException('status 不能为空');
     }
     const data = await this.electionStageService.updateStatus(id, body.status);
     return { code: 0, data, message: 'success' };
   }
 }
