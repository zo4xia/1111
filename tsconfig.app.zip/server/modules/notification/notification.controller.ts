import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Query,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { NotificationService } from './notification.service';
import type {
  Notification,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/notifications')
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
    @Query('type') type?: string,
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Notification>>> {
    const data = await this.notificationService.list({
      orgId,
      electionId,
      type,
      status,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async detail(@Param('id') id: string): Promise<ApiResponse<Notification>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.notificationService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: Partial<Notification> & { orgId: string },
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.orgId) {
      throw new BadRequestException('组织ID不能为空');
    }
    const data = await this.notificationService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: Partial<Notification>,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.notificationService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    await this.notificationService.remove(id);
    return { code: 0, data: undefined, message: 'success' };
  }
}
