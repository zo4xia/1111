import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count } from 'drizzle-orm';
import { notifications } from '@server/database/schema';
import type { Notification, ListResponse } from '@shared/api.interface';

@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    electionId?: string;
    type?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Notification>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const conditions = this.buildConditions(params);

    const query = conditions.length > 0
      ? this.db.select().from(notifications).where(and(...conditions))
      : this.db.select().from(notifications);

    const rows = await query
      .orderBy(desc(notifications.notifScheduledAt), desc(notifications.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(notifications).where(and(...conditions))
      : await this.db.select({ count: count() }).from(notifications);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Notification[] = rows.map((r) => this.mapNotification(r));

    return { items, total };
  }

  async getById(id: string): Promise<Notification> {
    const rows = await this.db.select().from(notifications).where(eq(notifications.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('通知不存在');
    }
    return this.mapNotification(rows[0]);
  }

  async create(data: Partial<Notification> & {
    orgId: string;
    electionId?: string;
    type?: string;
    content?: string;
  }): Promise<{ id: string }> {
    if (!data.orgId) {
      throw new BadRequestException('组织ID不能为空');
    }

    const result = await this.db.insert(notifications).values({
      notifId: data.id || '',
      orgId: data.orgId,
      electionId: data.electionId || '',
      notifType: data.type || '',
      notifContent: data.content || '',
      notifToRoleFilter: data.toRoleFilter || '',
      notifToPhones: data.toPhones || '',
      notifStatus: data.status || 'pending',
      notifScheduledAt: data.scheduledAt || null,
      notifSourceType: data.sourceType || '',
      notifSourceKey: data.sourceKey || '',
    }).returning({ id: notifications.id });

    if (result.length === 0) {
      throw new BadRequestException('创建通知失败');
    }

    this.logger.log(`创建通知: ${result[0].id}`);
    return { id: result[0].id };
  }

  async update(
    id: string,
    data: Partial<Notification>,
  ): Promise<{ id: string }> {
    const existing = await this.db.select().from(notifications).where(eq(notifications.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('通知不存在');
    }

    const patch: Partial<typeof notifications.$inferInsert> = {};
    if (data.type !== undefined) patch.notifType = data.type;
    if (data.content !== undefined) patch.notifContent = data.content;
    if (data.toRoleFilter !== undefined) patch.notifToRoleFilter = data.toRoleFilter;
    if (data.toPhones !== undefined) patch.notifToPhones = data.toPhones;
    if (data.status !== undefined) patch.notifStatus = data.status;
    if (data.scheduledAt !== undefined) {
      patch.notifScheduledAt = data.scheduledAt || null;
    }
    if (data.sourceType !== undefined) patch.notifSourceType = data.sourceType;
    if (data.sourceKey !== undefined) patch.notifSourceKey = data.sourceKey;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db.update(notifications)
      .set(patch)
      .where(eq(notifications.id, id))
      .returning({ id: notifications.id });

    if (result.length === 0) {
      throw new BadRequestException('更新通知失败');
    }

    this.logger.log(`更新通知: ${id}`);
    return { id };
  }

  async remove(id: string): Promise<void> {
    const existing = await this.db.select().from(notifications).where(eq(notifications.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('通知不存在');
    }

    const result = await this.db.delete(notifications)
      .where(eq(notifications.id, id))
      .returning({ id: notifications.id });

    if (result.length === 0) {
      throw new BadRequestException('删除通知失败');
    }

    this.logger.log(`删除通知: ${id}`);
  }

  private buildConditions(params: {
    orgId?: string;
    electionId?: string;
    type?: string;
    status?: string;
  }) {
    const conditions = [];
    if (params.orgId) conditions.push(eq(notifications.orgId, params.orgId));
    if (params.electionId) conditions.push(eq(notifications.electionId, params.electionId));
    if (params.type) conditions.push(eq(notifications.notifType, params.type));
    if (params.status) conditions.push(eq(notifications.notifStatus, params.status));
    return conditions;
  }

  private mapNotification(row: typeof notifications.$inferSelect): Notification {
    return {
      id: row.id,
      orgId: row.orgId || '',
      electionId: row.electionId || '',
      type: row.notifType || '',
      content: row.notifContent || '',
      toRoleFilter: row.notifToRoleFilter || '',
      toPhones: row.notifToPhones || '',
      status: row.notifStatus || 'pending',
      scheduledAt: row.notifScheduledAt || '',
      sourceType: row.notifSourceType || '',
      sourceKey: row.notifSourceKey || '',
    };
  }
}
