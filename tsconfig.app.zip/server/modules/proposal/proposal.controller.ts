import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Delete,
  Query,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { ProposalService } from './proposal.service';
import type {
  Proposal,
  ProposalDetail,
  ProposalCreateDto,
  ProposalUpdateDto,
  ProposalStats,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/proposals')
export class ProposalController {
  constructor(private readonly proposalService: ProposalService) {}

  @Get('stats')
  async stats(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
  ): Promise<ApiResponse<ProposalStats>> {
    const data = await this.proposalService.getStats({ orgId, electionId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
    @Query('status') status?: string,
    @Query('method') method?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Proposal>>> {
    const data = await this.proposalService.list({
      orgId,
      electionId,
      status,
      method,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async detail(@Param('id') id: string): Promise<ApiResponse<ProposalDetail>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.proposalService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: ProposalCreateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.title) {
      throw new BadRequestException('标题不能为空');
    }
    const data = await this.proposalService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: ProposalUpdateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.proposalService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    await this.proposalService.remove(id);
    return { code: 0, data: undefined, message: 'success' };
  }

  @Patch(':id/submit')
  async submit(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.proposalService.submitForReview(id);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/approve')
  async approve(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.proposalService.approve(id);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/reject')
  async reject(
    @Param('id') id: string,
    @Body() body: { comment?: string },
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.proposalService.reject(id, body.comment || '');
    return { code: 0, data, message: 'success' };
  }
}
