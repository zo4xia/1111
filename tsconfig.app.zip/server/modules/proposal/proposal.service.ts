import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count, sql } from 'drizzle-orm';
import { proposals } from '@server/database/schema';
import type {
  Proposal,
  ProposalDetail,
  ProposalCreateDto,
  ProposalUpdateDto,
  ProposalStats,
  ListResponse,
} from '@shared/api.interface';

@Injectable()
export class ProposalService {
  private readonly logger = new Logger(ProposalService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    electionId?: string;
    status?: string;
    method?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Proposal>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const conditions = this.buildConditions(params);

    const query = conditions.length > 0
      ? this.db.select().from(proposals).where(and(...conditions))
      : this.db.select().from(proposals);

    const rows = await query
      .orderBy(desc(proposals.propSubmitTime), desc(proposals.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(proposals).where(and(...conditions))
      : await this.db.select({ count: count() }).from(proposals);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Proposal[] = rows.map((r) => this.mapProposal(r));

    return { items, total };
  }

  async getById(id: string): Promise<ProposalDetail> {
    const rows = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('提案不存在');
    }
    const basic = this.mapProposal(rows[0]);
    return { ...basic, content: '' };
  }

  async create(data: ProposalCreateDto): Promise<{ id: string }> {
    if (!data.title) {
      throw new BadRequestException('标题不能为空');
    }
    if (!data.method) {
      throw new BadRequestException('选举方式不能为空');
    }

    const now = new Date().toISOString();
    const result = await this.db.insert(proposals).values({
      orgId: data.orgId || '',
      electionId: data.electionId || '',
      propTitle: data.title,
      propMethod: data.method,
      propCreatorId: '',
      propStatus: 'draft',
      propVersion: 1,
      propSubmitTime: now,
      propReviewerId: '',
      propReviewTime: null,
      propReviewComment: '',
    }).returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('创建提案失败');
    }

    this.logger.log(`创建提案草稿: ${data.title}`);
    return { id: result[0].id };
  }

  async update(
    id: string,
    data: ProposalUpdateDto,
  ): Promise<{ id: string }> {
    const existing = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('提案不存在');
    }

    if (existing[0].propStatus !== 'draft') {
      throw new ConflictException('仅草稿状态的提案可编辑');
    }

    const patch: Partial<typeof proposals.$inferInsert> = {};
    if (data.title !== undefined) patch.propTitle = data.title;
    if (data.method !== undefined) patch.propMethod = data.method;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db.update(proposals)
      .set(patch)
      .where(eq(proposals.id, id))
      .returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('更新提案失败');
    }

    this.logger.log(`更新提案: ${id}`);
    return { id };
  }

  async remove(id: string): Promise<void> {
    const existing = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('提案不存在');
    }

    if (existing[0].propStatus !== 'draft') {
      throw new ConflictException('仅草稿状态的提案可删除');
    }

    const result = await this.db.delete(proposals)
      .where(eq(proposals.id, id))
      .returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('删除提案失败');
    }

    this.logger.log(`删除提案: ${id}`);
  }

  async submitForReview(id: string): Promise<{ id: string; status: string }> {
    const existing = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('提案不存在');
    }

    if (existing[0].propStatus !== 'draft') {
      throw new ConflictException('仅草稿状态的提案可提交审核');
    }

    const now = new Date().toISOString();
    const result = await this.db.update(proposals)
      .set({ propStatus: 'pending', propSubmitTime: now })
      .where(eq(proposals.id, id))
      .returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('提交提案失败');
    }

    this.logger.log(`提案提交审核: ${id}`);
    return { id, status: 'pending' };
  }

  async approve(id: string): Promise<{ id: string; status: string }> {
    const existing = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('提案不存在');
    }

    if (existing[0].propStatus !== 'pending') {
      throw new ConflictException('仅待审核状态的提案可审批');
    }

    const now = new Date().toISOString();
    const result = await this.db.update(proposals)
      .set({ propStatus: 'approved', propReviewTime: now })
      .where(eq(proposals.id, id))
      .returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('审批操作失败');
    }

    this.logger.log(`提案审核通过: ${id}`);
    return { id, status: 'approved' };
  }

  async reject(
    id: string,
    comment: string,
  ): Promise<{ id: string; status: string }> {
    const existing = await this.db.select().from(proposals).where(eq(proposals.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('提案不存在');
    }

    if (existing[0].propStatus !== 'pending') {
      throw new ConflictException('仅待审核状态的提案可驳回');
    }

    const now = new Date().toISOString();
    const result = await this.db.update(proposals)
      .set({
        propStatus: 'rejected',
        propReviewTime: now,
        propReviewComment: comment || '',
      })
      .where(eq(proposals.id, id))
      .returning({ id: proposals.id });

    if (result.length === 0) {
      throw new BadRequestException('驳回操作失败');
    }

    this.logger.log(`提案审核驳回: ${id}`);
    return { id, status: 'rejected' };
  }

  async getStats(params: {
    orgId?: string;
    electionId?: string;
  }): Promise<ProposalStats> {
    const conditions = this.buildConditions(params);

    const result = conditions.length > 0
      ? await this.db
          .select({
            total: count(),
            pending: sql<number>`count(*) filter (where ${proposals.propStatus} = 'pending')`,
            approved: sql<number>`count(*) filter (where ${proposals.propStatus} = 'approved')`,
            rejected: sql<number>`count(*) filter (where ${proposals.propStatus} = 'rejected')`,
          })
          .from(proposals)
          .where(and(...conditions))
      : await this.db
          .select({
            total: count(),
            pending: sql<number>`count(*) filter (where ${proposals.propStatus} = 'pending')`,
            approved: sql<number>`count(*) filter (where ${proposals.propStatus} = 'approved')`,
            rejected: sql<number>`count(*) filter (where ${proposals.propStatus} = 'rejected')`,
          })
          .from(proposals);

    const row = result[0];
    return {
      total: Number(row?.total ?? 0),
      pending: Number(row?.pending ?? 0),
      approved: Number(row?.approved ?? 0),
      rejected: Number(row?.rejected ?? 0),
    };
  }

  private buildConditions(params: {
    orgId?: string;
    electionId?: string;
    status?: string;
    method?: string;
  }) {
    const conditions = [];
    if (params.orgId) conditions.push(eq(proposals.orgId, params.orgId));
    if (params.electionId) conditions.push(eq(proposals.electionId, params.electionId));
    if (params.status) conditions.push(eq(proposals.propStatus, params.status));
    if (params.method) conditions.push(eq(proposals.propMethod, params.method));
    return conditions;
  }

  private mapProposal(row: typeof proposals.$inferSelect): Proposal {
    return {
      id: row.id,
      orgId: row.orgId || '',
      electionId: row.electionId || '',
      title: row.propTitle || '',
      method: row.propMethod || '',
      creatorId: row.propCreatorId || '',
      status: row.propStatus || 'draft',
      version: row.propVersion ?? 1,
      submitTime: row.propSubmitTime || '',
      reviewerId: row.propReviewerId || '',
      reviewTime: row.propReviewTime || '',
      reviewComment: row.propReviewComment || '',
    };
  }
}
