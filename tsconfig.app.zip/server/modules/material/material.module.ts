import { Module } from '@nestjs/common';
import { CandidateModule } from '../candidate/candidate.module';
import { MaterialService } from './material.service';
import { MaterialController } from './material.controller';

@Module({
  imports: [CandidateModule],
  controllers: [MaterialController],
  providers: [MaterialService],
  exports: [],
})
export class MaterialModule {}
