import {
  Controller,
  Get,
  Query,
  Param,
  Post,
  Put,
  Delete,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { MaterialService } from './material.service';
import type {
  Material,
  MaterialDetail,
  ListResponse,
  ApiResponse,
  MaterialStats,
} from '@shared/api.interface';

@Controller('api/materials')
export class MaterialController {
  constructor(private readonly materialService: MaterialService) {}

  @Get('stats')
  async stats(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
  ): Promise<ApiResponse<MaterialStats>> {
    const data = await this.materialService.getStats({ orgId, electionId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('positionId') positionId?: string,
    @Query('type') type?: string,
    @Query('status') status?: string,
    @Query('electionId') electionId?: string,
    @Query('stage') stage?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Material>>> {
    const data = await this.materialService.list({
      orgId,
      positionId,
      type,
      status,
      electionId,
      stage,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async getById(@Param('id') id: string): Promise<ApiResponse<MaterialDetail>> {
    const data = await this.materialService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: Partial<MaterialDetail> & { orgId?: string; electionId?: string },
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.orgId || !body.electionId) {
      throw new BadRequestException('orgId 和 electionId 不能为空');
    }
    const data = await this.materialService.create(body as Partial<MaterialDetail> & { orgId: string; electionId: string });
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: Partial<MaterialDetail>,
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.materialService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<{ success: boolean }>> {
    const data = await this.materialService.remove(id);
    return { code: 0, data, message: 'success' };
  }

  @Post(':id/review')
  async review(
    @Param('id') id: string,
    @Body() body: { action: string; comment?: string; reviewer?: string },
  ): Promise<ApiResponse<{ id: string; status: string; candidateId?: string }>> {
    if (!body.action) {
      throw new BadRequestException('action 不能为空');
    }
    const data = await this.materialService.review(
      id,
      body.action as 'approve' | 'reject' | 'need_correction',
      body.comment || '',
      body.reviewer || '系统审核员',
    );
    return { code: 0, data, message: 'success' };
  }

  @Post(':id/resubmit')
  async resubmit(
    @Param('id') id: string,
    @Body() body: { submitter?: string },
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    const data = await this.materialService.resubmit(
      id,
      body.submitter || '',
    );
    return { code: 0, data, message: 'success' };
  }
}
