import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, desc, like, count, gte, isNull } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { materials, candidates, voters } from '@server/database/schema';
import type {
  Material,
  MaterialDetail,
  ListResponse,
  MaterialStats,
  MaterialStatus,
} from '@shared/api.interface';

const TERMINAL_STATUSES: MaterialStatus[] = ['approved', 'rejected'];
const REVIEWABLE_STATUSES: MaterialStatus[] = ['submitted', 'resubmitted'];

@Injectable()
export class MaterialService {
  private readonly logger = new Logger(MaterialService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    positionId?: string;
    type?: string;
    status?: string;
    electionId?: string;
    stage?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Material>> {
    const conditions = [];
    if (params.orgId) conditions.push(eq(materials.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(materials.electionId, params.electionId));
    if (params.positionId)
      conditions.push(eq(materials.matPositionId, params.positionId));
    if (params.type) conditions.push(eq(materials.matType, params.type));
    if (params.status)
      conditions.push(eq(materials.matStatus, params.status));
    if (params.stage) conditions.push(eq(materials.matStage, params.stage));

    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const [totalResult, rows] = await Promise.all([
      this.db.select({ count: count() }).from(materials).where(where),
      this.db
        .select()
        .from(materials)
        .where(where)
        .orderBy(desc(materials.matSubmitTime))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

     const total = Number(totalResult[0]?.count ?? 0);
      const items: Material[] = rows.map((r) => ({
        id: r.id,
        orgId: r.orgId,
        electionId: r.electionId,
        applicantId: r.matApplicantId || '',
        applicant: r.matSubmitter || r.matApplicantId || '',
        position: r.matPositionId || '',
       type: r.matType || '',
      submitter: r.matSubmitter || '',
      submitTime: r.matSubmitTime || '',
      status: (r.matStatus as MaterialStatus) || 'submitted',
      reviewer: r.matReviewer || '',
      stage: r.matStage || '',
    }));

    return { items, total };
  }

  async getById(id: string): Promise<MaterialDetail> {
    const rows = await this.db
      .select()
      .from(materials)
      .where(eq(materials.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('材料记录不存在');
    }
    const r = rows[0];
     return {
       id: r.id,
       orgId: r.orgId,
       electionId: r.electionId,
       applicantId: r.matApplicantId || '',
       applicant: r.matSubmitter || r.matApplicantId || '',
      position: r.matPositionId || '',
      type: r.matType || '',
      submitter: r.matSubmitter || '',
      submitTime: r.matSubmitTime || '',
      status: (r.matStatus as MaterialStatus) || 'submitted',
      reviewer: r.matReviewer || '',
      stage: r.matStage || '',
      applicantPhone: r.matSubmitterPhone || '',
      content: r.matNote || '',
      reviewTime: r.matReviewTime || '',
      reviewComment: r.matReviewComment || '',
      candidateId: r.matCandidateId || '',
      submitterPhone: r.matSubmitterPhone || '',
      note: r.matNote || '',
    };
  }

  async create(
    data: Partial<MaterialDetail> & { orgId: string; electionId: string },
  ): Promise<{ id: string }> {
    if (!data.orgId || !data.electionId) {
      throw new BadRequestException('orgId 和 electionId 不能为空');
    }
    const inserted = await this.db
      .insert(materials)
      .values({
        orgId: data.orgId,
        electionId: data.electionId,
        matPositionId: data.position || '',
        matApplicantId: data.applicant || '',
        matType: data.type || '',
        matSubmitter: data.submitter || '',
        matSubmitterPhone: data.applicantPhone || '',
        matNote: data.content || data.note || '',
        matStage: data.stage || '',
        matStatus: 'submitted',
        matSubmitTime: new Date().toISOString(),
      })
      .returning({ id: materials.id });
    if (inserted.length === 0) {
      throw new BadRequestException('创建材料记录失败');
    }
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    data: Partial<MaterialDetail>,
  ): Promise<{ id: string }> {
    const patch: Partial<typeof materials.$inferInsert> = {};
    if (data.applicant !== undefined) patch.matApplicantId = data.applicant;
    if (data.applicantPhone !== undefined)
      patch.matSubmitterPhone = data.applicantPhone;
    if (data.position !== undefined) patch.matPositionId = data.position;
    if (data.type !== undefined) patch.matType = data.type;
    if (data.content !== undefined) patch.matNote = data.content;
    if (data.submitter !== undefined) patch.matSubmitter = data.submitter;
    if (data.stage !== undefined) patch.matStage = data.stage;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(materials)
      .set(patch)
      .where(eq(materials.id, id))
      .returning({ id: materials.id });
    if (updated.length === 0) {
      throw new NotFoundException('材料记录不存在');
    }
    return { id };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const deleted = await this.db
      .delete(materials)
      .where(eq(materials.id, id))
      .returning({ id: materials.id });
    if (deleted.length === 0) {
      throw new NotFoundException('材料记录不存在');
    }
    return { success: true };
  }

  async review(
    id: string,
    action: 'approve' | 'reject' | 'need_correction',
    comment: string,
    reviewer: string,
  ): Promise<{ id: string; status: string; candidateId?: string }> {
    if (!action) {
      throw new BadRequestException('审核操作不能为空');
    }
    const validActions: Array<'approve' | 'reject' | 'need_correction'> = [
      'approve',
      'reject',
      'need_correction',
    ];
    if (!validActions.includes(action)) {
      throw new BadRequestException(
        '审核操作必须是 approve / reject / need_correction 之一',
      );
    }

    const existing = await this.getById(id);
    const currentStatus = existing.status as MaterialStatus;
    if (TERMINAL_STATUSES.includes(currentStatus)) {
      throw new BadRequestException(
        `材料已处于终态（${currentStatus}），不可再次审核`,
      );
    }

    const nowStr = new Date().toISOString();
    const nextStatus: MaterialStatus =
      action === 'approve'
        ? 'approved'
        : action === 'reject'
          ? 'rejected'
          : 'needs_correction';

    let candidateId: string | undefined;

    await this.db.transaction(async (tx) => {
      await tx
        .update(materials)
        .set({
          matStatus: nextStatus,
          matReviewer: reviewer,
          matReviewTime: nowStr,
          matReviewComment: comment,
        })
        .where(eq(materials.id, id));

       if (action === 'approve' && !existing.candidateId) {
         const cand = await tx
           .insert(candidates)
           .values({
             orgId: existing.orgId,
             electionId: existing.electionId,
             candName: existing.applicant,
             candPositionId: existing.position,
             candSource: existing.type === '组织推荐' ? 'org_recommend' : 'self',
             candPhone: existing.applicantPhone,
             candR1: 'approved',
             candR1Reviewer: reviewer,
             candR1Time: nowStr,
             candStatus: 'reviewing',
           })
           .returning({ id: candidates.id });
         if (cand.length > 0) {
           candidateId = cand[0].id;
           await tx
             .update(materials)
             .set({ matCandidateId: candidateId })
             .where(eq(materials.id, id));
         }
       }
       await tx
         .update(voters)
         .set({
           votMaterialStatus:
             action === 'approve'
               ? 'approved'
               : action === 'reject'
                 ? 'rejected'
                 : 'needs_correction',
         })
         .where(
           and(
             eq(voters.orgId, existing.orgId),
             eq(voters.electionId, existing.electionId),
             eq(voters.votName, existing.applicant),
           ),
         );
    });

    this.logger.log(
      `材料审核: id=${id}, action=${action}, newStatus=${nextStatus}, reviewer=${reviewer}`,
    );

    return {
      id,
      status: nextStatus,
      candidateId,
    };
  }

  async resubmit(
    id: string,
    submitter: string,
  ): Promise<{ id: string; status: string }> {
    const existing = await this.getById(id);
    if (
      existing.status !== 'needs_correction' &&
      existing.status !== 'rejected'
    ) {
      throw new BadRequestException(
        '只有需补正或已驳回状态的材料才能重新提交',
      );
    }
    await this.db
      .update(materials)
      .set({
        matStatus: 'resubmitted',
        matSubmitter: submitter || existing.submitter,
        matSubmitTime: new Date().toISOString(),
      })
      .where(eq(materials.id, id));

    return { id, status: 'resubmitted' };
  }

  async getStats(params: {
    orgId?: string;
    electionId?: string;
  }): Promise<MaterialStats> {
    const conditions = [];
    if (params.orgId) conditions.push(eq(materials.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(materials.electionId, params.electionId));
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const rows = await this.db
      .select({ status: materials.matStatus, count: count() })
      .from(materials)
      .where(where)
      .groupBy(materials.matStatus);

    const stats: MaterialStats = {
      total: 0,
      submitted: 0,
      needsCorrection: 0,
      resubmitted: 0,
      approved: 0,
      rejected: 0,
    };
    for (const r of rows) {
      const s = r.status || 'submitted';
      const c = Number(r.count);
      stats.total += c;
      if (s === 'submitted') stats.submitted = c;
      else if (s === 'needs_correction') stats.needsCorrection = c;
      else if (s === 'resubmitted') stats.resubmitted = c;
      else if (s === 'approved') stats.approved = c;
      else if (s === 'rejected') stats.rejected = c;
    }
    return stats;
  }
}
