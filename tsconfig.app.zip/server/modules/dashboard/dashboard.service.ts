import { Injectable, Logger, Inject } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, asc, desc, sql } from 'drizzle-orm';
import {
  elections,
  electionStages,
  voters,
  candidates,
  announcements,
  proposals,
  positions,
  roster,
  materials,
  archives,
  organizations,
  stageTemplates,
} from '@server/database/schema';
import type { WorkstationData } from '@shared/api.interface';

export interface DashboardOverview {
  currentTerm: string;
  electionDate: string;
  daysToElection: number;
  voterCount: number;
  candidateCount: number;
  publishedAnnouncementCount: number;
  currentStage: {
    stageKey: string;
    stageName: string;
    status: string;
  } | null;
}

export interface ReviewRoundStat {
  round: number;
  name: string;
  pendingCount: number;
  passCount: number;
  rejectCount: number;
  status: 'completed' | 'active' | 'pending';
}

const ROUND_CONFIG: Array<{ round: number; name: string; field: 'candR1' | 'candR2' | 'candR3' | 'candR4' }> = [
  { round: 1, name: '材料完整性', field: 'candR1' },
  { round: 2, name: '镇级初审', field: 'candR2' },
  { round: 3, name: '区级联审', field: 'candR3' },
  { round: 4, name: '党委考察', field: 'candR4' },
];

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getWorkstation(orgId: string): Promise<WorkstationData> {
    const orgSlug = orgId || '';

    const [orgInfo, electionList, proposalList, positionList, rosterList, statsResult] =
      await Promise.all([
        this.getOrgInfo(orgSlug),
        this.getElections(orgSlug),
        this.getProposals(orgSlug),
        this.getPositions(orgSlug),
        this.getRoster(orgSlug),
        this.getWorkstationStats(orgSlug),
      ]);

    const currentElection = electionList.find((e) => e.status === 'in_progress') || null;
    const stages = currentElection
      ? await this.getStagesForWorkstation(currentElection.id)
      : [];

    return {
      orgInfo,
      currentElection,
      elections: electionList,
      stages,
      proposals: proposalList,
      positions: positionList,
      roster: rosterList,
      stats: statsResult,
    };
  }

  private async getOrgInfo(orgSlug: string) {
    const rows = await this.db
      .select({ name: organizations.name, town: organizations.town, type: organizations.type })
      .from(organizations)
      .where(eq(organizations.slug, orgSlug))
      .limit(1);
    return rows[0] || { name: '', town: '', type: '' };
  }

  private async getElections(orgSlug: string) {
    const rows = await this.db
      .select()
      .from(elections)
      .where(eq(elections.orgId, orgSlug))
      .orderBy(desc(elections.elTerm));
    return rows.map((row) => ({
      id: row.elId || '',
      name: row.elName || '',
      term: row.elTerm || '',
      status: row.elStatus || '',
      method: row.elMethod || '',
      electionDate: row.elElectionDate ? new Date(row.elElectionDate).toISOString().split('T')[0] : '',
    }));
  }

  private async getProposals(orgSlug: string) {
    const rows = await this.db
      .select()
      .from(proposals)
      .where(eq(proposals.orgId, orgSlug))
      .orderBy(desc(proposals.createdAt))
      .limit(10);
    return rows.map((row) => ({
      id: row.id,
      title: row.propTitle || '',
      status: (row.propStatus || 'draft') as WorkstationData['proposals'][number]['status'],
      version: row.propVersion || 1,
    }));
  }

  private async getPositions(orgSlug: string) {
    const current = await this.db
      .select()
      .from(elections)
      .where(and(eq(elections.orgId, orgSlug), eq(elections.elStatus, 'in_progress')))
      .limit(1);
    if (current.length === 0) return [];

    const rows = await this.db
      .select()
      .from(positions)
      .where(eq(positions.electionId, current[0].elId || ''))
      .orderBy(positions.posType);
    return rows.map((row) => ({
      id: row.id,
      type: (row.posType || '') as WorkstationData['positions'][number]['type'],
      quota: row.posQuota || 1,
      status: (row.posStatus || 'active') as WorkstationData['positions'][number]['status'],
    }));
  }

  private async getRoster(orgSlug: string) {
    const rows = await this.db
      .select()
      .from(roster)
      .where(and(eq(roster.orgId, orgSlug), eq(roster.rosIsActive, true)))
      .orderBy(roster.rosPosition);
    return rows.map((row) => ({
      id: row.id,
      position: row.rosPosition || '',
      name: row.rosName || '',
      phone: row.rosPhone || '',
      term: row.rosTerm || '',
    }));
  }

  private async getWorkstationStats(orgSlug: string) {
    const current = await this.db
      .select({ elId: elections.elId })
      .from(elections)
      .where(and(eq(elections.orgId, orgSlug), eq(elections.elStatus, 'in_progress')))
      .limit(1);
    const electionId = current[0]?.elId || '';

    const [matCount, candCount, annCount, archCount] = await Promise.all([
      electionId
        ? this.db
            .select({ count: count() })
            .from(materials)
            .where(and(eq(materials.electionId, electionId), eq(materials.matStatus, 'submitted')))
        : Promise.resolve([{ count: '0' }]),
      electionId
        ? this.db
            .select({ count: count() })
            .from(candidates)
            .where(and(eq(candidates.electionId, electionId), eq(candidates.candR1, '通过')))
        : Promise.resolve([{ count: '0' }]),
      electionId
        ? this.db
            .select({ count: count() })
            .from(announcements)
            .where(and(eq(announcements.orgId, orgSlug), eq(announcements.annStatus, 'published')))
        : Promise.resolve([{ count: '0' }]),
      this.db
        .select({ count: count() })
        .from(archives)
        .where(eq(archives.orgId, orgSlug)),
    ]);

    return {
      pendingMaterials: Number(matCount[0]?.count ?? 0),
      passedCandidates: Number(candCount[0]?.count ?? 0),
      publishedAnnouncements: Number(annCount[0]?.count ?? 0),
      archives: Number(archCount[0]?.count ?? 0),
    };
  }

  private async getStagesForWorkstation(electionId: string) {
    const rows = await this.db
      .select()
      .from(electionStages)
      .where(eq(electionStages.electionId, electionId))
      .orderBy(asc(electionStages.stageOrder));

    if (rows.length > 0) {
      return rows.map((row) => ({
        stageKey: row.stageKey || '',
        stageName: row.stageName || '',
        status: (row.stageStatus || '未开始') as WorkstationData['stages'][number]['status'],
        planStart: row.stageStartDate ? String(row.stageStartDate) : '',
        planEnd: row.stageEndDate ? String(row.stageEndDate) : '',
        order: row.stageOrder || 0,
      }));
    }

    const tplRows = await this.db
      .select()
      .from(stageTemplates)
      .orderBy(asc(stageTemplates.stOrder));

    return tplRows.map((row) => ({
      stageKey: row.stKey || '',
      stageName: row.stName || '',
      status: '未开始' as WorkstationData['stages'][number]['status'],
      planStart: '',
      planEnd: '',
      order: row.stOrder || 0,
    }));
  }

  async getOverview(
    orgId?: string,
    electionId?: string,
  ): Promise<DashboardOverview> {
    const emptyResult: DashboardOverview = {
      currentTerm: '',
      electionDate: '',
      daysToElection: 0,
      voterCount: 0,
      candidateCount: 0,
      publishedAnnouncementCount: 0,
      currentStage: null,
    };

    const orgSlug = orgId || '';
    const election = electionId
      ? await this.getElectionById(electionId)
      : orgSlug
        ? await this.getCurrentElection(orgSlug)
        : null;

    const filterOrg = election ? election.orgId : orgSlug;
    const filterElection = election ? election.id : '';

    const [voterCount, candidateCount, publishedAnnouncementCount, stages] =
      await Promise.all([
        this.countVoters(filterOrg, filterElection),
        this.countCandidates(filterOrg, filterElection),
        this.countPublishedAnnouncements(filterOrg),
        election ? this.getStages(election.id) : Promise.resolve([]),
      ]);

    const currentStage = this.findCurrentStage(stages);

    return {
      currentTerm: election?.term || '',
      electionDate: election?.electionDate || '',
      daysToElection: election?.electionDate ? this.calcDaysToElection(election.electionDate) : 0,
      voterCount,
      candidateCount,
      publishedAnnouncementCount,
      currentStage,
    };
  }

  async getReviewRounds(electionId: string): Promise<ReviewRoundStat[]> {
    if (!electionId) {
      return ROUND_CONFIG.map((cfg) => ({
        round: cfg.round,
        name: cfg.name,
        pendingCount: 0,
        passCount: 0,
        rejectCount: 0,
        status: 'pending' as const,
      }));
    }

    const rows = await this.db
      .select({
        candR1: candidates.candR1,
        candR2: candidates.candR2,
        candR3: candidates.candR3,
        candR4: candidates.candR4,
      })
      .from(candidates)
      .where(eq(candidates.electionId, electionId));

    return ROUND_CONFIG.map((roundCfg) => {
      let pendingCount = 0;
      let passCount = 0;
      let rejectCount = 0;

      for (const row of rows) {
        const value = row[roundCfg.field] || '';
        if (!value || value === 'pending' || value === '待审核') {
          pendingCount += 1;
        } else if (value === 'approved' || value === 'pass' || value === '通过' || value === '已通过') {
          passCount += 1;
        } else if (value === 'rejected' || value === 'fail' || value === '驳回' || value === '未通过' || value === '不通过') {
          rejectCount += 1;
        } else {
          pendingCount += 1;
        }
      }

      let status: ReviewRoundStat['status'] = 'pending';
      if (pendingCount === 0 && passCount > 0) {
        status = 'completed';
      } else if (passCount > 0 || rejectCount > 0) {
        status = 'active';
      }

      return {
        round: roundCfg.round,
        name: roundCfg.name,
        pendingCount,
        passCount,
        rejectCount,
        status,
      };
    });
  }

  private async getElectionById(id: string) {
    const rows = await this.db.select().from(elections).where(eq(elections.elId, id)).limit(1);
    if (rows.length === 0) return null;
    const row = rows[0];
    return {
      id: row.elId || '',
      term: row.elTerm || '',
      electionDate: row.elElectionDate || '',
      orgId: row.orgId || '',
    };
  }

  private async getCurrentElection(orgSlug: string) {
    const rows = await this.db
      .select()
      .from(elections)
      .where(and(eq(elections.orgId, orgSlug), eq(elections.elStatus, 'in_progress')))
      .orderBy(elections.elElectionDate)
      .limit(1);
    if (rows.length === 0) return null;
    const row = rows[0];
    return {
      id: row.elId || '',
      term: row.elTerm || '',
      electionDate: row.elElectionDate || '',
      orgId: row.orgId || '',
    };
  }

  private async countVoters(orgId: string, electionId: string): Promise<number> {
    const conditions = [];
    if (orgId) conditions.push(eq(voters.orgId, orgId));
    if (electionId) conditions.push(eq(voters.electionId, electionId));
    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const result = await this.db.select({ count: count() }).from(voters).where(where);
    return Number(result[0]?.count ?? 0);
  }

  private async countCandidates(orgId: string, electionId: string): Promise<number> {
    const conditions = [];
    if (orgId) conditions.push(eq(candidates.orgId, orgId));
    if (electionId) conditions.push(eq(candidates.electionId, electionId));
    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const result = await this.db.select({ count: count() }).from(candidates).where(where);
    return Number(result[0]?.count ?? 0);
  }

  private async countPublishedAnnouncements(orgId: string): Promise<number> {
    if (!orgId) return 0;
    const result = await this.db
      .select({ count: count() })
      .from(announcements)
      .where(and(
        eq(announcements.orgId, orgId),
        eq(announcements.annStatus, '已发布'),
      ));
    return Number(result[0]?.count ?? 0);
  }

  private async getStages(electionId: string) {
    const rows = await this.db
      .select()
      .from(electionStages)
      .where(eq(electionStages.electionId, electionId))
      .orderBy(asc(electionStages.stageOrder));

    return rows.map((row) => ({
      id: row.id,
      stageKey: row.stageKey || '',
      stageName: row.stageName || '',
      status: row.stageStatus || '未开始',
    }));
  }

  private findCurrentStage(stages: Array<{ stageKey: string; stageName: string; status: string }>) {
    if (stages.length === 0) return null;

    const active = stages.find((s) => s.status === 'in_progress' || s.status === '办理中');
    if (active) {
      return { stageKey: active.stageKey, stageName: active.stageName, status: active.status };
    }

    const pending = stages.find((s) => s.status === 'pending' || s.status === '未开始');
    if (pending) {
      return { stageKey: pending.stageKey, stageName: pending.stageName, status: pending.status };
    }

    const last = stages[stages.length - 1];
    return { stageKey: last.stageKey, stageName: last.stageName, status: last.status };
  }

  private calcDaysToElection(electionDate: string): number {
    if (!electionDate) return 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(electionDate);
    target.setHours(0, 0, 0, 0);
    const diffMs = target.getTime() - today.getTime();
    return Math.round(diffMs / (1000 * 60 * 60 * 24));
  }
}
