import { Controller, Get, Query } from '@nestjs/common';
import { DashboardService } from './dashboard.service';
import type { ApiResponse, WorkstationData } from '@shared/api.interface';
import type {
  DashboardOverview,
  ReviewRoundStat,
} from './dashboard.service';

@Controller('api/dashboard')
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Get('workstation')
  async getWorkstation(
    @Query('orgId') orgId: string,
  ): Promise<ApiResponse<WorkstationData>> {
    const data = await this.dashboardService.getWorkstation(orgId);
    return {
      code: 0,
      data,
      message: 'success',
    };
  }

  @Get('overview')
  async getOverview(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
  ): Promise<ApiResponse<DashboardOverview>> {
    const data = await this.dashboardService.getOverview(orgId, electionId);
    return {
      code: 0,
      data,
      message: 'success',
    };
  }

  @Get('review-rounds')
  async getReviewRounds(
    @Query('electionId') electionId: string,
  ): Promise<ApiResponse<ReviewRoundStat[]>> {
    const data = await this.dashboardService.getReviewRounds(electionId);
    return {
      code: 0,
      data,
      message: 'success',
    };
  }
}
