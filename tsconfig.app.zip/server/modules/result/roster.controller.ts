import {
  Controller,
  Get,
  Query,
  Post,
  Put,
  Delete,
  Body,
  Param,
  BadRequestException,
} from '@nestjs/common';
import { ResultService } from './result.service';
import type {
  RosterItem,
  RosterCreateDto,
  RosterUpdateDto,
  RosterStats,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/roster')
export class RosterController {
  constructor(private readonly resultService: ResultService) {}

  @Get('stats')
  async getStats(
    @Query('orgId') orgId?: string,
  ): Promise<ApiResponse<RosterStats>> {
    const data = await this.resultService.getRosterStats({ orgId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('position') position?: string,
    @Query('status') status?: string,
    @Query('isActive') isActive?: string,
    @Query('term') term?: string,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<RosterItem>>> {
    const data = await this.resultService.listRoster({
      orgId,
      position,
      status,
      isActive: isActive !== undefined ? isActive === 'true' : undefined,
      term,
      search,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async getById(
    @Param('id') id: string,
  ): Promise<ApiResponse<RosterItem>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.getRosterById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: RosterCreateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.name || !body.position) {
      throw new BadRequestException('姓名和岗位不能为空');
    }
    const data = await this.resultService.createRoster(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: RosterUpdateDto,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.updateRoster(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.removeRoster(id);
    return { code: 0, data, message: 'success' };
  }
}
