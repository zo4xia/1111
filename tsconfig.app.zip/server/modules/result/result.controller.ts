import {
  Controller,
  Get,
  Query,
  Post,
  Put,
  Patch,
  Delete,
  Body,
  Param,
  BadRequestException,
} from '@nestjs/common';
import { ResultService } from './result.service';
import type {
  ElectionResultOverview,
  ElectionResult,
  ElectionResultCreateDto,
  ElectionResultUpdateDto,
  ElectionResultFilingDto,
  ElectionResultHandoverDto,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/election-results')
export class ResultController {
  constructor(private readonly resultService: ResultService) {}

  @Get('overview')
  async getOverview(
    @Query('electionId') electionId: string,
    @Query('orgId') orgId?: string,
  ): Promise<ApiResponse<ElectionResultOverview>> {
    if (!electionId) {
      throw new BadRequestException('electionId 不能为空');
    }
    const data = await this.resultService.getOverview({ electionId, orgId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
    @Query('position') position?: string,
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<ElectionResult>>> {
    const data = await this.resultService.list({
      orgId,
      electionId,
      position,
      status,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async getById(
    @Param('id') id: string,
  ): Promise<ApiResponse<ElectionResult>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: ElectionResultCreateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.electionId || !body.position) {
      throw new BadRequestException('electionId 和 position 不能为空');
    }
    const data = await this.resultService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: ElectionResultUpdateDto,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.resultService.remove(id);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/filing')
  async filing(
    @Param('id') id: string,
    @Body() body: ElectionResultFilingDto,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    if (!body.filingStatus) {
      throw new BadRequestException('filingStatus 不能为空');
    }
    const data = await this.resultService.filing(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/handover')
  async handover(
    @Param('id') id: string,
    @Body() body: ElectionResultHandoverDto,
  ): Promise<ApiResponse<{ success: boolean }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    if (!body.handoverStatus) {
      throw new BadRequestException('handoverStatus 不能为空');
    }
    const data = await this.resultService.handover(id, body);
    return { code: 0, data, message: 'success' };
  }
}
