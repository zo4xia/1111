import {
  Injectable,
  Logger,
  BadRequestException,
  NotFoundException,
  Inject,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count, sql } from 'drizzle-orm';
import { electionResults, roster, candidates } from '@server/database/schema';
import type {
  ElectionResultOverview,
  ElectionResult,
  ElectionResultCandidate,
  ElectionResultCreateDto,
  ElectionResultUpdateDto,
  ElectionResultFilingDto,
  ElectionResultHandoverDto,
  RosterItem,
  RosterCreateDto,
  RosterUpdateDto,
  RosterStats,
  ListResponse,
} from '@shared/api.interface';

const POSITION_QUOTAS: Record<string, number> = {
  主任: 1,
  副主任: 2,
  委员: 3,
};

@Injectable()
export class ResultService {
  private readonly logger = new Logger(ResultService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ========== 内部映射辅助 ==========

  private mapElectionResult(row: typeof electionResults.$inferSelect): ElectionResult {
    return {
      id: row.id,
      orgId: row.orgId,
      orgName: row.orgName ?? '',
      electionId: row.electionId,
      electionDate: row.erElectionDate ?? '',
      position: row.erPosition ?? '',
      winnerName: row.erWinnerName ?? '',
      votes: row.erVotes ?? 0,
      eligibleVoters: row.erEligibleVoters ?? 0,
      actualVoters: row.erActualVoters ?? 0,
      validVotes: row.erValidVotes ?? 0,
      invalidVotes: row.erInvalidVotes ?? 0,
      turnout: row.erTurnout ?? '',
      resultAnnCode: row.erResultAnnCode ?? '',
      filingStatus: row.erFilingStatus ?? '未备案',
      filingTime: row.erFilingTime ?? '',
      handoverStatus: row.erHandoverStatus ?? '未交接',
      note: row.erNote ?? '',
      candidates: [],
    };
  }

  private mapRosterItem(row: typeof roster.$inferSelect): RosterItem {
    return {
      id: row.id,
      orgId: row.orgId,
      position: row.rosPosition ?? '',
      name: row.rosName ?? '',
      phone: row.rosPhone ?? '',
      term: row.rosTerm ?? '',
      yearStart: row.rosYearStart !== null ? String(row.rosYearStart) : '',
      yearEnd: row.rosYearEnd !== null ? String(row.rosYearEnd) : '',
      status: row.rosStatus ?? '',
      isActive: row.rosIsActive ?? false,
      sessionNo: row.rosSessionNo ?? '',
      note: row.rosNote ?? '',
    };
  }

  // ========== 选举结果 ==========

  async list(params: {
    orgId?: string;
    electionId?: string;
    position?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<ElectionResult>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;
    const offset = (page - 1) * pageSize;

    const conditions = [];
    if (params.orgId) conditions.push(eq(electionResults.orgId, params.orgId));
    if (params.electionId) conditions.push(eq(electionResults.electionId, params.electionId));
    if (params.position) conditions.push(eq(electionResults.erPosition, params.position));
    if (params.status) conditions.push(eq(electionResults.erFilingStatus, params.status));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [rows, totalResult] = await Promise.all([
      this.db
        .select()
        .from(electionResults)
        .where(where)
        .orderBy(desc(electionResults.erElectionDate), electionResults.erPosition)
        .limit(pageSize)
        .offset(offset),
      this.db.select({ count: count() }).from(electionResults).where(where),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: ElectionResult[] = rows.map((row) => this.mapElectionResult(row));

    return { items, total };
  }

  async getById(id: string): Promise<ElectionResult> {
    const rows = await this.db
      .select()
      .from(electionResults)
      .where(eq(electionResults.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('选举结果不存在');
    }

    const result = this.mapElectionResult(rows[0]);

    // 从 candidates 表按 electionId + position 过滤
    const candidateRows = await this.db
      .select()
      .from(candidates)
      .where(
        and(
          eq(candidates.electionId, result.electionId),
          eq(candidates.candPositionId, result.position),
        ),
      )
      .orderBy(desc(candidates.candVotes));

    const totalVotes = candidateRows.reduce(
      (sum: number, c) => sum + (c.candVotes ?? 0),
      0,
    );
    const quota = POSITION_QUOTAS[result.position] || 1;

    const resultCandidates: ElectionResultCandidate[] = candidateRows.map(
      (c, idx: number) => ({
        id: c.id,
        name: c.candName,
        votes: c.candVotes ?? 0,
        voteRate:
          totalVotes > 0
            ? `${(((c.candVotes ?? 0) / totalVotes) * 100).toFixed(1)}%`
            : '0.0%',
        isElected: idx < quota && (c.candVotes ?? 0) > 0,
      }),
    );

    result.candidates = resultCandidates;
    return result;
  }

  async create(dto: ElectionResultCreateDto): Promise<{ id: string }> {
    if (!dto.electionId || !dto.position) {
      throw new BadRequestException('选举ID和岗位不能为空');
    }

    const maxVotes =
      dto.candidateVotes?.reduce((max, cv) => Math.max(max, cv.votes), 0) || 0;

    const inserted = await this.db
      .insert(electionResults)
      .values({
        orgId: dto.orgId || '',
        electionId: dto.electionId,
        erPosition: dto.position,
        erWinnerName: dto.winnerName || '',
        erVotes: maxVotes,
        erValidVotes: dto.validVotes || 0,
        erInvalidVotes: dto.invalidVotes || 0,
        erActualVoters: dto.actualVoters || 0,
        erResultAnnCode: dto.resultAnnCode || '',
        erFilingStatus: '未备案',
        erHandoverStatus: '未交接',
        erNote: dto.note || '',
      })
      .returning({ id: electionResults.id });

    if (inserted.length === 0) {
      throw new BadRequestException('创建选举结果失败');
    }

    // 更新候选人票数和当选状态
    if (dto.candidateVotes && dto.candidateVotes.length > 0) {
      const quota = POSITION_QUOTAS[dto.position] || 1;
      const sorted = [...dto.candidateVotes].sort((a, b) => b.votes - a.votes);
      const electedIds = new Set(
        sorted
          .slice(0, quota)
          .filter((c) => c.votes > 0)
          .map((c) => c.candidateId),
      );

      for (const cv of dto.candidateVotes) {
        const status = electedIds.has(cv.candidateId) ? '当选' : '落选';
        await this.db
          .update(candidates)
          .set({
            candVotes: cv.votes,
            candStatus: status,
          })
          .where(eq(candidates.id, cv.candidateId));
      }
    }

    return { id: inserted[0].id };
  }

  async update(
    id: string,
    dto: ElectionResultUpdateDto,
  ): Promise<{ success: boolean }> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }

    const patch: Partial<typeof electionResults.$inferInsert> = {};
    if (dto.position !== undefined) patch.erPosition = dto.position;
    if (dto.winnerName !== undefined) patch.erWinnerName = dto.winnerName;
    if (dto.votes !== undefined) patch.erVotes = dto.votes;
    if (dto.validVotes !== undefined) patch.erValidVotes = dto.validVotes;
    if (dto.invalidVotes !== undefined) patch.erInvalidVotes = dto.invalidVotes;
    if (dto.actualVoters !== undefined) patch.erActualVoters = dto.actualVoters;
    if (dto.eligibleVoters !== undefined)
      patch.erEligibleVoters = dto.eligibleVoters;
    if (dto.resultAnnCode !== undefined) patch.erResultAnnCode = dto.resultAnnCode;
    if (dto.note !== undefined) patch.erNote = dto.note;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(electionResults)
      .set(patch)
      .where(eq(electionResults.id, id))
      .returning({ id: electionResults.id });

    if (updated.length === 0) {
      throw new NotFoundException('选举结果不存在');
    }

    return { success: true };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }

    const deleted = await this.db
      .delete(electionResults)
      .where(eq(electionResults.id, id))
      .returning({ id: electionResults.id });

    if (deleted.length === 0) {
      throw new NotFoundException('选举结果不存在');
    }

    return { success: true };
  }

  async filing(
    id: string,
    dto: ElectionResultFilingDto,
  ): Promise<{ success: boolean }> {
    if (!id || !dto.filingStatus) {
      throw new BadRequestException('id 和 filingStatus 不能为空');
    }

    const patch: Partial<typeof electionResults.$inferInsert> = {
      erFilingStatus: dto.filingStatus,
    };

    if (dto.filingTime !== undefined) {
      patch.erFilingTime = dto.filingTime;
    } else if (dto.filingStatus === '已备案') {
      patch.erFilingTime = new Date().toISOString().slice(0, 10);
    }

    const updated = await this.db
      .update(electionResults)
      .set(patch)
      .where(eq(electionResults.id, id))
      .returning({ id: electionResults.id });

    if (updated.length === 0) {
      throw new NotFoundException('选举结果不存在');
    }

    return { success: true };
  }

  async handover(
    id: string,
    dto: ElectionResultHandoverDto,
  ): Promise<{ success: boolean }> {
    if (!id || !dto.handoverStatus) {
      throw new BadRequestException('id 和 handoverStatus 不能为空');
    }

    const updated = await this.db
      .update(electionResults)
      .set({ erHandoverStatus: dto.handoverStatus })
      .where(eq(electionResults.id, id))
      .returning({ id: electionResults.id });

    if (updated.length === 0) {
      throw new NotFoundException('选举结果不存在');
    }

    return { success: true };
  }

  async getOverview(params: {
    electionId: string;
    orgId?: string;
  }): Promise<ElectionResultOverview> {
    if (!params.electionId) {
      throw new BadRequestException('electionId 不能为空');
    }

    const conditions = [eq(electionResults.electionId, params.electionId)];
    if (params.orgId) {
      conditions.push(eq(electionResults.orgId, params.orgId));
    }
    const where = and(...conditions);

    // 聚合：日期取最新，选民/参选取最大值，有效/废票按岗位求和
    const result = await this.db
      .select({
        electionDate: sql<string>`MAX(${electionResults.erElectionDate})`,
        eligibleVoters: sql<number>`COALESCE(MAX(${electionResults.erEligibleVoters}), 0)`,
        actualVoters: sql<number>`COALESCE(MAX(${electionResults.erActualVoters}), 0)`,
        validVotes: sql<number>`COALESCE(SUM(${electionResults.erValidVotes}), 0)`,
        invalidVotes: sql<number>`COALESCE(SUM(${electionResults.erInvalidVotes}), 0)`,
      })
      .from(electionResults)
      .where(where);

    const row = result[0];
    const eligibleVoters = Number(row?.eligibleVoters) || 0;
    const actualVoters = Number(row?.actualVoters) || 0;
    const validVotes = Number(row?.validVotes) || 0;
    const invalidVotes = Number(row?.invalidVotes) || 0;
    const turnoutRaw =
      eligibleVoters > 0 ? (actualVoters / eligibleVoters) * 100 : 0;

    return {
      electionDate: row?.electionDate ?? '',
      eligibleVoters,
      actualVoters,
      validVotes,
      invalidVotes,
      turnout: `${turnoutRaw.toFixed(1)}%`,
    };
  }

  // ========== 花名册 ==========

  async listRoster(params: {
    orgId?: string;
    position?: string;
    status?: string;
    isActive?: boolean;
    term?: string;
    search?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<RosterItem>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 100;
    const offset = (page - 1) * pageSize;

    const conditions = [];
    if (params.orgId) conditions.push(eq(roster.orgId, params.orgId));
    if (params.position) conditions.push(eq(roster.rosPosition, params.position));
    if (params.status) conditions.push(eq(roster.rosStatus, params.status));
    if (params.isActive !== undefined)
      conditions.push(eq(roster.rosIsActive, params.isActive));
    if (params.term) conditions.push(eq(roster.rosSessionNo, params.term));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [rows, totalResult] = await Promise.all([
      this.db
        .select()
        .from(roster)
        .where(where)
        .orderBy(desc(roster.rosSessionNo), roster.rosPosition)
        .limit(pageSize)
        .offset(offset),
      this.db.select({ count: count() }).from(roster).where(where),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    let items: RosterItem[] = rows.map((row) => this.mapRosterItem(row));

    if (params.search) {
      const keyword = params.search.toLowerCase();
      items = items.filter(
        (item) =>
          item.name.toLowerCase().includes(keyword) ||
          item.position.toLowerCase().includes(keyword) ||
          item.phone.toLowerCase().includes(keyword),
      );
    }

    return { items, total };
  }

  async getRosterById(id: string): Promise<RosterItem> {
    const rows = await this.db
      .select()
      .from(roster)
      .where(eq(roster.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('花名册记录不存在');
    }

    return this.mapRosterItem(rows[0]);
  }

  async createRoster(dto: RosterCreateDto): Promise<{ id: string }> {
    if (!dto.name || !dto.position) {
      throw new BadRequestException('姓名和岗位不能为空');
    }

    const inserted = await this.db
      .insert(roster)
      .values({
        orgId: dto.orgId || '',
        rosPosition: dto.position,
        rosName: dto.name,
        rosPhone: dto.phone || '',
        rosTerm: dto.term || '',
        rosYearStart: dto.yearStart ? parseInt(dto.yearStart, 10) : null,
        rosYearEnd: dto.yearEnd ? parseInt(dto.yearEnd, 10) : null,
        rosStatus: dto.status || 'confirmed',
        rosIsActive: dto.isActive,
        rosSessionNo: dto.sessionNo || '',
        rosNote: dto.note || '',
      })
      .returning({ id: roster.id });

    if (inserted.length === 0) {
      throw new BadRequestException('创建花名册记录失败');
    }

    return { id: inserted[0].id };
  }

  async updateRoster(
    id: string,
    dto: RosterUpdateDto,
  ): Promise<{ success: boolean }> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }

    const patch: Partial<typeof roster.$inferInsert> = {};
    if (dto.position !== undefined) patch.rosPosition = dto.position;
    if (dto.name !== undefined) patch.rosName = dto.name;
    if (dto.phone !== undefined) patch.rosPhone = dto.phone;
    if (dto.term !== undefined) patch.rosTerm = dto.term;
    if (dto.yearStart !== undefined)
      patch.rosYearStart = dto.yearStart ? parseInt(dto.yearStart, 10) : null;
    if (dto.yearEnd !== undefined)
      patch.rosYearEnd = dto.yearEnd ? parseInt(dto.yearEnd, 10) : null;
    if (dto.status !== undefined) patch.rosStatus = dto.status;
    if (dto.isActive !== undefined) patch.rosIsActive = dto.isActive;
    if (dto.sessionNo !== undefined) patch.rosSessionNo = dto.sessionNo;
    if (dto.note !== undefined) patch.rosNote = dto.note;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const updated = await this.db
      .update(roster)
      .set(patch)
      .where(eq(roster.id, id))
      .returning({ id: roster.id });

    if (updated.length === 0) {
      throw new NotFoundException('花名册记录不存在');
    }

    return { success: true };
  }

  async removeRoster(id: string): Promise<{ success: boolean }> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }

    const deleted = await this.db
      .delete(roster)
      .where(eq(roster.id, id))
      .returning({ id: roster.id });

    if (deleted.length === 0) {
      throw new NotFoundException('花名册记录不存在');
    }

    return { success: true };
  }

  async getRosterStats(params: { orgId?: string }): Promise<RosterStats> {
    const conditions = [];
    if (params.orgId) {
      conditions.push(eq(roster.orgId, params.orgId));
    }
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, activeResult, sessionRows] = await Promise.all([
      this.db.select({ count: count() }).from(roster).where(where),
      this.db
        .select({ count: count() })
        .from(roster)
        .where(where ? and(where, eq(roster.rosIsActive, true)) : eq(roster.rosIsActive, true)),
      this.db
        .select({ sessionNo: roster.rosSessionNo })
        .from(roster)
        .where(where)
        .groupBy(roster.rosSessionNo),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const activeCount = Number(activeResult[0]?.count ?? 0);
    const terms = sessionRows
      .map((r) => r.sessionNo)
      .filter((s): s is string => s !== null && s !== undefined && s !== '')
      .sort((a, b) => {
        const na = Number(a);
        const nb = Number(b);
        if (!Number.isNaN(na) && !Number.isNaN(nb)) return nb - na;
        return b.localeCompare(a);
      });

    return { total, activeCount, terms };
  }
}
