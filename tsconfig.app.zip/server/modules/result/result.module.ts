import { Module } from '@nestjs/common';
import { ResultService } from './result.service';
import { ResultController } from './result.controller';
import { RosterController } from './roster.controller';

@Module({
  controllers: [ResultController, RosterController],
  providers: [ResultService],
  exports: [ResultService],
})
export class ResultModule {}
