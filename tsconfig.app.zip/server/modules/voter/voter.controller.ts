import {
  Controller,
  Get,
  Query,
  Param,
  Post,
  Put,
  Patch,
  Delete,
  Body,
} from '@nestjs/common';
import { VoterService } from './voter.service';
import type { ApiResponse } from '@shared/api.interface';
import type { Voter, VoterStats, ListResponse } from '@shared/api.interface';

@Controller('api/voters')
export class VoterController {
  constructor(private readonly voterService: VoterService) {}

  @Get()
  async list(
    @Query('electionId') electionId?: string,
    @Query('orgId') orgId?: string,
    @Query('search') search?: string,
    @Query('name') name?: string,
    @Query('idCard') idCard?: string,
     @Query('status') status?: string,
     @Query('source') source?: string,
     @Query('materialStatus') materialStatus?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Voter>>> {
    const data = await this.voterService.list({
      electionId,
      orgId,
      search,
      name,
      idCard,
       status,
       source,
       materialStatus,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get('stats')
  async stats(
    @Query('electionId') electionId: string,
    @Query('orgId') orgId?: string,
  ): Promise<ApiResponse<VoterStats>> {
    const data = await this.voterService.getStats({ electionId, orgId });
    return { code: 0, data, message: 'success' };
  }

  @Get('statistics')
  async statistics(
    @Query('electionId') electionId: string,
    @Query('orgId') orgId?: string,
  ): Promise<ApiResponse<VoterStats>> {
    const data = await this.voterService.statistics(electionId, orgId);
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async getById(@Param('id') id: string): Promise<ApiResponse<Voter>> {
    const data = await this.voterService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body()
    body: Omit<Voter, 'id' | 'registerTime'> & { registerTime?: string },
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.voterService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Post('batch')
  async batchCreate(
    @Body()
    body: {
      items: Array<
        Omit<Voter, 'id' | 'registerTime'> & { registerTime?: string }
      >;
    },
  ): Promise<ApiResponse<{ inserted: number; ids: string[] }>> {
    const data = await this.voterService.batchCreate(body.items);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: Partial<Voter>,
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.voterService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id')
  async patch(
    @Param('id') id: string,
    @Body() body: Partial<Voter>,
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.voterService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() body: { status: string },
  ): Promise<ApiResponse<{ id: string; status: string }>> {
    const data = await this.voterService.updateStatus(id, body.status);
    return { code: 0, data, message: 'success' };
  }

  @Patch('bulk-status')
  async bulkUpdateStatus(
    @Body() body: { ids: string[]; status: string },
  ): Promise<ApiResponse<{ updated: number }>> {
    const data = await this.voterService.bulkUpdateStatus(
      body.ids,
      body.status,
    );
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async delete(
    @Param('id') id: string,
  ): Promise<ApiResponse<{ id: string }>> {
    const data = await this.voterService.remove(id);
    return { code: 0, data, message: 'success' };
  }
}
