import {
  Inject,
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { eq, and, desc, ilike, sql, inArray, or } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { voters } from '@server/database/schema';
import type {
  Voter,
  VoterStats,
  ListResponse,
} from '@shared/api.interface';

interface ListParams {
  electionId?: string;
  orgId?: string;
  search?: string;
  name?: string;
  idCard?: string;
  status?: string;
  source?: string;
  materialStatus?: string;
  page?: number;
  pageSize?: number;
}

interface StatsParams {
  electionId: string;
  orgId?: string;
}

@Injectable()
export class VoterService {
  private readonly logger = new Logger(VoterService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: ListParams): Promise<ListResponse<Voter>> {
    const conditions = this.buildWhereConditions(params);
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const page = params.page && params.page > 0 ? params.page : 1;
    const pageSize =
      params.pageSize && params.pageSize > 0 ? params.pageSize : 20;

    const [totalResult, rows] = await Promise.all([
      this.db.select({ count: sql<number>`count(*)` }).from(voters).where(where),
      this.db
        .select()
        .from(voters)
        .where(where)
        .orderBy(desc(voters.votRegisterTime), desc(voters.id))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Voter[] = rows.map((row) => this.mapRow(row));

    return { items, total };
  }

  async getById(id: string): Promise<Voter> {
    const rows = await this.db
      .select()
      .from(voters)
      .where(eq(voters.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('参选人不存在');
    }

    return this.mapRow(rows[0]);
  }

  async create(
    data: Omit<Voter, 'id' | 'registerTime'> & { registerTime?: string },
  ): Promise<{ id: string }> {
    if (!data.name) {
      throw new BadRequestException('姓名不能为空');
    }

    const result = await this.db
      .insert(voters)
      .values({
        orgId: data.orgId || '',
        electionId: data.electionId || '',
        votName: data.name,
        votGender: data.gender || '',
        votAge: data.age ?? 0,
        votIdCard: data.idCard || '',
        votPhone: data.phone || '',
        votHouseholdAddr: data.householdAddr || '',
        votResidenceAddr: data.residenceAddr || '',
        votStatus: data.status || '待审核',
        votRegisterTime: data.registerTime || undefined,
        votNote: data.note || '',
         votSource: data.source || 'registered',
         votPositionId: data.positionId || '',
         votMaterialStatus: data.materialStatus || 'none',
       })
       .returning({ id: voters.id });

     return { id: result[0].id };
   }

   async batchCreate(
    items: Array<
      Omit<Voter, 'id' | 'registerTime'> & { registerTime?: string }
    >,
  ): Promise<{ inserted: number; ids: string[] }> {
    if (!items || items.length === 0) {
      throw new BadRequestException('批量数据不能为空');
    }

    const values = items.map((item) => ({
      orgId: item.orgId || '',
      electionId: item.electionId || '',
      votName: item.name || '',
      votGender: item.gender || '',
      votAge: item.age ?? 0,
      votIdCard: item.idCard || '',
      votPhone: item.phone || '',
      votHouseholdAddr: item.householdAddr || '',
      votResidenceAddr: item.residenceAddr || '',
      votStatus: item.status || '待审核',
      votRegisterTime: item.registerTime || undefined,
      votNote: item.note || '',
         votSource: item.source || 'registered',
         votPositionId: item.positionId || '',
         votMaterialStatus: item.materialStatus || 'none',
       }));

    const result = await this.db
      .insert(voters)
      .values(values)
      .returning({ id: voters.id });

    return {
      inserted: result.length,
      ids: result.map((r) => r.id),
    };
  }

  async update(
    id: string,
    data: Partial<Voter>,
  ): Promise<{ id: string }> {
    if (Object.keys(data).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const patch: Partial<typeof voters.$inferInsert> = {};

    if (data.name !== undefined) patch.votName = data.name;
    if (data.gender !== undefined) patch.votGender = data.gender;
    if (data.age !== undefined) patch.votAge = data.age;
    if (data.idCard !== undefined) patch.votIdCard = data.idCard;
    if (data.phone !== undefined) patch.votPhone = data.phone;
    if (data.householdAddr !== undefined)
      patch.votHouseholdAddr = data.householdAddr;
    if (data.residenceAddr !== undefined)
      patch.votResidenceAddr = data.residenceAddr;
    if (data.status !== undefined) patch.votStatus = data.status;
    if (data.note !== undefined) patch.votNote = data.note;
    if (data.source !== undefined) patch.votSource = data.source;
    if (data.positionId !== undefined) patch.votPositionId = data.positionId;
    if (data.materialStatus !== undefined)
      patch.votMaterialStatus = data.materialStatus;

    const result = await this.db
      .update(voters)
      .set(patch)
      .where(eq(voters.id, id))
      .returning({ id: voters.id });

    if (result.length === 0) {
      throw new NotFoundException('参选人不存在');
    }

    return { id };
  }

  async updateStatus(
    id: string,
    status: string,
  ): Promise<{ id: string; status: string }> {
    if (!status) {
      throw new BadRequestException('status 不能为空');
    }

    const result = await this.db
      .update(voters)
      .set({ votStatus: status })
      .where(eq(voters.id, id))
      .returning({ id: voters.id });

    if (result.length === 0) {
      throw new NotFoundException('参选人不存在');
    }

    return { id, status };
  }

  async bulkUpdateStatus(
    ids: string[],
    status: string,
  ): Promise<{ updated: number }> {
    if (!ids || ids.length === 0) {
      throw new BadRequestException('ids 不能为空');
    }
    if (!status) {
      throw new BadRequestException('status 不能为空');
    }

    const result = await this.db
      .update(voters)
      .set({ votStatus: status })
      .where(inArray(voters.id, ids))
      .returning({ id: voters.id });

    return { updated: result.length };
  }

  async remove(id: string): Promise<{ id: string }> {
    const result = await this.db
      .delete(voters)
      .where(eq(voters.id, id))
      .returning({ id: voters.id });

    if (result.length === 0) {
      throw new NotFoundException('参选人不存在或删除失败');
    }

    return { id };
  }

  async getStats(params: StatsParams): Promise<VoterStats> {
    const conditions = this.buildStatsConditions(params);
    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [aggResult] = await Promise.all([
      this.db
        .select({
          total: sql<number>`count(*)`,
          maleCount: sql<number>`count(*) filter (where ${voters.votGender} = '男')`,
          femaleCount: sql<number>`count(*) filter (where ${voters.votGender} = '女')`,
        })
        .from(voters)
        .where(where),
    ]);

    const agg = aggResult[0] ?? {
      total: 0,
      maleCount: 0,
      femaleCount: 0,
    };

    return {
      total: Number(agg.total),
      maleCount: Number(agg.maleCount),
      femaleCount: Number(agg.femaleCount),
    };
  }

  async statistics(electionId: string, orgId?: string): Promise<VoterStats> {
    return this.getStats({ electionId, orgId });
  }

  private buildWhereConditions(params: ListParams) {
    const conditions = [];

    if (params.orgId) conditions.push(eq(voters.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(voters.electionId, params.electionId));

    if (params.search) {
      const keyword = `%${params.search.trim()}%`;
      conditions.push(
        or(
          ilike(voters.votName, keyword),
          ilike(voters.votIdCard, keyword),
        ),
      );
    } else {
      if (params.name) {
        conditions.push(ilike(voters.votName, `%${params.name.trim()}%`));
      }
      if (params.idCard) {
        conditions.push(ilike(voters.votIdCard, `%${params.idCard}%`));
      }
    }

    if (params.status) conditions.push(eq(voters.votStatus, params.status));
    if (params.source) conditions.push(eq(voters.votSource, params.source));
    if (params.materialStatus)
      conditions.push(eq(voters.votMaterialStatus, params.materialStatus));

    return conditions;
  }

  private buildStatsConditions(params: StatsParams) {
    const conditions = [];
    if (params.orgId) conditions.push(eq(voters.orgId, params.orgId));
    if (params.electionId)
      conditions.push(eq(voters.electionId, params.electionId));
    return conditions;
  }

  private mapRow(row: typeof voters.$inferSelect): Voter {
    const note = row.votNote ?? '';
    return {
      id: row.id,
      orgId: row.orgId,
      electionId: row.electionId,
      name: row.votName,
      gender: row.votGender ?? '',
      age: row.votAge ?? 0,
      idCard: row.votIdCard ?? '',
      phone: row.votPhone ?? '',
      householdAddr: row.votHouseholdAddr ?? '',
      residenceAddr: row.votResidenceAddr ?? '',
      status: (row.votStatus ?? '待审核') as Voter['status'],
      registerTime: row.votRegisterTime ?? '',
      note,
      source: row.votSource ?? 'registered',
      positionId: row.votPositionId ?? '',
      materialStatus: row.votMaterialStatus ?? 'none',
    };
  }
}
