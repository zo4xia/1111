import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Query,
  Param,
  Body,
  BadRequestException,
} from '@nestjs/common';
import { PositionService } from './position.service';
import type {
  Position,
  PositionCreateDto,
  PositionUpdateDto,
  PositionStats,
  ListResponse,
  ApiResponse,
} from '@shared/api.interface';

@Controller('api/positions')
export class PositionController {
  constructor(private readonly positionService: PositionService) {}

  @Get('stats')
  async stats(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
  ): Promise<ApiResponse<PositionStats>> {
    const data = await this.positionService.getStats({ orgId, electionId });
    return { code: 0, data, message: 'success' };
  }

  @Get()
  async list(
    @Query('orgId') orgId?: string,
    @Query('electionId') electionId?: string,
    @Query('status') status?: string,
    @Query('type') type?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ): Promise<ApiResponse<ListResponse<Position>>> {
    const data = await this.positionService.list({
      orgId,
      electionId,
      status,
      type,
      page: page ? parseInt(page, 10) : undefined,
      pageSize: pageSize ? parseInt(pageSize, 10) : undefined,
    });
    return { code: 0, data, message: 'success' };
  }

  @Get(':id')
  async detail(@Param('id') id: string): Promise<ApiResponse<Position>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.positionService.getById(id);
    return { code: 0, data, message: 'success' };
  }

  @Post()
  async create(
    @Body() body: PositionCreateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!body.type) {
      throw new BadRequestException('岗位类型不能为空');
    }
    const data = await this.positionService.create(body);
    return { code: 0, data, message: 'success' };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: PositionUpdateDto,
  ): Promise<ApiResponse<{ id: string }>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    const data = await this.positionService.update(id, body);
    return { code: 0, data, message: 'success' };
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ApiResponse<void>> {
    if (!id) {
      throw new BadRequestException('id 不能为空');
    }
    await this.positionService.remove(id);
    return { code: 0, data: undefined, message: 'success' };
  }
}
