import {
  Inject,
  Injectable,
  Logger,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, desc, count, sql } from 'drizzle-orm';
import { positions } from '@server/database/schema';
import type {
  Position,
  PositionCreateDto,
  PositionUpdateDto,
  PositionStats,
  ListResponse,
} from '@shared/api.interface';

@Injectable()
export class PositionService {
  private readonly logger = new Logger(PositionService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: {
    orgId?: string;
    electionId?: string;
    status?: string;
    type?: string;
    page?: number;
    pageSize?: number;
  }): Promise<ListResponse<Position>> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 50;

    const conditions = this.buildConditions(params);

    const query = conditions.length > 0
      ? this.db.select().from(positions).where(and(...conditions))
      : this.db.select().from(positions);

    const rows = await query
      .orderBy(desc(positions.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = conditions.length > 0
      ? await this.db.select({ count: count() }).from(positions).where(and(...conditions))
      : await this.db.select({ count: count() }).from(positions);

    const total = Number(totalResult[0]?.count ?? 0);
    const items: Position[] = rows.map((r) => this.mapPosition(r));

    return { items, total };
  }

  async getById(id: string): Promise<Position> {
    const rows = await this.db.select().from(positions).where(eq(positions.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('岗位不存在');
    }
    return this.mapPosition(rows[0]);
  }

  async create(data: PositionCreateDto): Promise<{ id: string }> {
    if (!data.type) {
      throw new BadRequestException('岗位类型不能为空');
    }
    if (data.quota === undefined || data.quota <= 0) {
      throw new BadRequestException('应选配额必须大于 0');
    }

    const result = await this.db.insert(positions).values({
      orgId: data.orgId || '',
      electionId: data.electionId || '',
      posType: data.type,
      posQuota: data.quota,
      posStatus: 'active',
      posDesc: data.description || '',
    }).returning({ id: positions.id });

    if (result.length === 0) {
      throw new BadRequestException('创建岗位失败');
    }

    this.logger.log(`创建岗位: ${data.type}`);
    return { id: result[0].id };
  }

  async update(
    id: string,
    data: PositionUpdateDto,
  ): Promise<{ id: string }> {
    const existing = await this.db.select().from(positions).where(eq(positions.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('岗位不存在');
    }

    const patch: Partial<typeof positions.$inferInsert> = {};
    if (data.type !== undefined) patch.posType = data.type;
    if (data.quota !== undefined) patch.posQuota = data.quota;
    if (data.description !== undefined) patch.posDesc = data.description;
    if (data.status !== undefined) patch.posStatus = data.status;

    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    const result = await this.db.update(positions)
      .set(patch)
      .where(eq(positions.id, id))
      .returning({ id: positions.id });

    if (result.length === 0) {
      throw new BadRequestException('更新岗位失败');
    }

    this.logger.log(`更新岗位: ${id}`);
    return { id };
  }

  async remove(id: string): Promise<void> {
    const existing = await this.db.select().from(positions).where(eq(positions.id, id));
    if (existing.length === 0) {
      throw new NotFoundException('岗位不存在');
    }

    const result = await this.db.delete(positions)
      .where(eq(positions.id, id))
      .returning({ id: positions.id });

    if (result.length === 0) {
      throw new BadRequestException('删除岗位失败');
    }

    this.logger.log(`删除岗位: ${id}`);
  }

  async getStats(params: {
    orgId?: string;
    electionId?: string;
  }): Promise<PositionStats> {
    const conditions = this.buildConditions(params);

    const result = conditions.length > 0
      ? await this.db
          .select({
            total: count(),
            totalQuota: sql<number>`coalesce(sum(${positions.posQuota}), 0)`,
            directorCount: sql<number>`count(*) filter (where ${positions.posType} = '主任')`,
            viceDirectorCount: sql<number>`count(*) filter (where ${positions.posType} = '副主任')`,
            memberCount: sql<number>`count(*) filter (where ${positions.posType} = '委员')`,
          })
          .from(positions)
          .where(and(...conditions))
      : await this.db
          .select({
            total: count(),
            totalQuota: sql<number>`coalesce(sum(${positions.posQuota}), 0)`,
            directorCount: sql<number>`count(*) filter (where ${positions.posType} = '主任')`,
            viceDirectorCount: sql<number>`count(*) filter (where ${positions.posType} = '副主任')`,
            memberCount: sql<number>`count(*) filter (where ${positions.posType} = '委员')`,
          })
          .from(positions);

    const row = result[0];
    return {
      total: Number(row?.total ?? 0),
      totalQuota: Number(row?.totalQuota ?? 0),
      directorCount: Number(row?.directorCount ?? 0),
      viceDirectorCount: Number(row?.viceDirectorCount ?? 0),
      memberCount: Number(row?.memberCount ?? 0),
    };
  }

  private buildConditions(params: {
    orgId?: string;
    electionId?: string;
    status?: string;
    type?: string;
  }) {
    const conditions = [];
    if (params.orgId) conditions.push(eq(positions.orgId, params.orgId));
    if (params.electionId) conditions.push(eq(positions.electionId, params.electionId));
    if (params.status) conditions.push(eq(positions.posStatus, params.status));
    if (params.type) conditions.push(eq(positions.posType, params.type));
    return conditions;
  }

  private mapPosition(row: typeof positions.$inferSelect): Position {
    return {
      id: row.id,
      orgId: row.orgId || '',
      electionId: row.electionId || '',
      type: row.posType || '',
      quota: row.posQuota ?? 1,
      status: row.posStatus || 'active',
      description: row.posDesc || '',
    };
  }
}
