
项目核心重点：不再使用飞书，本系统是基于不同归属地，每个归属地自己的选举活动开展的，虽然选举活动的流程都一样，但是每个村子进度不一样，Dday的设置也不一样，所以这个是多表的。这是核心关键，这点我们一定要注意

小程序端为其他团队半成品，字段什么的都要审核，对方能力差，需要仔细甄别

# UI 设计指南

> **设计类型**: App 设计（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。

> ℹ️ Section 1 为设计意图与决策上下文。Code agent 实现时以 Section 2 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解

- **目标用户**: 基层政务工作人员（镇街/村居干部），高频操作、数据密集录入与审核场景，心理预期严谨高效、零容错
- **核心目的**: 引导行动 + 建立信任（选举流程合规、状态可追溯、审核留痕）
- **情绪基调**: 秩序感 / 掌控感；避免焦虑、混乱、花哨娱乐感

### 1.2 设计方向

- **Design Style**: Grid 网格 — 16阶段倒排工期+四轮审核天然适合网格化表达，sharp圆角+等宽数字强化日程精确感与政务严肃性
- **Application Type**: Admin/SaaS（政务工作台）— Sidebar导航后台系统
- **Aesthetic Direction**: 克制理性的政务蓝灰体系，以结构化线条和状态色驱动信息层级，拒绝装饰性渐变

## 2. Color System (色彩系统)

**色彩关系**: 深靛蓝主色 + 暖米白底 + 冷灰文字 + 交通灯语义状态色
**配色设计理由**: 米白底(#FAF8F5)减轻长时间操作视觉疲劳，深靛蓝传递政务权威，状态色沿用红黄绿蓝四色确保跨模块语义一致
**主色推导**: primary取深靛蓝(H217)对应"审核/推进/提交"等核心行政动作，区别于互联网产品的亮蓝
**使用比例**: 60% 米白/白底 · 30% 灰蓝辅助 · 10% 深靛蓝primary；状态色仅用于标签/图标/进度条，不做填充背景

### 2.1 主题颜色

| Token                | HSL 值            | 说明                                     |
| -------------------- | ----------------- | ---------------------------------------- |
| `background`         | hsl(36 33% 97%)   | 米白底色 #FAF8F5，延续现有代码基底       |
| `card`               | hsl(0 0% 100%)    | 纯白卡片容器                             |
| `foreground`         | hsl(215 25% 17%)  | 深灰蓝主文字 #1F2937                     |
| `muted-foreground`   | hsl(215 16% 47%)  | 次级说明文字                             |
| `primary`            | hsl(217 65% 32%)  | 深靛蓝主交互，沉稳权威                   |
| `primary-foreground` | hsl(0 0% 100%)    | 主按钮文字                               |
| `accent`             | hsl(217 30% 94%)  | Ghost/hover/focus 低对比反馈背景          |
| `accent-foreground`  | hsl(215 25% 17%)  | accent上的文字                           |
| `border`             | hsl(215 20% 88%)  | 卡片/分割线边框                          |

### 2.2 导航区配色

- **基调关系**: Sidebar复用`background`同色系加深(hsl(217 25% 12%))，Topbar与内容区同底无缝衔接
- **关键状态**: 激活态用`primary`色块左侧4px竖条标识；hover用`accent`半透明覆盖；文字白色确保≥4.5:1
- **边界与背景**: Sidebar右侧1px `border`分隔；Topbar底部1px `border`分隔

### 2.3 语义颜色

| 用途        | 边框/文字色           | 背景色              | 业务映射                              |
| ----------- | --------------------- | ------------------- | ------------------------------------- |
| 成功/已完成 | hsl(152 60% 40%)      | hsl(152 50% 95%)    | 阶段已完成、审核通过、已发布          |
| 办理中/进行 | hsl(217 65% 32%)      | hsl(217 50% 94%)    | 当前阶段、待审核                      |
| 警告/需补正 | hsl(38 85% 45%)       | hsl(38 70% 94%)     | 材料需补正、配额预警                  |
| 错误/驳回   | hsl(0 65% 50%)        | hsl(0 55% 95%)      | 审核驳回、账号禁用                    |
| 未开始/草稿 | hsl(215 16% 57%)      | hsl(215 15% 94%)    | 未开始阶段、草稿状态                  |
| 当选/锁定   | hsl(42 80% 50%)       | hsl(42 70% 95%)     | 当选徽章、岗位锁定（金色仅结果页使用） |

## 3. Typography (字体排版)

- **Heading**: "Source Han Sans SC", "Noto Sans SC", -apple-system, BlinkMacSystemFont, "Microsoft YaHei", sans-serif
- **Body**: 同上字体栈，正文14px/行高1.6，表格内13px/行高1.5
- **Mono**: "JetBrains Mono", "Roboto Mono", ui-monospace, monospace（日志内容、身份证号、D日偏移标识、版本号）
- **字体策略**: 全栈系统字体无个性化定制需求，依赖系统回退保证中文渲染；数字/ID字段强制等宽对齐；标题font-bold vs 正文font-normal形成层级

## 4. Layout Strategy (布局策略)

- **导航意图**: 应用概要设计已声明Sidebar+Topbar全局导航，原样保留；Sidebar支持折叠；至多一套全局导航
- **页面架构**: Sidebar(240px/折叠64px) + Topbar(56px) + Content(p-4/max-w-[1400px])；Footer固定底部显示版本与组件契约信息
- **响应式**: ≥1280px展开Sidebar；<1280px自动折叠为icon-only；移动端隐藏Sidebar改用Topbar汉堡菜单

## 5. Visual Language (视觉语言)

- **形态参数**: 圆角`rounded-sm`(2px) · 阴影`shadow-none`(卡片用1px border替代) · 间距`compact`(gap-3/p-4)
- **识别签名**: D日偏移标识(D-35/D+1)用等宽字体+深色bg胶囊；状态标签统一pill形状+hue-tinted背景；时间轴节点用左侧3px色条区分模块
- **装饰策略**: 不使用任何装饰性插图/渐变/图标动画；仅用色条、徽章、分割线构建信息结构
- **动效原则**: 状态切换/数字更新150ms ease-out；Tab切换无动画；禁止弹跳/缩放等拟物动效
- **可及性**: 所有状态标签同时携带文字+颜色双编码；对比度≥4.5:1；Focus ring用`ring-2 ring-primary offset-2`

## 6. Component Principles (组件原则)

- **状态完整性**: Button/Input/Select/Table Row全覆盖Default/Hover/Focus/Active/Disabled；Disabled态opacity-50+cursor-not-allowed
- **层级清晰**: Primary按钮filled `bg-primary`；Secondary/Ghost用`border-border hover:bg-accent`；Danger操作红色文字按钮而非填充
- **一致性**: 状态标签全系统统一样式(hue-tinted pill)；表格行hover `bg-accent`；弹窗/抽屉统一从右侧滑入
- **数据密集适配**: 表格紧凑模式(row-height: 40px)；表头sticky；关键列(姓名/身份证)font-medium；操作列固定右对齐

## 7. Image Direction (图片与视觉资产)

- **Image Role**: 无强制图片需求
- **Image Art Direction**: 本系统为纯数据管理后台，不设置Hero/插画/品牌图；视觉记忆点通过16阶段时间轴色条、四轮审核进度卡、D日锚点红线等结构化元素建立
- **Image Prompt Keywords**: 无
- **Image Avoidance**: 禁止添加政务人物素材、抽象科技背景、通用办公插图等与业务流程无关的视觉噪音

## 8. 应避免 (Anti-patterns)

- ❌ 使用圆角>8px的卡片或按钮——破坏Grid风格的精确感与政务严肃性
- ❌ 状态仅靠颜色区分而无文字标签——色盲用户无法辨识审核/阶段状态
- ❌ 在仪表盘/列表页添加统计图表以外的装饰性可视化——本系统是操作工作台而非展示大屏